package command

import (
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"time"

	"github.com/robfig/cron/v3"
)

func CronTimer(c *cron.Cron, cfg *config.CronConfig) {
	if cfg.Name != "timer" {
		return
	}

	c.AddFunc(cfg.Time, func() {
		go timerTask()
	})
}

func timerTask() {
	//查找任务
	var findTimers []models.Timer
	if result := global.DB.Where("status = ?", config.TimerStatusPending).Where("execute_time <= ?", time.Now().UnixMilli()).Order("execute_time asc").Find(&findTimers); result.Error != nil {
		return
	}

	//获取任务
	executeTimers := []*models.Timer{}
	for _, timer := range findTimers {
		result := global.DB.Model(&models.Timer{}).Where("id = ?", timer.Id).Where("status = ?", config.TimerStatusPending).Updates(&models.Timer{
			Status:    config.TimerStatusExecuting,
			StartTime: time.Now().UnixMilli(),
		})
		if result.Error != nil {
			continue
		}

		if result.RowsAffected < 1 {
			continue
		}

		executeTimers = append(executeTimers, &timer)
	}

	//执行任务
	for _, timer := range executeTimers {
		var err error
		switch timer.ExecuteType {
		case config.TimerExecuteTypeOrderCancel:
			var order models.Order
			if result := global.DB.Where("id = ?", timer.ExecuteId).First(&order); result.Error != nil {
				err = result.Error
			} else {
				err = service.OrderCancel(&order)
			}
		case config.TimerExecuteTypeOrderDeliver:
			var order models.Order
			if result := global.DB.Where("id = ?", timer.ExecuteId).First(&order); result.Error != nil {
				err = result.Error
			} else {
				err = service.OrderDeliver(&order)
			}
		case config.TimerExecuteTypeOrderComplete:
			var order models.Order
			if result := global.DB.Where("id = ?", timer.ExecuteId).First(&order); result.Error != nil {
				err = result.Error
			} else {
				err = service.OrderComplete(&order)
			}
		}

		//完成任务
		updateData := models.Timer{
			EndTime: time.Now().UnixMilli(),
		}

		if err != nil {
			updateData.Status = config.TimerStatusFail
			updateData.Remark = err.Error()
		} else {
			updateData.Status = config.TimerStatusSuccess
		}

		global.DB.Model(&models.Timer{}).Where("id = ?", timer.Id).Updates(&updateData)
	}
}
