package command

import (
	"app/global"

	"github.com/robfig/cron/v3"
)

// 秒(0-59) 分(0-59) 时(0-23) 日(1-31) 月(1-12) 周(0-6)
// *: 匹配该字段所有值，如 0 0 * 1 1 *, 第三个字段为 * 表示（1 月 1 日）每小时。
// /: 表示范围增量，如 */12 * * * * * 表示每 12 秒执行一次
// ,: 用来分隔同一组中的项目，如 * * * 5,10,15 3,4 * 表示每个三月或四月的 5， 10， 15 号（3.05， 3.10， 3.15， 4.05， 4.10，4.15）
// -: 表示范围，如 */5 * 10-12 * * * 表示每天十点到十二点每五秒执行一次
func InitCron() {
	c := cron.New(cron.WithSeconds())

	for _, item := range global.AppConfig.Crons {
		CronTimer(c, &item)
		CronWxMpAccessToken(c, &item)
	}

	c.Start()
}
