package command

import (
	"app/config"
	"app/service"
	"log"
	"time"

	"github.com/robfig/cron/v3"
)

func CronWxMpAccessToken(c *cron.Cron, cfg *config.CronConfig) {
	if cfg.Name != "wxMpAccessToken" {
		return
	}

	c.AddFunc(cfg.Time, WxMpAccessTokenTask)
}

func WxMpAccessTokenTask() {
	log.Println("WxMpAccessTokenTask do")
	at := service.WxMpAccessTokenInstance
	if at != nil && at.ExpiresTime-1200 > time.Now().Unix() {
		return
	}

	log.Println("CreateWxMpAccessToken do")
	if err := service.CreateWxMpAccessToken(); err != nil {
		log.Println("CreateWxMpAccessToken " + err.Error())
		return
	}
}
