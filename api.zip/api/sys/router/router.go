package router

import (
	"app/global"
	"app/models"
	"app/sys/controller"
	"app/sys/middlewares"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func InitRouter(r *gin.Engine) {
	public := r.Group("/sys")
	{
		public.GET("/captcha", controller.GetCaptcha)
		public.POST("/login", controller.Login)
	}

	var permissionIds []uint

	private := r.Group("/sys")
	{
		private.Use(middlewares.AuthMiddleware(), middlewares.PermissionMiddleware())

		configs := private.Group("/configs")
		{
			permissionIds = append(permissionIds,
				AddRouterAndPermission(configs, http.MethodGet, "", "获取列表", "配置", controller.GetConfigs),
				AddRouterAndPermission(configs, http.MethodGet, "/:id", "获取", "配置", controller.GetConfig),
				AddRouterAndPermission(configs, http.MethodPut, "/:id", "更新", "配置", controller.UpdateConfig),
			)
		}

		images := private.Group("/images")
		{
			permissionIds = append(permissionIds,
				AddRouterAndPermission(images, http.MethodGet, "", "获取列表", "图片", controller.GetImages),
				AddRouterAndPermission(images, http.MethodGet, "/:id", "获取", "图片", controller.GetImage),
				AddRouterAndPermission(images, http.MethodPost, "", "上传", "图片", controller.CreateImage),
			)
		}

		my := private.Group("/my")
		{
			permissionIds = append(permissionIds,
				AddRouterAndPermission(my, http.MethodGet, "", "获取", "个人资料", controller.GetMySysAdmin),
				AddRouterAndPermission(my, http.MethodPut, "", "更新", "个人资料", controller.UpdateMySysAdmin),
			)
		}

		sysRoles := private.Group("/sysRoles")
		{
			permissionIds = append(permissionIds,
				AddRouterAndPermission(sysRoles, http.MethodGet, "", "获取列表", "角色", controller.GetSysRoles),
				AddRouterAndPermission(sysRoles, http.MethodGet, "/:id", "获取", "角色", controller.GetSysRole),
				AddRouterAndPermission(sysRoles, http.MethodPost, "", "创建", "角色", controller.CreateSysRole),
				AddRouterAndPermission(sysRoles, http.MethodPut, "/:id", "更新", "角色", controller.UpdateSysRole),
				AddRouterAndPermission(sysRoles, http.MethodDelete, "/:id", "删除", "角色", controller.DeletedSysRole),
			)
		}

		permissionIds = append(permissionIds,
			AddRouterAndPermission(private, http.MethodGet, "/sysPermissions", "获取权限列表", "角色", controller.GetSysPermissions),
			AddRouterAndPermission(private, http.MethodGet, "/sysRolePermissions/:id", "获取角色权限", "角色", controller.GetSysRolePermissions),
			AddRouterAndPermission(private, http.MethodPut, "/sysRolePermissions/:id", "更新角色权限", "角色", controller.UpdateSysRolePermissions),
		)

		sysAdmins := private.Group("/sysAdmins")
		{
			permissionIds = append(permissionIds,
				AddRouterAndPermission(sysAdmins, http.MethodGet, "", "获取列表", "管理员", controller.GetSysAdmins),
				AddRouterAndPermission(sysAdmins, http.MethodGet, "/:id", "获取", "管理员", controller.GetSysAdmin),
				AddRouterAndPermission(sysAdmins, http.MethodPost, "", "创建", "管理员", controller.CreateSysAdmin),
				AddRouterAndPermission(sysAdmins, http.MethodPut, "/:id", "更新", "管理员", controller.UpdateSysAdmin),
				AddRouterAndPermission(sysAdmins, http.MethodDelete, "/:id", "删除", "管理员", controller.DeletedSysAdmin),
			)
		}

		categorys := private.Group("/categorys")
		{
			permissionIds = append(permissionIds,
				AddRouterAndPermission(categorys, http.MethodGet, "", "获取列表", "产品分类", controller.GetCategorys),
				AddRouterAndPermission(categorys, http.MethodGet, "/:id", "获取", "产品分类", controller.GetCategory),
				AddRouterAndPermission(categorys, http.MethodPost, "", "创建", "产品分类", controller.CreateCategory),
				AddRouterAndPermission(categorys, http.MethodPut, "/:id", "更新", "产品分类", controller.UpdateCategory),
				AddRouterAndPermission(categorys, http.MethodDelete, "/:id", "删除", "产品分类", controller.DeletedCategory),
			)
		}

		products := private.Group("/products")
		{
			permissionIds = append(permissionIds,
				AddRouterAndPermission(products, http.MethodGet, "", "获取列表", "产品", controller.GetProducts),
				AddRouterAndPermission(products, http.MethodGet, "/:id", "获取", "产品", controller.GetProduct),
				AddRouterAndPermission(products, http.MethodPost, "", "创建", "产品", controller.CreateProduct),
				AddRouterAndPermission(products, http.MethodPut, "/:id", "更新", "产品", controller.UpdateProduct),
				AddRouterAndPermission(products, http.MethodDelete, "/:id", "删除", "产品", controller.DeletedProduct),
			)
		}

		permissionIds = append(permissionIds,
			AddRouterAndPermission(private, http.MethodPut, "/productsStatus/:id", "更新状态", "产品", controller.UpdateProductStatus),
		)

		resources := private.Group("/resources")
		{
			permissionIds = append(permissionIds,
				AddRouterAndPermission(resources, http.MethodGet, "", "获取列表", "资源", controller.GetResources),
				AddRouterAndPermission(resources, http.MethodGet, "/:id", "获取", "资源", controller.GetResource),
				AddRouterAndPermission(resources, http.MethodPost, "", "创建", "资源", controller.CreateResource),
				AddRouterAndPermission(resources, http.MethodPut, "/:id", "更新", "资源", controller.UpdateResource),
			)
		}

		permissionIds = append(permissionIds,
			AddRouterAndPermission(private, http.MethodGet, "/resourcesUpload/:id", "上传", "资源", controller.GetResourcesUpload),
			AddRouterAndPermission(private, http.MethodGet, "/resourcesDownload/:id", "下载", "资源", controller.GetResourcesDownload),
		)

		banners := private.Group("/banners")
		{
			permissionIds = append(permissionIds,
				AddRouterAndPermission(banners, http.MethodGet, "", "获取列表", "广告", controller.GetBanners),
				AddRouterAndPermission(banners, http.MethodGet, "/:id", "获取", "广告", controller.GetBanner),
				AddRouterAndPermission(banners, http.MethodPost, "", "创建", "广告", controller.CreateBanner),
				AddRouterAndPermission(banners, http.MethodPut, "/:id", "更新", "广告", controller.UpdateBanner),
				AddRouterAndPermission(banners, http.MethodDelete, "/:id", "删除", "广告", controller.DeletedBanner),
			)
		}

		users := private.Group("/users")
		{
			permissionIds = append(permissionIds,
				AddRouterAndPermission(users, http.MethodGet, "", "获取列表", "用户", controller.GetUsers),
				AddRouterAndPermission(users, http.MethodGet, "/:id", "获取", "用户", controller.GetUser),
				AddRouterAndPermission(users, http.MethodPut, "/:id", "更新", "用户", controller.UpdateUser),
			)
		}

		orders := private.Group("/orders")
		{
			permissionIds = append(permissionIds,
				AddRouterAndPermission(orders, http.MethodGet, "", "获取列表", "订单", controller.GetOrders),
				AddRouterAndPermission(orders, http.MethodGet, "/:id", "获取", "订单", controller.GetOrder),
				AddRouterAndPermission(orders, http.MethodPost, "", "创建", "订单", controller.CreateOrder),
				AddRouterAndPermission(orders, http.MethodPut, "/:id", "更新", "订单", controller.UpdateOrder),
			)
		}

		permissionIds = append(permissionIds,
			AddRouterAndPermission(private, http.MethodPost, "/orderExpresses", "发货", "订单", controller.CreateOrderExpress),
		)
		permissionIds = append(permissionIds,
			AddRouterAndPermission(private, http.MethodPut, "/orderRefunds/:id", "更新退款", "订单", controller.UpdateOrderRefund),
		)
	}

	global.DB.Where("id not in ?", permissionIds).Delete(&models.SysPermission{})
}

func AddRouterAndPermission(r *gin.RouterGroup, httpMethod string, path string, name string, groupName string, handlers ...gin.HandlerFunc) uint {
	r.Handle(httpMethod, path, handlers...)

	db := global.DB

	fullPath := r.BasePath() + path
	if pos := strings.Index(fullPath, ":"); pos >= 0 {
		fullPath = fullPath[0:pos] + "*"
	}

	var permission models.SysPermission
	if result := db.Where(&models.SysPermission{Method: httpMethod, Path: fullPath}).First(&permission); result.Error != nil {
		permission = models.SysPermission{
			Method:    httpMethod,
			Path:      fullPath,
			Name:      name,
			GroupName: groupName,
		}

		db.Create(&permission)
	} else {
		if permission.Name != name || permission.GroupName != groupName {
			permission.Name = name
			permission.GroupName = groupName
			db.Save(&permission)
		}
	}

	return permission.Id
}
