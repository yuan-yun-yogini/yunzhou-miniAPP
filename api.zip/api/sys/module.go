package sys

import (
	"app/config"
	"app/sys/module"
	"app/sys/router"

	"github.com/gin-gonic/gin"
)

func Start(r *gin.Engine, cfg *config.ModuleConfig) {
	module.ModuleConfig = cfg

	router.InitRouter(r)
}
