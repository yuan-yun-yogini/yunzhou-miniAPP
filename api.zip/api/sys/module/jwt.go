package module

import (
	"errors"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

type Claims struct {
	AdminId   uint   `json:"adminId"`
	AdminType string `json:"adminType"`
	RoleIds   []uint `json:"roleIds"`
	jwt.RegisteredClaims
}

// GenerateToken 生成JWT token
func GenerateToken(adminId uint, adminType string, roleIds []uint) (string, time.Time, error) {
	expirationTime := time.Now().Add(time.Duration(ModuleConfig.JWT.Expiry) * time.Second)
	claims := &Claims{
		AdminId:   adminId,
		AdminType: adminType,
		RoleIds:   roleIds,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(expirationTime),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString([]byte(ModuleConfig.JWT.Secret))
	if err != nil {
		return "", expirationTime, err
	}

	return tokenString, expirationTime, nil
}

// ParseToken 解析JWT token
func ParseToken(tokenString string) (*Claims, error) {
	claims := &Claims{}

	token, err := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (interface{}, error) {
		return []byte(ModuleConfig.JWT.Secret), nil
	})

	if err != nil {
		return nil, err
	}

	if !token.Valid {
		return nil, errors.New("invalid token")
	}

	return claims, nil
}
