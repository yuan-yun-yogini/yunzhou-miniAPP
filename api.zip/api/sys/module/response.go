package module

import (
	"app/sys/dtos"
	"net/http"

	"github.com/gin-gonic/gin"
)

func SendResponse(c *gin.Context, status int, data any) {
	c.JSON(status, data)
}

func SendSuccessResponse(c *gin.Context, message string, data any) {
	SendResponse(c, http.StatusOK, dtos.BaseResponse{
		Code:    0,
		Message: message,
		Data:    data,
	})
}

func SendFailResponse(c *gin.Context, status int, code int, message string) {
	SendResponse(c, status, dtos.BaseResponse{
		Code:    code,
		Message: message,
		Data:    nil,
	})
}

func SendFailBadRequestResponse(c *gin.Context, message string) {
	SendFailResponse(c, http.StatusBadRequest, http.StatusBadRequest, message)
}

func SendFailUnauthorizedResponse(c *gin.Context, message string) {
	SendFailResponse(c, http.StatusUnauthorized, http.StatusUnauthorized, message)
}

func SendFailForbiddenResponse(c *gin.Context, message string) {
	SendFailResponse(c, http.StatusForbidden, http.StatusForbidden, message)
}

func SendErrorResponse(c *gin.Context, status int, code int, err error) {
	if gin.Mode() == gin.ReleaseMode {
		SendFailResponse(c, status, code, "系统错误")
	}

	SendFailResponse(c, status, code, err.Error())
}

func SendErrorBadRequestResponse(c *gin.Context, err error) {
	SendErrorResponse(c, http.StatusBadRequest, http.StatusBadRequest, err)
}

func SendErrorInternalServerResponse(c *gin.Context, err error) {
	SendErrorResponse(c, http.StatusInternalServerError, http.StatusInternalServerError, err)
}
