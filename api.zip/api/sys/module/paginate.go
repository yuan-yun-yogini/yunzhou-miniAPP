package module

import (
	"app/sys/dtos"

	"gorm.io/gorm"
)

func Paginate(db *gorm.DB, page uint, pageSize uint, dest any, pagination *dtos.Pagination) {
	tx := db.Session(&gorm.Session{})

	var totalSize int64
	tx.Count(&totalSize)
	pagination.TotalSize = uint(totalSize)

	if pageSize == 0 {
		pageSize = 10
	}
	if pageSize > 100 {
		pageSize = 100
	}
	pagination.PageSize = pageSize

	pagination.TotalPage = pagination.TotalSize / pagination.PageSize
	if pagination.TotalSize%pagination.PageSize != 0 {
		pagination.TotalPage += 1
	}

	if page > pagination.TotalPage {
		page = pagination.TotalPage
	}
	if page <= 1 {
		page = 1
	}
	pagination.Page = page

	tx.Offset(int((pagination.Page - 1) * pagination.PageSize)).Limit(int(pagination.PageSize)).Find(dest)
}
