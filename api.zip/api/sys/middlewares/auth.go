package middlewares

import (
	"app/config"
	"app/global"
	"app/sys/module"
	"fmt"
	"strings"

	"github.com/gin-gonic/gin"
)

// AuthMiddleware JWT认证中间件
func AuthMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		tokenString := ""
		authHeader := c.GetHeader("Authorization")
		if authHeader != "" {
			parts := strings.SplitN(authHeader, " ", 2)
			if !(len(parts) == 2 && parts[0] == "Bearer") {
				module.SendFailUnauthorizedResponse(c, "请登录")
				c.Abort()
				return
			}

			tokenString = parts[1]
		} else {
			if gin.Mode() == gin.DebugMode {
				cookie, err := c.Cookie("token")
				if err != nil {
					module.SendFailUnauthorizedResponse(c, "请登录")
					c.Abort()
					return
				}

				tokenString = cookie
			} else {
				module.SendFailUnauthorizedResponse(c, "请登录")
				c.Abort()
				return
			}
		}

		claims, err := module.ParseToken(tokenString)
		if err != nil {
			module.SendFailUnauthorizedResponse(c, "请重新登录")
			c.Abort()
			return
		}

		// 将用户信息存储到上下文中
		c.Set("adminId", claims.AdminId)
		c.Set("adminType", claims.AdminType)
		c.Set("roleIds", claims.RoleIds)

		c.Next()
	}
}

// PermissionMiddleware 管理员权限中间件
func PermissionMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		var hasPermission = false

		adminType := c.MustGet("adminType").(string)

		if adminType == config.SysAdminTypeSuper {
			hasPermission = true
		} else {
			roleIds := c.MustGet("roleIds").([]uint)

			for _, item := range roleIds {
				sub := fmt.Sprintf("sys_%d", item)
				obj := c.Request.URL.Path
				act := c.Request.Method

				ok, err := global.CasbinEnforcer.Enforce(sub, obj, act)
				if err == nil && ok {
					hasPermission = true
					break
				}
			}
		}

		if !hasPermission {
			module.SendFailForbiddenResponse(c, "没有权限")
			c.Abort()
			return
		}

		c.Next()
	}
}
