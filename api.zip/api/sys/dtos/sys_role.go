package dtos

import "time"

type SysRoleRequest struct {
	Name        string `json:"name" binding:"required"`
	Description string `json:"description"`
	Status      string `json:"status" binding:"required"`
}

type SysRoleResponse struct {
	Id          uint         `json:"id"`
	Name        string       `json:"name"`
	Description string       `json:"description"`
	Status      string       `json:"status"`
	CreatedAt   TimeResponse `json:"createdAt"`
}

type SysRoleSearchRequest struct {
	PageRequest
	Id             uint       `json:"id" form:"id"`
	Name           string     `json:"name" form:"name"`
	Status         string     `json:"status" form:"status"`
	StartCreatedAt *time.Time `json:"startCreatedAt" form:"startCreatedAt" time_format:"2006-01-02 15:04:05"`
	EndCreatedAt   *time.Time `json:"endCreatedAt" form:"endCreatedAt" time_format:"2006-01-02 15:04:05"`
}

type SysRolePermissionRequest struct {
	PermissionIds []uint `json:"permissionIds" binding:"required"`
}
