package dtos

import "time"

type BaseResponse struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    any    `json:"data"`
}

type PageRequest struct {
	Page     uint   `json:"page" form:"page"`
	PageSize uint   `json:"pageSize" form:"pageSize"`
	Sort     string `json:"sort" form:"sort"`
}

type Pagination struct {
	TotalSize uint `json:"totalSize"`
	TotalPage uint `json:"totalPage"`
	Page      uint `json:"page"`
	PageSize  uint `json:"pageSize"`
}

type PageResponse struct {
	List       any        `json:"list"`
	Pagination Pagination `json:"pagination"`
}

type TimeResponse time.Time

func (rt TimeResponse) MarshalJSON() ([]byte, error) {
	str := `"` + time.Time(rt).Format(time.DateTime) + `"`
	return []byte(str), nil
}

func (rt *TimeResponse) UnmarshalJSON(data []byte) error {
	var t time.Time
	err := t.UnmarshalJSON(data)
	if err != nil {
		return err
	}
	*rt = TimeResponse(t)
	return nil
}
