package dtos

import "time"

type UserRequest struct {
	Status string `json:"status"`
	Remark string `json:"remark"`
}

type UserSearchRequest struct {
	PageRequest
	Id             uint       `json:"id" form:"id"`
	Username       string     `json:"username" form:"username"`
	Name           string     `json:"name" form:"name"`
	Phone          string     `json:"phone" form:"phone"`
	Status         string     `json:"status" form:"status"`
	StartCreatedAt *time.Time `json:"startCreatedAt" form:"startCreatedAt" time_format:"2006-01-02 15:04:05"`
	EndCreatedAt   *time.Time `json:"endCreatedAt" form:"endCreatedAt" time_format:"2006-01-02 15:04:05"`
}

type UserResponse struct {
	Id        uint          `json:"id"`
	InviterId *uint         `json:"inviterId"`
	Username  string        `json:"username"`
	Phone     string        `json:"phone"`
	Name      string        `json:"name"`
	Avatar    ImageResponse `json:"avatar"`
	Status    string        `json:"status"`
	Remark    string        `json:"remark"`
	CreatedAt TimeResponse  `json:"createdAt"`
}
