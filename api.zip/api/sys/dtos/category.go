package dtos

type CategoryRequest struct {
	ParentId *uint  `json:"parentId"`
	Name     string `json:"name" binding:"required"`
	ImageId  uint   `json:"imageId" binding:"required"`
}

type CategoryResponse struct {
	Id       uint          `json:"id"`
	ParentId *uint         `json:"parentId"`
	Name     string        `json:"name"`
	Image    ImageResponse `json:"image"`
}
