package dtos

type ConfigRequest struct {
	Name        string `json:"name" binding:"required"`
	Description string `json:"description"`
	ConfigValue string `json:"configValue"`
}

type ConfigSearchRequest struct {
	PageRequest
	Name      string `json:"name" form:"name"`
	ConfigKey string `json:"configKey" form:"configKey"`
}

type ConfigResponse struct {
	Id          uint           `json:"id"`
	Type        string         `json:"type"`
	Name        string         `json:"name"`
	Description string         `json:"description"`
	ConfigKey   string         `json:"configKey"`
	ConfigValue string         `json:"configValue"`
	Image       *ImageResponse `json:"image"`
}
