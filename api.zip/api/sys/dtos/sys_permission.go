package dtos

type SysPermissionResponse struct {
	Id          uint         `json:"id"`
	Method      string       `json:"method"`
	Path        string       `json:"path"`
	Name        string       `json:"name"`
	Description string       `json:"description"`
	GroupName   string       `json:"groupName"`
	CreatedAt   TimeResponse `json:"createdAt"`
}
