package dtos

import "time"

type ProductSearchRequest struct {
	PageRequest
	Id              uint       `json:"id" form:"id"`
	CategoryId      uint       `json:"categoryId" form:"categoryId"`
	Name            string     `json:"name" form:"name"`
	Status          string     `json:"status" form:"status"`
	StartOnlineTime *time.Time `json:"startOnlineTime" form:"startOnlineTime" time_format:"2006-01-02 15:04:05"`
	EndOnlineTime   *time.Time `json:"endOnlineTime" form:"endOnlineTime" time_format:"2006-01-02 15:04:05"`
}

type ProductSpecRequest struct {
	Name  string   `json:"name"`
	Attrs []string `json:"attrs"`
}

type ProductSpecAttrRequest struct {
	ResourceIds   []uint `json:"resourceIds"`
	Name          string `json:"name"`
	ImageId       uint   `json:"imageId"`
	OriginalPrice uint   `json:"originalPrice"`
	Price         uint   `json:"price"`
	Stock         int    `json:"stock"`
}

type ProductRequest struct {
	CategoryId     uint                     `json:"categoryId" binding:"required"`
	ResourceIds    []uint                   `json:"resourceIds"`
	Sku            string                   `json:"sku"`
	Name           string                   `json:"name" binding:"required"`
	ImageId        uint                     `json:"imageId" binding:"required"`
	ImageIds       []uint                   `json:"imageIds" binding:"required"`
	DetailImageIds []uint                   `json:"detailImageIds"`
	Description    string                   `json:"description"`
	OriginalPrice  uint                     `json:"originalPrice"`
	Price          uint                     `json:"price" binding:"required"`
	Stock          int                      `json:"stock"`
	Flag           string                   `json:"flag"`
	Status         string                   `json:"status" binding:"required"`
	Sort           int                      `json:"sort"`
	Specs          []ProductSpecRequest     `json:"specs"`
	SpecAttrs      []ProductSpecAttrRequest `json:"specAttrs"`
}

type ProductStatusRequest struct {
	Status string `json:"status" binding:"required"`
}

type ProductSpecResponse struct {
	Id    uint     `json:"id"`
	Name  string   `json:"name"`
	Attrs []string `json:"attrs"`
}

type ProductSpecAttrResponse struct {
	Id            uint          `json:"id"`
	Name          string        `json:"name"`
	Image         ImageResponse `json:"image"`
	OriginalPrice uint          `json:"originalPrice"`
	Price         uint          `json:"price"`
	Stock         int           `json:"stock"`
	ResourceIds   []uint        `json:"resourceIds"`
}

type ProductListResponse struct {
	Id            uint             `json:"id"`
	Sku           string           `json:"sku"`
	Name          string           `json:"name"`
	OriginalPrice uint             `json:"originalPrice"`
	Price         uint             `json:"price"`
	Stock         int              `json:"stock"`
	Flag          string           `json:"flag"`
	Status        string           `json:"status"`
	OnlineTime    *TimeResponse    `json:"onlineTime"`
	SalesVolumn   uint             `json:"salesVolumn"`
	Sort          int              `json:"sort"`
	CreatedAt     TimeResponse     `json:"createdAt"`
	Category      CategoryResponse `json:"category"`
	Image         ImageResponse    `json:"image"`
}

type ProductResponse struct {
	Id            uint                      `json:"id"`
	Sku           string                    `json:"sku"`
	Name          string                    `json:"name"`
	Description   string                    `json:"description"`
	OriginalPrice uint                      `json:"originalPrice"`
	Price         uint                      `json:"price"`
	Stock         int                       `json:"stock"`
	Flag          string                    `json:"flag"`
	Status        string                    `json:"status"`
	OnlineTime    *TimeResponse             `json:"onlineTime"`
	SalesVolumn   uint                      `json:"salesVolumn"`
	Sort          int                       `json:"sort"`
	ResourceIds   []uint                    `json:"resourceIds"`
	CreatedAt     TimeResponse              `json:"createdAt"`
	Category      CategoryResponse          `json:"category"`
	Image         ImageResponse             `json:"image"`
	Images        []ImageResponse           `json:"images"`
	DetailImages  []ImageResponse           `json:"detailImages"`
	Specs         []ProductSpecResponse     `json:"specs"`
	SpecAttrs     []ProductSpecAttrResponse `json:"specAttrs"`
}
