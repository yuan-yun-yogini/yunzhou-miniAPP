package dtos

type BannerRequest struct {
	Type        string `json:"type" binding:"required"`
	Name        string `json:"name" binding:"required"`
	ImageId     uint   `json:"imageId" binding:"required"`
	Url         string `json:"url"`
	Description string `json:"description"`
	LoginStatus string `json:"loginStatus"`
	Status      string `json:"status" binding:"required"`
	Sort        int    `json:"sort"`
}

type BannerSearchRequest struct {
	PageRequest
	Id     uint   `json:"id" form:"id"`
	Type   string `json:"type" form:"type"`
	Name   string `json:"name" form:"name"`
	Status string `json:"status" form:"status"`
}

type BannerResponse struct {
	Id          uint          `json:"id"`
	Type        string        `json:"type"`
	Name        string        `json:"name"`
	Url         string        `json:"url"`
	Description string        `json:"description"`
	LoginStatus string        `json:"loginStatus"`
	Status      string        `json:"status"`
	Sort        int           `json:"sort"`
	Image       ImageResponse `json:"image"`
}
