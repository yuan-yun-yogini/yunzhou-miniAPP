package dtos

type ImageSearchRequest struct {
	PageRequest
	Id   uint   `json:"id" form:"id"`
	Hash string `json:"hash" form:"hash"`
}

type ImageResponse struct {
	Id     uint   `json:"id"`
	Type   string `json:"type"`
	Size   uint   `json:"size"`
	Width  int    `json:"width"`
	Height int    `json:"height"`
	Url    string `json:"url"`
}
