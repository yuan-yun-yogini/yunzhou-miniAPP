package dtos

import "time"

type SysAdminRequest struct {
	Type     string `json:"type" binding:"required"`
	Username string `json:"username" binding:"required"`
	Password string `json:"password" binding:"password"`
	Phone    string `json:"phone" binding:"phonenumber"`
	Name     string `json:"name" binding:"required"`
	AvatarId *uint  `json:"avatarId"`
	Status   string `json:"status" binding:"required"`
	Remark   string `json:"remark"`
	RoleIds  []uint `json:"roleIds"`
}

type SysAdminResponse struct {
	Id        uint              `json:"id"`
	Type      string            `json:"type"`
	Username  string            `json:"username"`
	Phone     string            `json:"phone"`
	Name      string            `json:"name"`
	Avatar    *ImageResponse    `json:"avatar"`
	LoginIp   string            `json:"loginIp"`
	LoginTime *TimeResponse     `json:"loginTime"`
	Status    string            `json:"status"`
	Remark    string            `json:"remark"`
	CreatedAt TimeResponse      `json:"createdAt"`
	Roles     []SysRoleResponse `json:"roles"`
}

type SysAdminSearchRequest struct {
	PageRequest
	Id             uint       `json:"id" form:"id"`
	Username       string     `json:"username" form:"username"`
	Name           string     `json:"name" form:"name"`
	Phone          string     `json:"phone" form:"phone"`
	Status         string     `json:"status" form:"status"`
	StartCreatedAt *time.Time `json:"startCreatedAt" form:"startCreatedAt" time_format:"2006-01-02 15:04:05"`
	EndCreatedAt   *time.Time `json:"endCreatedAt" form:"endCreatedAt" time_format:"2006-01-02 15:04:05"`
}

type SysAdminLoginRequest struct {
	Username      string `json:"username" binding:"required" example:"admin"`  //用户名
	Password      string `json:"password" binding:"required" example:"123456"` //密码
	CaptchaId     string `json:"captchaId" binding:"required"`                 //验证码id
	CaptchaAnswer string `json:"captchaAnswer" binding:"required"`             //验证码答案
}

type SysAdminLoginResponse struct {
	Token       string                  `json:"token"`
	Expire      uint                    `json:"expire"`
	Admin       SysAdminResponse        `json:"admin"`
	Permissions []SysPermissionResponse `json:"permissions"`
}
