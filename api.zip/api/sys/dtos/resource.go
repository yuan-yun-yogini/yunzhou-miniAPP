package dtos

type ResourceSearchRequest struct {
	PageRequest
	Id     uint   `json:"id" form:"id"`
	Type   string `json:"type" form:"type"`
	Name   string `json:"name" form:"name"`
	Status string `json:"status" form:"status"`
}

type ResourceRequest struct {
	Name   string `json:"name"`
	Type   string `json:"type"`
	Ext    string `json:"ext"`
	Status string `json:"status"`
}

type ResourceResponse struct {
	Id     uint   `json:"id"`
	Name   string `json:"name"`
	Type   string `json:"type"`
	Ext    string `json:"ext"`
	Size   uint   `json:"size"`
	Hash   string `json:"hash"`
	Attr   string `json:"attr"`
	Status string `json:"status"`
	Url    string `json:"url"`
}
