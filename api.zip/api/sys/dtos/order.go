package dtos

import "time"

type OrderSearchRequest struct {
	PageRequest
	Id             uint       `json:"id" form:"id"`                                                           //id
	UserId         uint       `json:"userId" form:"userId"`                                                   //用户id
	OrderNo        string     `json:"orderNo" form:"orderNo"`                                                 //订单编号
	Status         string     `json:"status" form:"status"`                                                   //状态
	RefundStatus   string     `json:"refundStatus" form:"refundStatus"`                                       //退款状态
	EvaluateStatus string     `json:"evaluateStatus" form:"evaluateStatus"`                                   //评价状态
	StartCreatedAt *time.Time `json:"startCreatedAt" form:"startCreatedAt" time_format:"2006-01-02 15:04:05"` //开始创建时间
	EndCreatedAt   *time.Time `json:"endCreatedAt" form:"endCreatedAt" time_format:"2006-01-02 15:04:05"`     //结束创建时间
}

type OrderCreateRequest struct {
	UserId            uint   `json:"userId" binding:"required"`
	AddressId         *uint  `json:"addressId"`
	ProductId         uint   `json:"productId" binding:"required"`
	ProductSepcAttrId *uint  `json:"productSpecAttrId"`
	ProductQuantity   uint   `json:"productQuantity" binding:"required"`
	PayAmount         uint   `json:"payAmount"`
	CouponId          *uint  `json:"couponId"`
	Remark            string `json:"remark"`
}

type OrderRequest struct {
	Remark *string `json:"remark"`
}

type OrderExpressListRequest struct {
	OrderId        uint                  `json:"orderId" binding:"required"`
	OrderExpresses []OrderExpressRequest `json:"orderExpresses" binding:"required"`
}

type OrderExpressRequest struct {
	CompanyName string `json:"companyName" binding:"required"`
	ExpressNo   string `json:"expressNo" binding:"required"`
}

type OrderRefundRequest struct {
	ReplyContent string `json:"replyContent"`
	Status       string `json:"status" binding:"required"`
}

type OrderListResponse struct {
	Id             uint         `json:"id"`
	OrderNo        string       `json:"orderNo"`
	TotalAmount    uint         `json:"totalAmount"`
	DiscountAmount uint         `json:"discountAmount"`
	PayAmount      uint         `json:"payAmount"`
	RefundAmount   uint         `json:"refundAmount"`
	Remark         string       `json:"remark"`
	Status         string       `json:"status"`
	RefundStatus   string       `json:"refundStatus"`
	EvaluateStatus string       `json:"evaluateStatus"`
	CreatedAt      TimeResponse `json:"createdAt"`
	User           UserResponse `json:"user"`
}

type OrderResponse struct {
	Id             uint                   `json:"id"`
	OrderNo        string                 `json:"orderNo"`
	TotalAmount    uint                   `json:"totalAmount"`
	DiscountAmount uint                   `json:"discountAmount"`
	PayAmount      uint                   `json:"payAmount"`
	RefundAmount   uint                   `json:"refundAmount"`
	Description    string                 `json:"description"`
	Remark         string                 `json:"remark"`
	Status         string                 `json:"status"`
	RefundStatus   string                 `json:"refundStatus"`
	EvaluateStatus string                 `json:"evaluateStatus"`
	CreatedAt      TimeResponse           `json:"createdAt"`
	User           UserResponse           `json:"user"`
	OrderAddress   *OrderAddressResponse  `json:"orderAddress"`
	OrderProducts  []OrderProductResponse `json:"orderProducts"`
	OrderExpresses []OrderExpressResponse `json:"orderExpresses"`
	OrderRefund    *OrderRefundResponse   `json:"orderRefund"`
}

type OrderProductResponse struct {
	Id                  uint          `json:"id"`
	ProductId           uint          `json:"productId"`
	ProductName         string        `json:"productName"`
	ProductSpecAttrId   *uint         `json:"productSpecAttrId"`
	ProductSpecAttrName string        `json:"productSpecAttrName"`
	Quantity            uint          `json:"quantity"`
	Price               uint          `json:"price"`
	TotalAmount         uint          `json:"totalAmount"`
	DiscountAmount      uint          `json:"discountAmount"`
	PayAmount           uint          `json:"payAmount"`
	ProductImage        ImageResponse `json:"productImage"`
}

type OrderAddressResponse struct {
	Id       uint   `json:"id"`
	Name     string `json:"name"`
	Phone    string `json:"phone"`
	Province string `json:"province"`
	City     string `json:"city"`
	District string `json:"district"`
	Detail   string `json:"detail"`
}

type OrderExpressResponse struct {
	Id          uint   `json:"id"`
	CompanyName string `json:"companyName"`
	ExpressNo   string `json:"expressNo"`
	Status      string `json:"status"`
}

type OrderRefundResponse struct {
	Id           uint            `json:"id"`
	Amount       uint            `json:"amount"`
	Reason       string          `json:"reason"`
	ReplyContent string          `json:"replyContent"`
	ReplyTime    *TimeResponse   `json:"replyTime"`
	RefundTime   *TimeResponse   `json:"refundTime"`
	Status       string          `json:"status"`
	Images       []ImageResponse `json:"images"`
}
