package controller

import (
	"app/global"
	"app/models"
	"app/sys/dtos"
	"app/sys/module"
	"app/utils"
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
)

// @Tags Sys用户管理
// @Summary 获取用户列表
// @Produce json
// @Param page query int false "页码"
// @Param pageSize query int false "页条数"
// @Param sort query string false "排序"
// @Param id query int false "id"
// @Param username query string false "用户名"
// @Param name query string false "名称"
// @Param phone query string false "手机号"
// @Param status query string false "状态"
// @Param startCreatedAt query string false "开始创建时间"
// @Param endCreatedAt query string false "结束创建时间"
// @Success 200 {object} dtos.PageResponse{list=[]dtos.UserResponse} "用户列表"
// @Router /sys/users [get]
func GetUsers(c *gin.Context) {
	var req dtos.UserSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	db := global.DB.Model(&models.User{})

	if req.Id > 0 {
		db = db.Where("id = ?", req.Id)
	}
	if req.Username != "" {
		db = db.Where("username like ?", fmt.Sprintf("%%%s%%", req.Username))
	}
	if req.Name != "" {
		db = db.Where("name like ?", fmt.Sprintf("%%%s%%", req.Name))
	}
	if req.Phone != "" {
		db = db.Where("phone like ?", fmt.Sprintf("%%%s%%", req.Phone))
	}
	if req.Status != "" {
		db = db.Where("status = ?", req.Status)
	}
	if req.StartCreatedAt != nil {
		db = db.Where("created_at >= ?", req.StartCreatedAt)
	}
	if req.EndCreatedAt != nil {
		db = db.Where("created_at <= ?", req.EndCreatedAt)
	}

	if req.Sort == "idDesc" {
		db = db.Order("id desc")
	} else {
		db = db.Order("id asc")
	}

	db = db.Preload("Avatar")

	var pageResponse dtos.PageResponse
	var users []models.User

	module.Paginate(db, req.Page, req.PageSize, &users, &(pageResponse.Pagination))

	var dtoList []dtos.UserResponse
	utils.CopyObject(&users, &dtoList)

	pageResponse.List = dtoList

	module.SendSuccessResponse(c, "", pageResponse)
}

// @Tags Sys用户管理
// @Summary 获取用户信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.UserResponse "用户信息"
// @Router /sys/users/{id} [get]
func GetUser(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var user models.User
	if result := global.DB.Where("id = ?", id).Preload("Avatar").First(&user); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.UserResponse
	utils.CopyObject(&user, &dto)

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Sys用户管理
// @Summary 更新用户信息
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.UserRequest true "用户信息"
// @Success 200 {object} dtos.UserResponse "用户信息"
// @Router /sys/users/{id} [put]
func UpdateUser(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.UserRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var user models.User
	if result := global.DB.Where("id = ?", id).First(&user); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	utils.CopyObject(&req, &user)

	db := global.DB
	if user.Password == "" {
		db = db.Omit("Password")
	}
	db.Save(&user)

	GetUser(c)
}
