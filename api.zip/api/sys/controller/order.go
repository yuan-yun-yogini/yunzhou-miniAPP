package controller

import (
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"app/sys/dtos"
	"app/sys/module"
	"app/utils"
	"fmt"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// @Tags Sys订单管理
// @Summary 获取订单列表
// @Produce json
// @Param page query int false "页码"
// @Param pageSize query int false "页条数"
// @Param sort query string false "排序"
// @Param id query int false "id"
// @Param userId query int false "用户id"
// @Param status query string false "状态"
// @Param startCreatedAt query string false "开始创建时间"
// @Param endCreatedAt query string false "结束创建时间"
// @Success 200 {object} dtos.PageResponse{list=[]dtos.OrderListResponse} "订单列表"
// @Router /sys/orders [get]
func GetOrders(c *gin.Context) {
	var req dtos.OrderSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	db := global.DB.Model(&models.Order{})

	if req.Id > 0 {
		db = db.Where("id = ?", req.Id)
	}
	if req.UserId > 0 {
		db = db.Where("user_id = ?", req.UserId)
	}
	if req.OrderNo != "" {
		db = db.Where("order_no = ?", req.OrderNo)
	}
	if req.Status != "" {
		db = db.Where("status = ?", req.Status)
	}
	if req.RefundStatus != "" {
		db = db.Where("refund_status = ?", req.RefundStatus)
	}
	if req.EvaluateStatus != "" {
		db = db.Where("evaluate_status = ?", req.EvaluateStatus)
	}
	if req.StartCreatedAt != nil {
		db = db.Where("created_at >= ?", req.StartCreatedAt)
	}
	if req.EndCreatedAt != nil {
		db = db.Where("created_at <= ?", req.EndCreatedAt)
	}

	db = db.Order("id desc")

	db = db.Preload("User")

	var pageResponse dtos.PageResponse
	var orders []models.Order

	module.Paginate(db, req.Page, req.PageSize, &orders, &(pageResponse.Pagination))

	var dtoList []dtos.OrderListResponse
	utils.CopyObject(&orders, &dtoList)

	pageResponse.List = dtoList

	module.SendSuccessResponse(c, "", pageResponse)
}

// @Tags Sys订单管理
// @Summary 获取订单信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.OrderResponse "订单信息"
// @Router /sys/orders/{id} [get]
func GetOrder(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var order models.Order
	if result := global.DB.Where("id = ?", id).Preload("User").Preload("OrderAddress").Preload("OrderProducts.ProductImage").Preload("OrderExpresses").Preload("OrderRefund").First(&order); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.OrderResponse
	utils.CopyObject(&order, &dto)

	if order.OrderRefund != nil {
		if order.OrderRefund.ImageIds != "" {
			imageList := service.LoadImageListWithIds([]string{order.OrderRefund.ImageIds})
			utils.CopyObject(&imageList[0], &dto.OrderRefund.Images)
		}
	}

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Sys订单管理
// @Summary 创建订单
// @Produce json
// @Param body body dtos.OrderCreateRequest true "订单信息"
// @Success 200 {object} dtos.OrderResponse "订单信息"
// @Router /api/orders [post]
func CreateOrder(c *gin.Context) {
	var req dtos.OrderCreateRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var user models.User
	if result := global.DB.Where("id = ?", req.UserId).First(&user); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var product models.Product
	if result := global.DB.Where("id = ?", req.ProductId).First(&product); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var productSpecAttr models.ProductSpecAttr
	if req.ProductSepcAttrId != nil && *req.ProductSepcAttrId > 0 {
		if result := global.DB.Where("id = ?", *req.ProductSepcAttrId).First(&productSpecAttr); result.Error != nil {
			module.SendErrorBadRequestResponse(c, result.Error)
			return
		}
	}

	var address models.Address
	if req.AddressId != nil && *req.AddressId > 0 {
		if result := global.DB.Where("id = ?", *req.AddressId).First(&address); result.Error != nil {
			module.SendErrorBadRequestResponse(c, result.Error)
			return
		}
	}

	//生成订单数据
	var order models.Order

	order.UserId = user.Id
	order.OrderNo = fmt.Sprintf("%s%09d%d", time.Now().Format("20060102150405"), time.Now().Nanosecond(), user.Id)
	order.Remark = req.Remark
	order.Status = config.OrderStatusCompleted

	var orderProduct models.OrderProduct

	orderProduct.UserId = user.Id
	orderProduct.ProductId = product.Id
	orderProduct.ProductName = product.Name
	orderProduct.Status = config.OrderStatusCompleted

	if productSpecAttr.Id > 0 {
		orderProduct.ProductSpecAttrId = &productSpecAttr.Id
		orderProduct.ProductSpecAttrName = productSpecAttr.Name

		orderProduct.ProductImageId = productSpecAttr.ImageId
		orderProduct.Price = productSpecAttr.Price
		orderProduct.ResourceIds = productSpecAttr.ResourceIds
	} else {
		orderProduct.ProductImageId = product.ImageId
		orderProduct.Price = product.Price
		orderProduct.ResourceIds = product.ResourceIds
	}

	orderProduct.Quantity = req.ProductQuantity
	orderProduct.TotalAmount = orderProduct.Price * orderProduct.Quantity
	orderProduct.PayAmount = req.PayAmount
	if orderProduct.TotalAmount > req.PayAmount {
		orderProduct.DiscountAmount = orderProduct.TotalAmount - req.PayAmount
	}

	order.TotalAmount = orderProduct.TotalAmount
	order.DiscountAmount = orderProduct.DiscountAmount
	order.PayAmount = orderProduct.PayAmount

	//生成收货信息
	var orderAddress *models.OrderAddress

	if address.Id > 0 {
		orderAddress = &models.OrderAddress{
			Name:     address.Name,
			Phone:    address.Phone,
			Province: address.Province,
			City:     address.City,
			District: address.District,
			Detail:   address.Detail,
		}
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		if result := tx.Create(&order); result.Error != nil {
			return result.Error
		}

		orderProduct.OrderId = order.Id

		if result := tx.Create(&orderProduct); result.Error != nil {
			return result.Error
		}

		if orderAddress != nil {
			orderAddress.OrderId = order.Id
			if result := tx.Create(orderAddress); result.Error != nil {
				return result.Error
			}
		}

		tx.Model(&models.Product{}).Where("id = ?", product.Id).Update("sales_volumn", gorm.Expr("sales_volumn + ?", req.ProductQuantity))

		return nil
	})

	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	var orderResponse dtos.OrderResponse
	utils.CopyObject(&order, &orderResponse)

	module.SendSuccessResponse(c, "创建成功", orderResponse)
}

// @Tags Sys订单管理
// @Summary 更新订单信息
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.OrderRequest true "订单信息"
// @Success 200 {object} dtos.BaseResponse "结果"
// @Router /sys/orders/{id} [put]
func UpdateOrder(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.OrderRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var order models.Order
	if result := global.DB.Where("id = ?", id).First(&order); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	if req.Remark != nil {
		order.Remark = *req.Remark
	}

	global.DB.Save(&order)

	module.SendSuccessResponse(c, "", nil)
}

// @Tags Sys订单管理
// @Summary 创建订单发货信息
// @Produce json
// @Param body body []dtos.OrderExpressListRequest true "发货信息"
// @Success 200 {object} []dtos.BaseResponse "结果"
// @Router /sys/orderExpresses [post]
func CreateOrderExpress(c *gin.Context) {
	var req dtos.OrderExpressListRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var order models.Order
	if result := global.DB.Where("id = ?", req.OrderId).First(&order); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	orderExpressRequests := []models.OrderExpress{}
	for _, item := range req.OrderExpresses {
		if item.CompanyName != "" && item.ExpressNo != "" {
			orderExpressRequests = append(orderExpressRequests, models.OrderExpress{
				OrderId:     order.Id,
				CompanyName: item.CompanyName,
				ExpressNo:   item.ExpressNo,
				Status:      config.OrderExpressStatusShipped,
			})
		}
	}

	err := service.OrderShip(&order, orderExpressRequests)
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	module.SendSuccessResponse(c, "", nil)
}

// @Tags Sys订单管理
// @Summary 更新订单退款信息
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.OrderRefundRequest true "退款信息"
// @Success 200 {object} dtos.BaseResponse "结果"
// @Router /sys/orderRefunds/{id} [put]
func UpdateOrderRefund(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.OrderRefundRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var orderRefund models.OrderRefund
	if result := global.DB.Where("id = ?", id).First(&orderRefund); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	switch req.Status {
	case config.OrderRefundStatusRefunding:
		if err := service.OrderRefundAccept(&orderRefund, req.ReplyContent); err != nil {
			module.SendErrorInternalServerResponse(c, err)
			return
		}
	case config.OrderRefundStatusReject:
		if req.ReplyContent == "" {
			module.SendFailBadRequestResponse(c, "请输入拒绝原因")
			return
		}

		if err := service.OrderRefundReject(&orderRefund, req.ReplyContent); err != nil {
			module.SendErrorInternalServerResponse(c, err)
			return
		}
	default:
		module.SendFailBadRequestResponse(c, "此状态不可操作")
		return
	}

	module.SendSuccessResponse(c, "", nil)
}
