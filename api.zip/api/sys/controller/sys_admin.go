package controller

import (
	"app/global"
	"app/models"
	"app/sys/dtos"
	"app/sys/module"
	"app/utils"
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
)

// @Tags Sys管理员管理
// @Summary 获取管理员列表
// @Produce json
// @Param page query int false "页码"
// @Param pageSize query int false "页条数"
// @Param sort query string false "排序"
// @Param id query int false "id"
// @Param username query string false "用户名"
// @Param name query string false "名称"
// @Param phone query string false "手机号"
// @Param status query string false "状态"
// @Param startCreatedAt query string false "开始创建时间"
// @Param endCreatedAt query string false "结束创建时间"
// @Success 200 {object} dtos.PageResponse{list=[]dtos.SysAdminResponse} "管理员列表"
// @Router /sys/sysAdmins [get]
func GetSysAdmins(c *gin.Context) {
	var req dtos.SysAdminSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	db := global.DB.Model(&models.SysAdmin{})

	if req.Id > 0 {
		db = db.Where("id = ?", req.Id)
	}
	if req.Username != "" {
		db = db.Where("username like ?", fmt.Sprintf("%%%s%%", req.Username))
	}
	if req.Name != "" {
		db = db.Where("name like ?", fmt.Sprintf("%%%s%%", req.Name))
	}
	if req.Phone != "" {
		db = db.Where("phone like ?", fmt.Sprintf("%%%s%%", req.Phone))
	}
	if req.Status != "" {
		db = db.Where("status = ?", req.Status)
	}
	if req.StartCreatedAt != nil {
		db = db.Where("created_at >= ?", req.StartCreatedAt)
	}
	if req.EndCreatedAt != nil {
		db = db.Where("created_at <= ?", req.EndCreatedAt)
	}

	if req.Sort == "idDesc" {
		db = db.Order("id desc")
	} else {
		db = db.Order("id asc")
	}

	db = db.Preload("Roles").Preload("Avatar")

	var pageResponse dtos.PageResponse
	var admins []models.SysAdmin

	module.Paginate(db, req.Page, req.PageSize, &admins, &(pageResponse.Pagination))

	var dtoList []dtos.SysAdminResponse
	utils.CopyObject(&admins, &dtoList)

	pageResponse.List = dtoList

	module.SendSuccessResponse(c, "", pageResponse)
}

// @Tags Sys管理员管理
// @Summary 获取管理员信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.SysAdminResponse "管理员信息"
// @Router /sys/sysAdmins/{id} [get]
func GetSysAdmin(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var admin models.SysAdmin
	if result := global.DB.Where("id = ?", id).Preload("Roles").Preload("Avatar").First(&admin); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.SysAdminResponse
	utils.CopyObject(&admin, &dto)

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Sys管理员管理
// @Summary 创建管理员信息
// @Produce json
// @Param body body dtos.SysAdminRequest true "管理员信息"
// @Success 200 {object} dtos.SysAdminResponse "管理员信息"
// @Router /sys/sysAdmins [post]
func CreateSysAdmin(c *gin.Context) {
	var req dtos.SysAdminRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var admin models.SysAdmin
	utils.CopyObject(&req, &admin)

	global.DB.Create(&admin)

	var roles []models.SysRole
	if result := global.DB.Where("id in ?", req.RoleIds).Find(&roles); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	global.DB.Model(&admin).Association("Roles").Replace(roles)

	var dto dtos.SysAdminResponse
	utils.CopyObject(&admin, &dto)

	module.SendSuccessResponse(c, "创建成功", dto)
}

// @Tags Sys管理员管理
// @Summary 更新管理员信息
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.SysAdminRequest true "管理员信息"
// @Success 200 {object} dtos.SysAdminResponse "管理员信息"
// @Router /sys/sysAdmins/{id} [put]
func UpdateSysAdmin(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.SysAdminRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var admin models.SysAdmin
	if result := global.DB.Where("id = ?", id).First(&admin); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	utils.CopyObject(&req, &admin)

	db := global.DB
	if admin.Password == "" {
		db = db.Omit("Password")
	}
	db.Save(&admin)

	var roles []models.SysRole
	if result := global.DB.Where("id in ?", req.RoleIds).Find(&roles); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	global.DB.Model(&admin).Association("Roles").Replace(roles)

	GetSysAdmin(c)
}

// @Tags Sys管理员管理
// @Summary 删除管理员信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.BaseResponse "删除结果"
// @Router /sys/sysAdmins/{id} [delete]
func DeletedSysAdmin(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	if result := global.DB.Where("id = ?", id).Delete(&models.SysAdmin{}); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	module.SendSuccessResponse(c, "删除成功", nil)
}

// @Tags Sys管理员管理
// @Summary 获取我的信息
// @Produce json
// @Success 200 {object} dtos.SysAdminResponse "我的信息"
// @Router /sys/my [get]
func GetMySysAdmin(c *gin.Context) {
	id := c.MustGet("adminId").(uint)

	var admin models.SysAdmin
	if result := global.DB.Where("id = ?", id).Preload("Avatar").First(&admin); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.SysAdminResponse
	utils.CopyObject(&admin, &dto)

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Sys管理员管理
// @Summary 更新我的信息
// @Produce json
// @Param body body dtos.SysAdminRequest true "我的信息"
// @Success 200 {object} dtos.SysAdminResponse "我的信息"
// @Router /sys/my [put]
func UpdateMySysAdmin(c *gin.Context) {
	id := c.MustGet("adminId").(uint)

	var req dtos.SysAdminRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var admin models.SysAdmin
	if result := global.DB.Where("id = ?", id).First(&admin); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	admin.Password = req.Password
	admin.Name = req.Name
	admin.AvatarId = req.AvatarId

	db := global.DB
	if admin.Password == "" {
		db = db.Omit("Password")
	}
	db.Save(&admin)

	GetMySysAdmin(c)
}
