package controller

import (
	"app/global"
	"app/models"
	"app/sys/dtos"
	"app/sys/module"
	"app/utils"
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// @Tags Sys产品分类
// @Summary 获取产品分类列表
// @Produce json
// @Success 200 {array} dtos.CategoryResponse "产品分类列表"
// @Router /sys/categorys [get]
func GetCategorys(c *gin.Context) {
	var categorys []models.Category

	global.DB.Model(&models.Category{}).Order("id asc").Preload("Image").Find(&categorys)

	var dtoList []dtos.CategoryResponse
	utils.CopyObject(&categorys, &dtoList)

	module.SendSuccessResponse(c, "", dtoList)
}

// @Tags Sys产品分类
// @Summary 获取产品分类信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.CategoryResponse "产品分类信息"
// @Router /sys/categorys/{id} [get]
func GetCategory(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var category models.Category
	if result := global.DB.Where("id = ?", id).Preload("Image").First(&category); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.CategoryResponse
	utils.CopyObject(&category, &dto)

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Sys产品分类
// @Summary 创建产品分类信息
// @Produce json
// @Param body body dtos.CategoryRequest true "产品分类信息"
// @Success 200 {object} dtos.CategoryResponse "产品分类信息"
// @Router /sys/categorys [post]
func CreateCategory(c *gin.Context) {
	var req dtos.CategoryRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var category models.Category
	utils.CopyObject(&req, &category)

	if req.ParentId != nil {
		var parentCategory models.Category
		if result := global.DB.Where("id = ?", *req.ParentId).First(&parentCategory); result.Error != nil {
			module.SendErrorBadRequestResponse(c, result.Error)
			return
		}

		if parentCategory.ParentIds != "" {
			category.ParentIds = fmt.Sprintf("%s%d,", parentCategory.ParentIds, parentCategory.Id)
		} else {
			category.ParentIds = fmt.Sprintf(",%d,", parentCategory.Id)
		}
	}

	global.DB.Create(&category)

	var dto dtos.CategoryResponse
	utils.CopyObject(&category, &dto)

	module.SendSuccessResponse(c, "创建成功", dto)
}

// @Tags Sys产品分类
// @Summary 更新产品分类信息
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.CategoryRequest true "产品分类信息"
// @Success 200 {object} dtos.CategoryResponse "产品分类信息"
// @Router /sys/categorys/{id} [put]
func UpdateCategory(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.CategoryRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var category models.Category
	if result := global.DB.Where("id = ?", id).First(&category); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	category.Name = req.Name
	category.ImageId = req.ImageId
	global.DB.Save(&category)

	GetCategory(c)
}

// @Tags Sys产品分类
// @Summary 删除产品分类信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.BaseResponse "删除结果"
// @Router /sys/categorys/{id} [delete]
func DeletedCategory(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var category models.Category
	if result := global.DB.Where("id = ?", id).First(&category); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var parentIds string
	if category.ParentIds != "" {
		parentIds = fmt.Sprintf("%s%d,", category.ParentIds, category.Id)
	} else {
		parentIds = fmt.Sprintf(",%d,", category.Id)
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		if result := tx.Where("id = ?", id).Delete(&models.Category{}); result.Error != nil {
			return result.Error
		}

		if result := tx.Where("parent_ids like ?", fmt.Sprintf("%s%%", parentIds)).Delete(&models.Category{}); result.Error != nil {
			return result.Error
		}

		return nil
	})

	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	module.SendSuccessResponse(c, "删除成功", nil)
}
