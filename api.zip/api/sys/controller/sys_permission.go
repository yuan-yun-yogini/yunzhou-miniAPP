package controller

import (
	"app/global"
	"app/models"
	"app/sys/dtos"
	"app/sys/module"
	"app/utils"

	"github.com/gin-gonic/gin"
)

// @Tags Sys角色管理
// @Summary 获取权限列表
// @Produce json
// @Success 200 {array} dtos.SysPermissionResponse "权限列表"
// @Router /sys/sysPermissions [get]
func GetSysPermissions(c *gin.Context) {
	var permissions []models.SysPermission
	if result := global.DB.Order("group_name asc").Find(&permissions); result.Error != nil {
		module.SendErrorInternalServerResponse(c, result.Error)
		return
	}

	var dtoList []dtos.SysPermissionResponse
	utils.CopyObject(&permissions, &dtoList)

	module.SendSuccessResponse(c, "", dtoList)
}
