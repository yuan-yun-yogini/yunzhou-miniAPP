package controller

import (
	"app/global"
	"app/models"
	"app/sys/dtos"
	"app/sys/module"
	"app/utils"
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
)

// @Tags Sys广告管理
// @Summary 获取广告列表
// @Produce json
// @Param page query int false "页码"
// @Param pageSize query int false "页条数"
// @Param sort query string false "排序"
// @Param id query int false "id"
// @Param type query string false "类型"
// @Param name query string false "名称"
// @Success 200 {object} dtos.PageResponse{list=[]dtos.BannerResponse} "广告列表"
// @Router /sys/banners [get]
func GetBanners(c *gin.Context) {
	var req dtos.BannerSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	db := global.DB.Model(&models.Banner{})

	if req.Id > 0 {
		db = db.Where("id = ?", req.Id)
	}
	if req.Type != "" {
		db = db.Where("type = ?", req.Type)
	}
	if req.Name != "" {
		db = db.Where("name like ?", fmt.Sprintf("%%%s%%", req.Name))
	}
	if req.Status != "" {
		db = db.Where("status = ?", req.Status)
	}

	db = db.Order("type asc,sort desc")
	db = db.Preload("Image")

	var pageResponse dtos.PageResponse
	var banners []models.Banner

	module.Paginate(db, req.Page, req.PageSize, &banners, &(pageResponse.Pagination))

	var dtoList []dtos.BannerResponse
	utils.CopyObject(&banners, &dtoList)

	pageResponse.List = dtoList

	module.SendSuccessResponse(c, "", pageResponse)
}

// @Tags Sys广告管理
// @Summary 获取广告信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.BannerResponse "广告信息"
// @Router /sys/banners/{id} [get]
func GetBanner(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var banner models.Banner
	if result := global.DB.Where("id = ?", id).Preload("Image").First(&banner); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.BannerResponse
	utils.CopyObject(&banner, &dto)

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Sys广告管理
// @Summary 创建广告信息
// @Produce json
// @Param body body dtos.BannerRequest true "广告信息"
// @Success 200 {object} dtos.BannerResponse "广告信息"
// @Router /sys/banners [post]
func CreateBanner(c *gin.Context) {
	var req dtos.BannerRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var banner models.Banner
	utils.CopyObject(&req, &banner)

	global.DB.Create(&banner)

	var dto dtos.BannerResponse
	utils.CopyObject(&banner, &dto)

	module.SendSuccessResponse(c, "创建成功", dto)
}

// @Tags Sys广告管理
// @Summary 更新广告信息
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.BannerRequest true "广告信息"
// @Success 200 {object} dtos.BannerResponse "广告信息"
// @Router /sys/banners/{id} [put]
func UpdateBanner(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.BannerRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var banner models.Banner
	if result := global.DB.Where("id = ?", id).First(&banner); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	utils.CopyObject(&req, &banner)
	global.DB.Save(&banner)

	GetBanner(c)
}

// @Tags Sys广告管理
// @Summary 删除广告信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.BaseResponse "删除结果"
// @Router /sys/banners/{id} [delete]
func DeletedBanner(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	if result := global.DB.Where("id = ?", id).Delete(&models.Banner{}); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	module.SendSuccessResponse(c, "删除成功", nil)
}
