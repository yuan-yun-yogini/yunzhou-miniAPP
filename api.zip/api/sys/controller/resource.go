package controller

import (
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"app/sys/dtos"
	"app/sys/module"
	"app/utils"
	"fmt"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
)

// @Tags Sys资源管理
// @Summary 获取资源列表
// @Produce json
// @Param page query int false "页码"
// @Param pageSize query int false "页条数"
// @Param sort query string false "排序"
// @Param id query int false "id"
// @Param type query string false "类型"
// @Param name query string false "名称"
// @Success 200 {object} dtos.PageResponse{list=[]dtos.ResourceResponse} "资源列表"
// @Router /sys/resources [get]
func GetResources(c *gin.Context) {
	var req dtos.ResourceSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	db := global.DB.Model(&models.Resource{})

	if req.Id > 0 {
		db = db.Where("id = ?", req.Id)
	}
	if req.Type != "" {
		db = db.Where("type = ?", req.Type)
	}
	if req.Name != "" {
		db = db.Where("name like ?", fmt.Sprintf("%%%s%%", req.Name))
	}
	if req.Status != "" {
		db = db.Where("status = ?", req.Status)
	}

	db = db.Order("id desc")

	var pageResponse dtos.PageResponse
	var resources []models.Resource

	module.Paginate(db, req.Page, req.PageSize, &resources, &(pageResponse.Pagination))

	var dtoList []dtos.ResourceResponse
	utils.CopyObject(&resources, &dtoList)

	pageResponse.List = dtoList

	module.SendSuccessResponse(c, "", pageResponse)
}

// @Tags Sys资源管理
// @Summary 获取资源信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.ResourceResponse "资源信息"
// @Router /sys/resources/{id} [get]
func GetResource(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var resource models.Resource
	if result := global.DB.Where("id = ?", id).First(&resource); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.ResourceResponse
	utils.CopyObject(&resource, &dto)

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Sys资源管理
// @Summary 创建资源信息
// @Produce json
// @Param body body dtos.ResourceRequest true "资源信息"
// @Success 200 {object} dtos.ResourceResponse "资源信息"
// @Router /sys/resources [post]
func CreateResource(c *gin.Context) {
	var req dtos.ResourceRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	if req.Name == "" {
		module.SendFailBadRequestResponse(c, "请输入资源名称")
		return
	}

	if req.Type == "" {
		module.SendFailBadRequestResponse(c, "请选择资源类型")
		return
	}

	var r models.Resource
	if result := global.DB.Where("name = ?", req.Name).First(&r); result.Error == nil {
		module.SendFailBadRequestResponse(c, "资源名称已存在")
		return
	}

	var resource models.Resource
	resource.Acl = config.AclPrivate
	resource.Name = req.Name
	resource.Type = req.Type
	resource.Status = config.ResourceStatusPending

	if req.Ext != "" {
		if req.Ext[0:1] != "." {
			resource.Ext = "." + req.Ext
		} else {
			resource.Ext = req.Ext
		}
	}

	adminId := c.MustGet("adminId").(uint)
	path := "files/"
	switch req.Type {
	case config.ResourceTypeVideo:
		path = "videos/"
	case config.ResourceTypeAudio:
		path = "audios/"
	case config.ResourceTypeDocument:
		path = "docs/"
	}
	resource.Filename = fmt.Sprintf("%s%s%09d%d%s", path, time.Now().Format("20060102150405"), time.Now().Nanosecond(), adminId, resource.Ext)

	global.DB.Create(&resource)

	var dto dtos.ResourceResponse
	utils.CopyObject(&resource, &dto)

	module.SendSuccessResponse(c, "创建成功", dto)
}

// @Tags Sys资源管理
// @Summary 更新资源信息
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.ResourceRequest true "资源信息"
// @Success 200 {object} dtos.ResourceResponse "资源信息"
// @Router /sys/resources/{id} [put]
func UpdateResource(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.ResourceRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	if req.Name != "" {
		var r models.Resource
		if result := global.DB.Where("name = ?", req.Name).Where("id <> ?", id).First(&r); result.Error == nil {
			module.SendFailBadRequestResponse(c, "资源名称已存在")
			return
		}
	}

	var resource models.Resource
	if result := global.DB.Where("id = ?", id).First(&resource); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	if req.Name != "" {
		resource.Name = req.Name
	}
	if req.Type != "" {
		resource.Type = req.Type
	}
	if req.Ext != "" {
		if req.Ext[0:1] != "." {
			resource.Ext = "." + req.Ext
		} else {
			resource.Ext = req.Ext
		}
	}
	if req.Status != "" && req.Status != resource.Status {
		if req.Status != config.ResourceStatusEnable && req.Status != config.ResourceStatusDisable {
			module.SendFailBadRequestResponse(c, "状态异常")
			return
		}

		//上传成功
		if resource.Status == config.ResourceStatusPending {
			info, err := service.GetUploadFileInfo(resource.Filename, resource.Acl)
			if err != nil {
				module.SendErrorInternalServerResponse(c, err)
				return
			}

			resource.Size = info.ContentLength
			resource.Hash = info.Hash
		}

		resource.Status = req.Status
	}

	global.DB.Save(&resource)

	GetResource(c)
}

// @Tags Sys资源管理
// @Summary 获取资源上传信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.ResourceResponse "资源上传信息"
// @Router /sys/resourcesUpload/{id} [get]
func GetResourcesUpload(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var resource models.Resource
	if result := global.DB.Where("id = ?", id).First(&resource); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	if resource.Status != config.ResourceStatusPending {
		module.SendFailBadRequestResponse(c, "资源已上传过")
		return
	}

	var dto dtos.ResourceResponse
	utils.CopyObject(&resource, &dto)

	url, err := service.CreateUploadFileUrl(resource.Filename, resource.Acl)
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	dto.Url = url

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Sys资源管理
// @Summary 获取资源下载信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.ResourceResponse "资源下载信息"
// @Router /sys/resourcesDownload/{id} [get]
func GetResourcesDownload(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var resource models.Resource
	if result := global.DB.Where("id = ?", id).First(&resource); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	if resource.Status == config.ResourceStatusPending {
		module.SendFailBadRequestResponse(c, "资源还未上传")
		return
	}

	var dto dtos.ResourceResponse
	utils.CopyObject(&resource, &dto)

	url, err := service.GetUploadFileUrl(resource.Filename, resource.Acl)
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	dto.Url = url

	module.SendSuccessResponse(c, "", dto)
}
