package controller

import (
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"app/sys/dtos"
	"app/sys/module"
	"app/utils"
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// @Tags Sys产品管理
// @Summary 获取产品列表
// @Produce json
// @Param page query int false "页码"
// @Param pageSize query int false "页条数"
// @Param sort query string false "排序"
// @Param id query int false "id"
// @Param categoryId query int false "分类id"
// @Param name query string false "名称"
// @Param status query string false "状态"
// @Param startOnlineTime query string false "开始上架时间"
// @Param endOnlineTime query string false "结束上架时间"
// @Success 200 {object} dtos.PageResponse{list=[]dtos.ProductListResponse} "产品列表"
// @Router /sys/products [get]
func GetProducts(c *gin.Context) {
	var req dtos.ProductSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	db := global.DB.Model(&models.Product{})

	if req.Id > 0 {
		db = db.Where("id = ?", req.Id)
	}
	if req.CategoryId > 0 {
		db = db.Where("category_id = ?", req.CategoryId)
	}
	if req.Name != "" {
		db = db.Where("name like ?", fmt.Sprintf("%%%s%%", req.Name))
	}
	if req.Status != "" {
		db = db.Where("status = ?", req.Status)
	}
	if req.StartOnlineTime != nil {
		db = db.Where("online_time >= ?", req.StartOnlineTime)
	}
	if req.EndOnlineTime != nil {
		db = db.Where("online_time <= ?", req.EndOnlineTime)
	}

	db = db.Order("sort desc,id desc")

	db = db.Preload("Category").Preload("Image")

	var pageResponse dtos.PageResponse
	var products []models.Product

	module.Paginate(db, req.Page, req.PageSize, &products, &(pageResponse.Pagination))

	var dtoList []dtos.ProductListResponse
	utils.CopyObject(&products, &dtoList)

	pageResponse.List = dtoList

	module.SendSuccessResponse(c, "", pageResponse)
}

// @Tags Sys产品管理
// @Summary 获取产品信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.ProductResponse "产品信息"
// @Router /sys/products/{id} [get]
func GetProduct(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var product models.Product
	if result := global.DB.Where("id = ?", id).Preload("Category").Preload("Image").First(&product); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.ProductResponse
	utils.CopyObject(&product, &dto)

	if product.ResourceIds != "" {
		dto.ResourceIds = utils.SplitToUintSlice(product.ResourceIds, ",")
	} else {
		dto.ResourceIds = []uint{}
	}

	if product.ImageIds != "" {
		imageList := service.LoadImageListWithIds([]string{product.ImageIds})
		utils.CopyObject(&imageList[0], &dto.Images)
	}

	if product.DetailImageIds != "" {
		imageList := service.LoadImageListWithIds([]string{product.DetailImageIds})
		utils.CopyObject(&imageList[0], &dto.DetailImages)
	}

	var specs []models.ProductSpec
	global.DB.Where("product_id = ?", product.Id).Order("id asc").Find(&specs)

	specDtos := []dtos.ProductSpecResponse{}
	for _, item := range specs {
		specDto := dtos.ProductSpecResponse{
			Name: item.Name,
		}

		json.Unmarshal([]byte(item.Attrs), &specDto.Attrs)
		specDtos = append(specDtos, specDto)
	}

	dto.Specs = specDtos

	var specAttrs []models.ProductSpecAttr
	global.DB.Where("product_id = ?", product.Id).Preload("Image").Order("id asc").Find(&specAttrs)
	utils.CopyObject(&specAttrs, &dto.SpecAttrs)

	for i, item := range specAttrs {
		if item.ResourceIds != "" {
			dto.SpecAttrs[i].ResourceIds = utils.SplitToUintSlice(item.ResourceIds, ",")
		} else {
			dto.SpecAttrs[i].ResourceIds = []uint{}
		}
	}

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Sys产品管理
// @Summary 创建产品信息
// @Produce json
// @Param body body dtos.ProductRequest true "产品信息"
// @Success 200 {object} dtos.ProductResponse "产品信息"
// @Router /sys/products [post]
func CreateProduct(c *gin.Context) {
	var req dtos.ProductRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var category models.Category
	if result := global.DB.Where("id = ?", req.CategoryId).First(&category); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var product models.Product
	utils.CopyObject(&req, &product)

	if category.ParentIds != "" {
		product.CategoryIds = fmt.Sprintf("%s%d,", category.ParentIds, category.Id)
	} else {
		product.CategoryIds = fmt.Sprintf(",%d,", category.Id)
	}

	product.ResourceIds = utils.JoinFromUintSlice(req.ResourceIds, ",")
	product.ImageIds = utils.JoinFromUintSlice(req.ImageIds, ",")
	product.DetailImageIds = utils.JoinFromUintSlice(req.DetailImageIds, ",")

	if product.Status == config.ProductStatusOnline {
		onlineTime := time.Now()
		product.OnlineTime = &onlineTime
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		tx.Create(&product)

		if len(req.Specs) > 0 && len(req.SpecAttrs) > 0 {
			for _, item := range req.Specs {
				attrs, _ := json.Marshal(&item.Attrs)
				tx.Create(&models.ProductSpec{
					ProductId: product.Id,
					Name:      item.Name,
					Attrs:     string(attrs),
				})
			}

			for _, item := range req.SpecAttrs {
				var specAttr models.ProductSpecAttr
				utils.CopyObject(&item, &specAttr)
				specAttr.ProductId = product.Id
				specAttr.ResourceIds = utils.JoinFromUintSlice(item.ResourceIds, ",")
				tx.Create(&specAttr)
			}
		}

		return nil
	})

	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	var dto dtos.ProductResponse
	utils.CopyObject(&product, &dto)

	module.SendSuccessResponse(c, "创建成功", dto)
}

// @Tags Sys产品管理
// @Summary 更新产品信息
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.ProductRequest true "产品信息"
// @Success 200 {object} dtos.ProductResponse "产品信息"
// @Router /sys/products/{id} [put]
func UpdateProduct(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.ProductRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var product models.Product
	if result := global.DB.Where("id = ?", id).First(&product); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	if req.CategoryId != product.CategoryId {
		var category models.Category
		if result := global.DB.Where("id = ?", req.CategoryId).First(&category); result.Error != nil {
			module.SendErrorBadRequestResponse(c, result.Error)
			return
		}

		if category.ParentIds != "" {
			product.CategoryIds = fmt.Sprintf("%s%d,", category.ParentIds, category.Id)
		} else {
			product.CategoryIds = fmt.Sprintf(",%d,", category.Id)
		}
	}

	if req.Status != product.Status && req.Status == config.ProductStatusOnline {
		onlineTime := time.Now()
		product.OnlineTime = &onlineTime
	}

	utils.CopyObject(&req, &product)

	product.ResourceIds = utils.JoinFromUintSlice(req.ResourceIds, ",")
	product.ImageIds = utils.JoinFromUintSlice(req.ImageIds, ",")
	product.DetailImageIds = utils.JoinFromUintSlice(req.DetailImageIds, ",")

	//查找现有规格进行比对，并进行增加,修改,删除处理
	var specs []models.ProductSpec
	global.DB.Where("product_id = ?", product.Id).Find(&specs)

	specMap := map[string]models.ProductSpec{}
	for _, item := range specs {
		specMap[item.Name] = item
	}

	specCreates := []models.ProductSpec{}
	specUpdates := []models.ProductSpec{}
	for _, item := range req.Specs {
		attrs, _ := json.Marshal(&item.Attrs)

		if v, ok := specMap[item.Name]; ok {
			utils.CopyObject(&item, &v)
			v.Attrs = string(attrs)
			specUpdates = append(specUpdates, v)
			delete(specMap, item.Name)
		} else {
			var spec models.ProductSpec
			utils.CopyObject(&item, &spec)
			spec.ProductId = product.Id
			spec.Attrs = string(attrs)
			specCreates = append(specCreates, spec)
		}
	}

	//查找现有规格属性进行比对，并进行增加,修改,删除处理
	var specAttrs []models.ProductSpecAttr
	global.DB.Where("product_id = ?", product.Id).Find(&specAttrs)

	specAttrMap := map[string]models.ProductSpecAttr{}
	for _, item := range specAttrs {
		specAttrMap[item.Name] = item
	}

	specAttrCreates := []models.ProductSpecAttr{}
	specAttrUpdates := []models.ProductSpecAttr{}
	for _, item := range req.SpecAttrs {
		if v, ok := specAttrMap[item.Name]; ok {
			utils.CopyObject(&item, &v)
			v.ResourceIds = utils.JoinFromUintSlice(item.ResourceIds, ",")
			specAttrUpdates = append(specAttrUpdates, v)
			delete(specAttrMap, item.Name)
		} else {
			var specAttr models.ProductSpecAttr
			utils.CopyObject(&item, &specAttr)
			specAttr.ProductId = product.Id
			specAttr.ResourceIds = utils.JoinFromUintSlice(item.ResourceIds, ",")
			specAttrCreates = append(specAttrCreates, specAttr)
		}
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		tx.Save(&product)

		for _, item := range specCreates {
			tx.Create(&item)
		}

		for _, item := range specUpdates {
			tx.Save(&item)
		}

		for _, v := range specMap {
			tx.Delete(&v)
		}

		for _, item := range specAttrCreates {
			tx.Create(&item)
		}

		for _, item := range specAttrUpdates {
			tx.Save(&item)
		}

		for _, v := range specAttrMap {
			tx.Delete(&v)
		}

		return nil
	})

	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	GetProduct(c)
}

// @Tags Sys产品管理
// @Summary 更新产品状态
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.ProductStatusRequest true "状态信息"
// @Success 200 {object} dtos.BaseResponse "更新结果"
// @Router /sys/productsStatus/{id} [put]
func UpdateProductStatus(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.ProductStatusRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var product models.Product
	if result := global.DB.Where("id = ?", id).First(&product); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	if req.Status != product.Status && req.Status == config.ProductStatusOnline {
		onlineTime := time.Now()
		product.OnlineTime = &onlineTime
	}

	product.Status = req.Status

	global.DB.Select("Status", "OnlineTime").Save(&product)

	module.SendSuccessResponse(c, "更新成功", nil)
}

// @Tags Sys产品管理
// @Summary 删除产品信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.BaseResponse "删除结果"
// @Router /sys/products/{id} [delete]
func DeletedProduct(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		if result := tx.Where("id = ?", id).Delete(&models.Product{}); result.Error != nil {
			return result.Error
		}

		if result := tx.Where("product_id = ?", id).Delete(&models.ProductSpec{}); result.Error != nil {
			return result.Error
		}

		if result := tx.Where("product_id = ?", id).Delete(&models.ProductSpecAttr{}); result.Error != nil {
			return result.Error
		}

		return nil
	})

	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	module.SendSuccessResponse(c, "删除成功", nil)
}
