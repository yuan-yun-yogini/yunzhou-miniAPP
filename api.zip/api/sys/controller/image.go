package controller

import (
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"app/sys/dtos"
	"app/sys/module"
	"app/utils"
	"image"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"log"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

// @Tags Sys图片管理
// @Summary 获取图片列表
// @Produce json
// @Param page query int false "页码"
// @Param pageSize query int false "页条数"
// @Param sort query string false "排序"
// @Param id query int false "id"
// @Param hash query string false "哈希"
// @Success 200 {object} dtos.PageResponse{list=[]dtos.ImageResponse} "图片列表"
// @Router /sys/images [get]
func GetImages(c *gin.Context) {
	var req dtos.ImageSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	db := global.DB.Model(&models.Image{})

	if req.Id > 0 {
		db = db.Where("id = ?", req.Id)
	}
	if req.Hash != "" {
		db = db.Where("hash = ?", req.Hash)
	}

	if req.Sort == "idDesc" {
		db = db.Order("id desc")
	} else {
		db = db.Order("id asc")
	}

	var pageResponse dtos.PageResponse
	var images []models.Image

	module.Paginate(db, req.Page, req.PageSize, &images, &(pageResponse.Pagination))

	var dtoList []dtos.ImageResponse
	utils.CopyObject(&images, &dtoList)

	pageResponse.List = dtoList

	module.SendSuccessResponse(c, "", pageResponse)
}

// @Tags Sys图片管理
// @Summary 获取图片信息
// @Produce json
// @Param id path int true "Id"
// @Success 200 {object} dtos.ImageResponse "用户信息"
// @Router /sys/images/{id} [get]
func GetImage(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var img models.Image
	if result := global.DB.Where("id = ?", id).First(&img); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.ImageResponse
	utils.CopyObject(&img, &dto)

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Sys图片管理
// @Summary 创建图片
// @Produce json
// @Param file formData file true "图片"
// @Success 200 {object} dtos.ImageResponse "图片信息"
// @Router /sys/images [post]
func CreateImage(c *gin.Context) {
	file, err := c.FormFile("file")
	if err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}
	log.Println(file.Filename)

	// 验证文件扩展名
	ext := strings.ToLower(filepath.Ext(file.Filename))
	if ext != ".jpg" && ext != ".jpeg" && ext != ".png" {
		module.SendFailBadRequestResponse(c, "不支持的文件格式")
		return
	}

	// 验证图片大小
	if file.Size >= 2*1024*1024 {
		module.SendFailBadRequestResponse(c, "图片大小不能超过2MB")
		return
	}

	// 读取文件流
	reader, err := file.Open()
	if err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}
	defer reader.Close()

	imgConfig, _, err := image.DecodeConfig(reader)
	if err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	reader.Seek(0, io.SeekStart)
	hash := utils.Md5Reader(reader)

	var img models.Image
	if result := global.DB.Where("hash = ?", hash).Where("acl = ?", config.AclPublic).First(&img); result.Error != nil {
		reader.Seek(0, io.SeekStart)
		url, err1 := service.UploadPublicReader(reader, "images/"+hash+ext)
		if err1 != nil {
			module.SendErrorInternalServerResponse(c, err1)
			return
		}

		img = models.Image{
			Acl:    config.AclPublic,
			Type:   ext,
			Size:   uint(file.Size),
			Hash:   hash,
			Width:  imgConfig.Width,
			Height: imgConfig.Height,
			Url:    url,
		}

		global.DB.Create(&img)
	}

	dto := dtos.ImageResponse{}
	utils.CopyObject(&img, &dto)

	module.SendSuccessResponse(c, "上传成功", dto)
}
