package controller

import (
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"app/sys/dtos"
	"app/sys/module"
	"app/utils"
	"time"

	"github.com/gin-gonic/gin"
)

// @Tags Sys登录
// @Summary 登录
// @Produce json
// @Param body body dtos.SysAdminLoginRequest true "登录信息"
// @Success 200 {object} dtos.SysAdminLoginResponse "登录结果"
// @Router /sys/login [post]
func Login(c *gin.Context) {
	var req dtos.SysAdminLoginRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	if gin.Mode() != gin.DebugMode {
		if !service.VerifyCaptcha(req.CaptchaId, req.CaptchaAnswer) {
			module.SendFailBadRequestResponse(c, "验证码错误")
			return
		}
	}

	var admin models.SysAdmin
	if result := global.DB.Where("username = ?", req.Username).Preload("Roles.Permissions").Preload("Avatar").First(&admin); result.Error != nil {
		module.SendFailBadRequestResponse(c, "用户名或密码错误")
		return
	}

	if !admin.CheckPassword(req.Password) {
		module.SendFailBadRequestResponse(c, "用户名或密码错误")
		return
	}

	if admin.Status == config.CommonStatusDisable {
		module.SendFailForbiddenResponse(c, "用户已被禁用，请联系管理员")
	}

	roleIds := make([]uint, len(admin.Roles))
	for i, v := range admin.Roles {
		roleIds[i] = v.Id
	}

	token, expire, err := module.GenerateToken(admin.Id, admin.Type, roleIds)
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	admin.LoginIp = c.ClientIP()
	loginTime := time.Now()
	admin.LoginTime = &loginTime
	global.DB.Select("LoginIp", "LoginTime").Save(&admin)

	var adminDto dtos.SysAdminResponse
	utils.CopyObject(&admin, &adminDto)

	//加载权限
	permissionDtos := make([]dtos.SysPermissionResponse, 0)
	permissionMap := make(map[uint]bool)

	for _, role := range admin.Roles {
		for _, permission := range role.Permissions {
			if _, ok := permissionMap[permission.Id]; ok {
				continue
			}

			permissionMap[permission.Id] = true

			permissionDto := dtos.SysPermissionResponse{}
			utils.CopyObject(&permission, &permissionDto)
			permissionDtos = append(permissionDtos, permissionDto)
		}
	}

	if gin.Mode() == gin.DebugMode {
		c.SetCookie("token", token, int(expire.Unix()-time.Now().Unix()), "/", "localhost", false, false)
	}

	module.SendSuccessResponse(c, "", dtos.SysAdminLoginResponse{
		Token:       token,
		Expire:      uint(expire.UnixMilli()),
		Admin:       adminDto,
		Permissions: permissionDtos,
	})
}
