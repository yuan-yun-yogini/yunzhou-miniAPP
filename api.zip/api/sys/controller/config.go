package controller

import (
	"app/config"
	"app/global"
	"app/models"
	"app/sys/dtos"
	"app/sys/module"
	"app/utils"
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
)

// @Tags Sys配置管理
// @Summary 获取配置列表
// @Produce json
// @Param page query int false "页码"
// @Param pageSize query int false "页条数"
// @Param sort query string false "排序"
// @Param id query int false "id"
// @Param type query string false "类型"
// @Param name query string false "名称"
// @Success 200 {object} dtos.PageResponse{list=[]dtos.ConfigResponse} "配置列表"
// @Router /sys/configs [get]
func GetConfigs(c *gin.Context) {
	var req dtos.ConfigSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	db := global.DB.Model(&models.Config{})

	if req.Name != "" {
		db = db.Where("name like ?", fmt.Sprintf("%%%s%%", req.Name))
	}
	if req.ConfigKey != "" {
		db = db.Where("config_key like ?", fmt.Sprintf("%%%s%%", req.ConfigKey))
	}

	db = db.Order("config_key asc")

	var pageResponse dtos.PageResponse
	var configs []models.Config

	module.Paginate(db, req.Page, req.PageSize, &configs, &(pageResponse.Pagination))

	var dtoList []dtos.ConfigResponse
	utils.CopyObject(&configs, &dtoList)

	for i := range dtoList {
		if dtoList[i].Type == config.ConfigTypeImage && dtoList[i].ConfigValue != "" {
			imageId, _ := strconv.Atoi(dtoList[i].ConfigValue)

			var image models.Image
			global.DB.Where("id = ?", imageId).First(&image)

			imageDto := dtos.ImageResponse{}
			utils.CopyObject(&image, &imageDto)

			dtoList[i].Image = &imageDto
		}
	}

	pageResponse.List = dtoList

	module.SendSuccessResponse(c, "", pageResponse)
}

// @Tags Sys配置管理
// @Summary 获取配置信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.ConfigResponse "配置信息"
// @Router /sys/configs/{id} [get]
func GetConfig(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var model models.Config
	if result := global.DB.Where("id = ?", id).First(&model); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.ConfigResponse
	utils.CopyObject(&model, &dto)

	if dto.Type == config.ConfigTypeImage && dto.ConfigValue != "" {
		imageId, _ := strconv.Atoi(dto.ConfigValue)

		var image models.Image
		global.DB.Where("id = ?", imageId).First(&image)

		imageDto := dtos.ImageResponse{}
		utils.CopyObject(&image, &imageDto)

		dto.Image = &imageDto
	}

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Sys配置管理
// @Summary 更新配置信息
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.ConfigRequest true "配置信息"
// @Success 200 {object} dtos.ConfigResponse "配置信息"
// @Router /sys/configs/{id} [put]
func UpdateConfig(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.ConfigRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var model models.Config
	if result := global.DB.Where("id = ?", id).First(&model); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	utils.CopyObject(&req, &model)
	global.DB.Save(&model)

	GetConfig(c)
}
