package controller

import (
	"app/global"
	"app/models"
	"app/sys/dtos"
	"app/sys/module"
	"app/utils"
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// @Tags Sys角色管理
// @Summary 获取角色列表
// @Produce json
// @Param page query int false "页码"
// @Param pageSize query int false "页条数"
// @Param sort query string false "排序"
// @Param id query int false "id"
// @Param name query string false "名称"
// @Param status query string false "状态"
// @Param startCreatedAt query string false "开始创建时间"
// @Param endCreatedAt query string false "结束创建时间"
// @Success 200 {object} dtos.PageResponse{list=[]dtos.SysRoleResponse} "角色列表"
// @Router /sys/sysRoles [get]
func GetSysRoles(c *gin.Context) {
	var req dtos.SysRoleSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	db := global.DB.Model(&models.SysRole{})

	if req.Id > 0 {
		db = db.Where("id = ?", req.Id)
	}
	if req.Name != "" {
		db = db.Where("name like ?", fmt.Sprintf("%%%s%%", req.Name))
	}
	if req.Status != "" {
		db = db.Where("status = ?", req.Status)
	}
	if req.StartCreatedAt != nil {
		db = db.Where("created_at >= ?", req.StartCreatedAt)
	}
	if req.EndCreatedAt != nil {
		db = db.Where("created_at <= ?", req.EndCreatedAt)
	}

	if req.Sort == "idDesc" {
		db = db.Order("id desc")
	} else {
		db = db.Order("id asc")
	}

	var pageResponse dtos.PageResponse
	var roles []models.SysRole

	module.Paginate(db, req.Page, req.PageSize, &roles, &(pageResponse.Pagination))

	var dtoList []dtos.SysRoleResponse
	utils.CopyObject(&roles, &dtoList)

	pageResponse.List = dtoList

	module.SendSuccessResponse(c, "", pageResponse)
}

// @Tags Sys角色管理
// @Summary 获取角色信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.SysRoleResponse "角色信息"
// @Router /sys/sysRoles/{id} [get]
func GetSysRole(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var role models.SysRole
	if result := global.DB.Where("id = ?", id).First(&role); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.SysRoleResponse
	utils.CopyObject(&role, &dto)

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Sys角色管理
// @Summary 创建角色信息
// @Produce json
// @Param body body dtos.SysRoleRequest true "角色信息"
// @Success 200 {object} dtos.SysRoleResponse "角色信息"
// @Router /sys/sysRoles [post]
func CreateSysRole(c *gin.Context) {
	var req dtos.SysRoleRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var role models.SysRole
	utils.CopyObject(&req, &role)

	global.DB.Create(&role)

	var dto dtos.SysRoleResponse
	utils.CopyObject(&role, &dto)

	module.SendSuccessResponse(c, "创建成功", dto)
}

// @Tags Sys角色管理
// @Summary 更新角色信息
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.SysRoleRequest true "角色信息"
// @Success 200 {object} dtos.SysRoleResponse "角色信息"
// @Router /sys/sysRoles/{id} [put]
func UpdateSysRole(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.SysRoleRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var role models.SysRole
	if result := global.DB.Where("id = ?", id).First(&role); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	utils.CopyObject(&req, &role)
	global.DB.Save(&role)

	GetSysRole(c)
}

// @Tags Sys角色管理
// @Summary 删除角色信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.BaseResponse "删除结果"
// @Router /sys/sysRoles/{id} [delete]
func DeletedSysRole(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	if result := global.DB.Where("id = ?", id).Delete(&models.SysRole{}); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	module.SendSuccessResponse(c, "删除成功", nil)
}

// @Tags Sys角色管理
// @Summary 获取角色权限
// @Produce json
// @Param id path int true "id"
// @Success 200 {array} dtos.SysPermissionResponse "权限列表"
// @Router /sys/sysRolePermissions/{id} [get]
func GetSysRolePermissions(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var role models.SysRole

	if result := global.DB.Where("id = ?", id).Preload("Permissions", func(tx *gorm.DB) *gorm.DB {
		return tx.Order("group_name asc")
	}).First(&role); result.Error != nil {
		module.SendErrorInternalServerResponse(c, result.Error)
		return
	}

	dtoList := make([]dtos.SysPermissionResponse, len(role.Permissions))
	for i, item := range role.Permissions {
		utils.CopyObject(&item, &dtoList[i])
	}
	module.SendSuccessResponse(c, "", dtoList)
}

// @Tags Sys角色管理
// @Summary 更新角色权限
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.SysRolePermissionRequest true "角色权限信息"
// @Success 200 {object} dtos.BaseResponse "设置结果"
// @Router /sys/sysRolePermissions/{id} [put]
func UpdateSysRolePermissions(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.SysRolePermissionRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var role models.SysRole
	if result := global.DB.Where("id = ?", id).First(&role); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var permissions []models.SysPermission
	if result := global.DB.Where("id in ?", req.PermissionIds).Find(&permissions); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	global.DB.Model(&role).Association("Permissions").Replace(permissions)

	v0 := fmt.Sprintf("sys_%d", role.Id)

	//删除旧的权限
	global.CasbinEnforcer.RemoveFilteredPolicy(0, v0)

	//添加新权限
	var rules [][]string
	for _, item := range permissions {
		rules = append(rules, []string{v0, item.Path, item.Method})
	}
	global.CasbinEnforcer.AddPolicies(rules)

	module.SendSuccessResponse(c, "设置成功", nil)
}
