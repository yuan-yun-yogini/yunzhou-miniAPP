package utils

import (
	"regexp"

	"github.com/gin-gonic/gin/binding"
	"github.com/go-playground/validator/v10"
)

func InitValidator() {
	if v, ok := binding.Validator.Engine().(*validator.Validate); ok {
		v.RegisterValidation("phonenumber", phoneNumberValidator)
		v.RegisterValidation("username", usernameValidator)
		v.RegisterValidation("password", passwordValidator)
	}
}

func phoneNumberValidator(fl validator.FieldLevel) bool {
	phone := fl.Field().String()
	if phone == "" {
		return true
	}
	matched, _ := regexp.MatchString(`^1[3-9]\d{9}$`, phone)
	return matched
}

func usernameValidator(fl validator.FieldLevel) bool {
	username := fl.Field().String()
	if username == "" {
		return true
	}
	matched, _ := regexp.MatchString(`^[a-zA-Z]\w*$`, username)
	return matched
}

func passwordValidator(fl validator.FieldLevel) bool {
	password := fl.Field().String()
	if password == "" {
		return true
	}
	return len(password) >= 6
}
