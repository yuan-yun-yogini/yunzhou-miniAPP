package utils

import (
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"io"
	"math/rand"
	"os"
	"strconv"
	"strings"
	"time"
)

// 生成随机字符串
func GenerateRandomString(length int) string {
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	var letterRunes = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
	b := make([]rune, length)
	for i := range b {
		b[i] = letterRunes[r.Intn(len(letterRunes))]
	}
	return string(b)
}

// 复制对象
func CopyObject(src any, dest any) {
	data, err := json.Marshal(src)
	if err != nil {
		return
	}

	json.Unmarshal(data, dest)
}

// 整数字符串转数组
func SplitToUintSlice(s string, sep string) []uint {
	if s == "" {
		return []uint{}
	}

	strSlice := strings.Split(s, sep)
	nums := []uint{}

	for _, item := range strSlice {
		num, err := strconv.Atoi(item)
		if err != nil {
			return []uint{}
		}
		nums = append(nums, uint(num))
	}

	return nums
}

// 整数数组转字符串
func JoinFromUintSlice(nums []uint, sep string) string {
	strSlice := make([]string, len(nums))

	for i, num := range nums {
		strSlice[i] = strconv.Itoa(int(num))
	}

	return strings.Join(strSlice, sep)
}

// 数组去重
func UniqueSlice[T comparable](slice []T) []T {
	maps := make(map[T]bool)
	var res []T
	for _, value := range slice {
		if _, ok := maps[value]; !ok {
			maps[value] = true
			res = append(res, value)
		}
	}
	return res
}

func Md5String(data string) string {
	hash := md5.New()
	hash.Write([]byte(data))
	bytes := hash.Sum(nil)
	return hex.EncodeToString(bytes)
}

func Md5Reader(reader io.Reader) string {
	hash := md5.New()
	io.Copy(hash, reader)
	bytes := hash.Sum(nil)
	return hex.EncodeToString(bytes)
}

func Md5File(filepath string) (string, error) {
	file, err := os.Open(filepath)
	if err != nil {
		return "", err
	}

	defer file.Close()

	return Md5Reader(file), nil
}

func AnonymousName(name string) string {
	result := ""
	if name == "" {
		result += "***"
	} else {
		rs := []rune(name)
		result += string(rs[:1])
		result += "***"
		if len(rs) > 1 {
			result += string(rs[(len(rs) - 1):])
		}
	}
	return result
}

func AnonymousPhone(phone string) string {
	result := phone[:3]
	result += "****"
	result += phone[7:]
	return result
}

func SubstrRune(str string, startIndex int, endIndex int) string {
	if str == "" {
		return ""
	}

	if startIndex >= endIndex {
		return ""
	}

	rstr := []rune(str)
	l := len(rstr)

	if l <= startIndex {
		return ""
	}

	if l <= endIndex {
		return string(rstr[startIndex:])
	}

	return string(rstr[startIndex:endIndex])
}
