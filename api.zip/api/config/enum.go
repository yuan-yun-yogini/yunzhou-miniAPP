package config

// 通用状态
const (
	CommonStatusEnable  = "enable"  //启用
	CommonStatusDisable = "disable" //禁用
)

// 日志级别
const (
	LogLevelDebug = "debug" //调试
	LogLevelInfo  = "info"  //信息
	LogLevelWarn  = "warn"  //警告
	LogLevelError = "error" //错误
)

// 产品状态
const (
	ProductStatusPending = "pending" //待发布
	ProductStatusOnline  = "online"  //上架
	ProductStatusOffline = "offline" //下架
)

// 订单状态
const (
	OrderStatusPending   = "pending"   //待支付
	OrderStatusPaid      = "paid"      //已支付，待发货
	OrderStatusShipped   = "shipped"   //已发货，待收货
	OrderStatusDelivered = "delivered" //已送达，已收货
	OrderStatusCompleted = "completed" //已完成
	OrderStatusCanceled  = "canceled"  //已取消
)

// 订单快递状态
const (
	OrderExpressStatusShipped   = "shipped"   //已发货
	OrderExpressStatusDelivered = "delivered" //已收货
)

// 订单退款状态
const (
	OrderRefundStatusPending   = "pending"   //待退款
	OrderRefundStatusReject    = "reject"    //拒绝退款
	OrderRefundStatusRefunding = "refunding" //退款中
	OrderRefundStatusSuccess   = "success"   //退款成功
	OrderRefundStatusFail      = "fail"      //退款失败
)

// 订单评价状态
const (
	OrderEvaluateStatusEvaluated = "evaluated" //已评价
	OrderEvaluateStatusAppend    = "append"    //已追评
)

// 支付交易类型
const (
	PayTradeTypeOrder = "order" //订单
)

// 支付渠道
const (
	PayChannelWxH5    = "wxH5"    //微信网页支付
	PayChannelWxJsapi = "wxJsapi" //微信内部网页支付
	PayChannelWxMp    = "wxMp"    //微信小程序支付
)

// 支付状态
const (
	PayStatusPending  = "pending"  //待支付
	PayStatusPaid     = "paid"     //已支付
	PayStatusCanceled = "canceled" //已取消
)

// 退款状态
const (
	PayRefundStatusPending = "pending" //退款中
	PayRefundStatusSuccess = "success" //退款成功
	PayRefundStatusFail    = "fail"    //退款失败
)

// 管理员类型
const (
	SysAdminTypeSuper  = "super"  //超级管理员
	SysAdminTypeNormal = "normal" //普通管理员
)

// 访问权限
const (
	AclPrivate = "private" //私有
	AclPublic  = "public"  //公开
)

// banner类型
const (
	BannerTypeIndexTop1 = "indexTop1" //首页顶部1
	BannerTypeIndexTop2 = "indexTop2" //首页顶部2
)

// banner登录状态
const (
	BannerLoginStatusYes = "yes" //已登录
	BannerLoginStatusNo  = "no"  //未登录
)

// 配置类型
const (
	ConfigTypeNumber = "number" //数字
	ConfigTypeString = "string" //字符串
	ConfigTypeText   = "text"   //文本
	ConfigTypeHtml   = "html"   //html
	ConfigTypeAmount = "amount" //金额
	ConfigTypeImage  = "image"  //图片
)

// 定时任务执行类型
const (
	TimerExecuteTypeOrderCancel   = "orderCancel"   //订单取消
	TimerExecuteTypeOrderDeliver  = "orderDeliver"  //订单收货
	TimerExecuteTypeOrderComplete = "orderComplete" //订单完成
)

// 定时任务状态
const (
	TimerStatusPending   = "pending"   //待执行
	TimerStatusExecuting = "executing" //执行中
	TimerStatusSuccess   = "success"   //执行成功
	TimerStatusFail      = "fail"      //执行失败
)

// 资源类型
const (
	ResourceTypeVideo    = "video"    //视频
	ResourceTypeAudio    = "audio"    //音频
	ResourceTypeDocument = "document" //文档
	ResourceTypeFile     = "file"     //文件
)

// 资源状态
const (
	ResourceStatusPending = "pending" //待上传
	ResourceStatusEnable  = "enable"  //启用
	ResourceStatusDisable = "disable" //禁用
)
