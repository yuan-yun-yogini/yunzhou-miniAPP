package config

import "time"

const (
	CachePrefixCaptcha = "captcha"
)

type Cache interface {
	Set(key string, value any, expiration time.Duration) error
	Get(key string) (string, error)
	Del(key string) error
}
