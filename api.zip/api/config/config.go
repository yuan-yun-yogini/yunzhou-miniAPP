package config

// 系统配置结构
type AppConfig struct {
	Server   ServerConfig   `json:"server"`
	Database DatabaseConfig `json:"database"`
	Redis    RedisConfig    `json:"redis"`
	Crons    []CronConfig   `json:"crons"`
	Coses    []CosConfig    `json:"coses"`
	WxMp     WxMpConfig     `json:"wxMp"`
	Pays     []PayConfig    `json:"pays"`
	Modules  []ModuleConfig `json:"modules"`
}

// 服务器配置
type ServerConfig struct {
	Mode    string `json:"mode"`
	Port    int    `json:"port"`
	TlsCert string `json:"tlsCert"`
	TlsKey  string `json:"tlsKey"`
	Notify  string `json:"notify"`
}

// 数据库配置
type DatabaseConfig struct {
	DSN             string `json:"dsn"`
	MaxIdleConns    int    `json:"maxIdleConns"`
	MaxOpenConns    int    `json:"maxOpenConns"`
	ConnMaxLifetime int64  `json:"connMaxLifetime"`
}

// 缓存配置
type RedisConfig struct {
	Addr     string `json:"addr"`
	Password string `json:"password"`
	DB       int    `json:"db"`
}

// 定时器配置
type CronConfig struct {
	Name string `json:"name"`
	Time string `json:"time"`
}

// 腾讯云存储桶配置
type CosConfig struct {
	Name      string `json:"name"`
	Acl       string `json:"acl"`
	BucketUrl string `json:"bucketUrl"`
	SecretId  string `json:"secretId"`
	SecretKey string `json:"secretKey"`
	Domain    string `json:"domain"`
}

// 微信小程配置
type WxMpConfig struct {
	AppId          string `json:"appId"`
	AppSecret      string `json:"appSecret"`
	AccessTokenKey string `json:"accessTokenKey"`
	AccessTokenUrl string `json:"accessTokenUrl"`
}

//支付配置
type PayConfig struct {
	Channels   []string `json:"channels"`
	AppId      string   `json:"appId"`
	MchId      string   `json:"mchId"`
	MchKey     string   `json:"mchKey"`
	MchNo      string   `json:"mchNo"`
	PrivatePem string   `json:"privatePem"`
	PublicPem  string   `json:"publicPem"`
	PublicNo   string   `json:"publicNo"`
}

// JWT配置
type JWTConfig struct {
	Secret string `json:"secret"`
	Expiry int    `json:"expiry"`
}

// 模块配置
type ModuleConfig struct {
	Name    string    `json:"name"`
	IsStart bool      `json:"isStart"`
	JWT     JWTConfig `json:"jwt"`
}
