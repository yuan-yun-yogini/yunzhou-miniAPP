package global

func InitGlobal() {
	InitConfig()
	InitDatabase()
	InitRedis()
	InitCasbin()
}
