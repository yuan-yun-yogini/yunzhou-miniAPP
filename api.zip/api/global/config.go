package global

import (
	"app/config"
	"encoding/json"
	"log"
	"os"
)

var AppConfig *config.AppConfig

// 初始化配置
func InitConfig() {
	// 加载.env文件
	data, err := os.ReadFile(".env")
	if err != nil {
		panic("未找到.env文件,请配置")
	}

	var cfg config.AppConfig
	err = json.Unmarshal(data, &cfg)
	if err != nil {
		panic("配置错误")
	}

	log.Println("配置加载成功")

	AppConfig = &cfg
}
