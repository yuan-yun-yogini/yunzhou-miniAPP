package global

import (
	"log"
	"strings"

	"github.com/casbin/casbin/v3"
	gormadapter "github.com/casbin/gorm-adapter/v3"
)

var CasbinEnforcer *casbin.Enforcer

func InitCasbin() {
	adapter, err := gormadapter.NewAdapterByDB(DB)
	if err != nil {
		log.Fatal("Failed to create casbin adapter", err)
	}

	// 加载模型配置
	enforcer, err := casbin.NewEnforcer("rbac_model.conf", adapter)
	if err != nil {
		log.Fatal("Failed to create casbin enforcer", err)
	}

	enforcer.AddFunction("keyMatch", CasbinKeyMatchFunc)

	// 加载策略
	if err := enforcer.LoadPolicy(); err != nil {
		log.Fatal("Failed to load casbin policy", err)
	}

	log.Println("Casbin initialized successfully")

	CasbinEnforcer = enforcer
}

func CasbinKeyMatch(key1, key2 string) bool {
	i := strings.Index(key2, "*")
	if i == -1 {
		return key1 == key2
	}

	if len(key1) > i {
		return key1[:i] == key2[:i]
	}

	return key1 == key2[:i]
}

func CasbinKeyMatchFunc(args ...any) (interface{}, error) {
	name1 := args[0].(string)
	name2 := args[1].(string)

	return (bool)(CasbinKeyMatch(name1, name2)), nil
}
