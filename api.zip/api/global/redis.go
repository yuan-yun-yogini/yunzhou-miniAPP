package global

import (
	"app/config"
	"context"
	"time"

	"github.com/redis/go-redis/v9"
)

var Cache config.Cache
var Redis *redis.Client

type RedisCache struct {
}

func InitRedis() {
	cfg := AppConfig.Redis
	rdb := redis.NewClient(&redis.Options{
		Addr:     cfg.Addr,
		Password: cfg.Password,
		DB:       cfg.DB,
	})

	Redis = rdb

	Cache = RedisCache{}
}

func (c RedisCache) Set(key string, value any, expiration time.Duration) error {
	return Redis.Set(context.Background(), key, value, expiration).Err()
}

func (c RedisCache) Get(key string) (string, error) {
	value, err := Redis.Get(context.Background(), key).Result()
	if err != nil {
		return "", err
	}

	return value, nil
}

func (c RedisCache) Del(key string) error {
	return Redis.Del(context.Background(), key).Err()
}
