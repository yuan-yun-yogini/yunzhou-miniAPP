package models

import "time"

type Category struct {
	BaseModel
	ParentId  *uint  `json:"parentId" gorm:"default:null;comment:上级id"`
	ParentIds string `json:"parentIdStr" gorm:"size:255;comment:所有上级id,逗号分隔"`
	Name      string `json:"name" gorm:"size:50;not null;comment:名称"`
	ImageId   uint   `json:"imageId" gorm:"comment:图片id"`
	Image     Image  `json:"image" gorm:"foreignKey:ImageId"`
}

type Product struct {
	BaseModel
	CategoryId       uint              `json:"categoryId" gorm:"not null;comment:分类id"`
	CategoryIds      string            `json:"categoryIdStr" gorm:"size:255;comment:多级分类id"`
	ResourceIds      string            `json:"resourceIdStr" gorm:"size:255;comment:资源id,多个逗号分隔"`
	Sku              string            `json:"sku" gorm:"size:100;comment:sku"`
	Name             string            `json:"name" gorm:"size:100;not null;comment:名称"`
	ImageId          uint              `json:"imageId" gorm:"not null;comment:封面图片id"`
	ImageIds         string            `json:"imageIdStr" gorm:"size:255;not null;comment:图片id,多个逗号分隔"`
	DetailImageIds   string            `json:"detailImageIdStr" gorm:"size:255;comment:详情图片id,多个逗号分隔"`
	Description      string            `json:"description" gorm:"type:text;comment:描述"`
	OriginalPrice    uint              `json:"originalPrice" gorm:"not null;comment:原价"`
	Price            uint              `json:"price" gorm:"not null;comment:价格"`
	Stock            int               `json:"stock" gorm:"not null;comment:库存"`
	Flag             string            `json:"flag" gorm:"size:255;comment:标记"`
	Status           string            `json:"status" gorm:"size:50;not null;comment:状态"`
	OnlineTime       *time.Time        `json:"onlineTime" gorm:"comment:上架时间"`
	SalesVolumn      uint              `json:"salesVolumn" gorm:"default:0;comment:销量"`
	Sort             int               `json:"sort" gorm:"default:0;comment:排序"`
	Category         Category          `json:"category" gorm:"foreignKey:CategoryId"`
	Image            Image             `json:"image" gorm:"foreignKey:ImageId"`
	ProductSpecs     []ProductSpec     `json:"productSpecs" gorm:"foreignKey:ProductId"`
	ProductSpecAttrs []ProductSpecAttr `json:"productSpecAttrs" gorm:"foreignKey:ProductId"`
}

type ProductSpec struct {
	BaseModel
	ProductId uint   `json:"productId" gorm:"not null;comment:产品id"`
	Name      string `json:"name" gorm:"size:100;not null;comment:名称"`
	Attrs     string `json:"attrStr" gorm:"type:text;comment:属性"`
}

type ProductSpecAttr struct {
	BaseModel
	ProductId     uint   `json:"productId" gorm:"not null;comment:产品id"`
	ResourceIds   string `json:"resourceIdStr" gorm:"size:255;comment:资源id,多个逗号分隔"`
	Name          string `json:"name" gorm:"size:255;not null;comment:名称"`
	ImageId       uint   `json:"imageId" gorm:"comment:图片id"`
	OriginalPrice uint   `json:"originalPrice" gorm:"not null;comment:原价"`
	Price         uint   `json:"price" gorm:"not null;comment:价格"`
	Stock         int    `json:"stock" gorm:"not null;default:0;comment:库存"`
	Image         Image  `json:"image" gorm:"foreignKey:ImageId"`
}
