package models

type Banner struct {
	BaseModel
	Type        string `json:"type" gorm:"size:50;not null;comment:类型"`
	Name        string `json:"name" gorm:"size:50;not null;comment:名称"`
	ImageId     uint   `json:"imageId" gorm:"comment:图片id"`
	Url         string `json:"url" gorm:"size:255;comment:跳转地址"`
	Description string `json:"description" gorm:"type:text;comment:描述"`
	LoginStatus string `json:"loginStatus" gorm:"size:50;comment:登录状态"`
	Status      string `json:"status" gorm:"size:50;comment:状态"`
	Sort        int    `json:"sort" gorm:"default:0;comment:排序"`
	Image       Image  `json:"image" gorm:"foreignKey:ImageId"`
}
