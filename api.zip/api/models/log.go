package models

type Log struct {
	BaseModel
	Level   string `json:"level" gorm:"size:50;comment:等级"`
	Name    string `json:"name" gorm:"size:50;comment:名称"`
	Content string `json:"content" gorm:"type:text;comment:内容"`
}
