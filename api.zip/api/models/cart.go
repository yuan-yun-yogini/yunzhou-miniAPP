package models

type Cart struct {
	BaseModel
	UserId            uint             `json:"userId" gorm:"not null;comment:用户id"`
	ProductId         uint             `json:"productId" gorm:"not null;comment:产品id"`
	ProductSpecAttrId *uint            `json:"productSpecAttrId" gorm:"comment:产品规格属性id"`
	Quantity          uint             `json:"quantity" gorm:"not null;comment:数量"`
	User              User             `json:"user" gorm:"foreignKey:UserId"`
	Product           Product          `json:"product" gorm:"foreignKey:ProductId"`
	ProductSpecAttr   *ProductSpecAttr `json:"productSpecAttr" gorm:"foreignKey:ProductSpecAttrId"`
}
