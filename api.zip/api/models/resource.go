package models

type Resource struct {
	BaseModel
	Acl      string `json:"acl" gorm:"size:50;not null;comment:访问权限"`
	Name     string `json:"name" gorm:"unique;size:50;not null;comment:名称"`
	Type     string `json:"type" gorm:"size:50;not null;comment:类型"`
	Ext      string `json:"ext" gorm:"size:50;not null;comment:后缀"`
	Size     uint   `json:"size" gorm:"not null;comment:大小"`
	Hash     string `json:"hash" gorm:"index;size:100;not null;comment:哈希"`
	Attr     string `json:"attr" gorm:"size:255;comment:属性"`
	Filename string `json:"filename" gorm:"size:160;not null;comment:文件名"`
	Status   string `json:"status" gorm:"size:50;not null;comment:状态"`
}
