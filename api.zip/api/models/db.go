package models

import (
	"app/config"
	"app/global"
)

func DbMigrate() {
	migrateTable()
	migrateData()
}

func migrateTable() {
	global.DB.AutoMigrate(
		&User{},
		&Address{},
		&Resource{},
		&Category{},
		&Product{},
		&ProductSpec{},
		&ProductSpecAttr{},
		&Cart{},
		&Order{},
		&OrderProduct{},
		&OrderAddress{},
		&OrderExpress{},
		&OrderRefund{},
		&OrderProductEvaluate{},
		&Pay{},
		&PayRefund{},
		&Banner{},
		&Config{},
		&SysPermission{},
		&SysRole{},
		&SysAdmin{},
		&Image{},
		&Area{},
		&Log{},
		&Timer{},
	)
}

func migrateData() {
	initDataAdmin()
	initDataConfig()
}

func initDataAdmin() {
	var admin SysAdmin
	if result := global.DB.First(&admin); result.Error != nil {
		global.DB.Create(&SysAdmin{
			Type:     config.SysAdminTypeSuper,
			Username: "admin",
			Password: "123456",
			Name:     "admin",
			Status:   config.CommonStatusEnable,
		})
	}
}

func initDataConfig() {
	configs := []Config{
		{
			Acl:         config.AclPrivate,
			Type:        config.ConfigTypeNumber,
			Name:        "订单自动取消时间(秒)",
			Description: "未支付的订单超过一定时间则自动取消，释放库存",
			ConfigKey:   "orderCancelDuration",
			ConfigValue: "900",
		},
		{
			Acl:         config.AclPrivate,
			Type:        config.ConfigTypeNumber,
			Name:        "订单自动收货时间(天)",
			Description: "订单已发货后超过一定时间用户未确认收货，则自动收货",
			ConfigKey:   "orderDeliverDuration",
			ConfigValue: "10",
		},
		{
			Acl:         config.AclPrivate,
			Type:        config.ConfigTypeNumber,
			Name:        "订单自动完成时间(天)",
			Description: "订单确认收货后超过一定时间则自动完成订单，已完成的订单不可再进行售后",
			ConfigKey:   "orderCompleteDuration",
			ConfigValue: "15",
		},
		{
			Acl:         config.AclPublic,
			Type:        config.ConfigTypeNumber,
			Name:        "客服手机号",
			Description: "",
			ConfigKey:   "csPhone",
			ConfigValue: "",
		},
		{
			Acl:         config.AclPublic,
			Type:        config.ConfigTypeString,
			Name:        "客服微信号",
			Description: "",
			ConfigKey:   "csWxNo",
			ConfigValue: "",
		},
		{
			Acl:         config.AclPublic,
			Type:        config.ConfigTypeImage,
			Name:        "客服微信二维码",
			Description: "",
			ConfigKey:   "csWxCode",
			ConfigValue: "",
		},
		{
			Acl:         config.AclPublic,
			Type:        config.ConfigTypeHtml,
			Name:        "用户服务协议",
			Description: "",
			ConfigKey:   "userServiceProtocol",
			ConfigValue: "用户服务协议",
		},
		{
			Acl:         config.AclPublic,
			Type:        config.ConfigTypeHtml,
			Name:        "隐私保护协议",
			Description: "",
			ConfigKey:   "userPrivateProtocol",
			ConfigValue: "隐私保护协议",
		},
	}

	for _, item := range configs {
		var cfg Config
		if result := global.DB.Where("config_key = ?", item.ConfigKey).First(&cfg); result.Error != nil {
			global.DB.Create(&item)
		}
	}
}
