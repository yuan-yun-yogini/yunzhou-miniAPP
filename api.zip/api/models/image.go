package models

type Image struct {
	BaseModel
	Acl    string `json:"acl" gorm:"size:50;not null;comment:访问权限"`
	Type   string `json:"type" gorm:"size:50;not null;comment:类型"`
	Size   uint   `json:"size" gorm:"not null;comment:大小"`
	Hash   string `json:"hash" gorm:"index;size:100;not null;comment:哈希"`
	Width  int    `json:"width" gorm:"not null;comment:宽"`
	Height int    `json:"height" gorm:"not null;comment:高"`
	Url    string `json:"url" gorm:"size:255;comment:链接地址"`
}
