package models

import (
	"time"

	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

type User struct {
	BaseModel
	InviterId  *uint      `json:"inviterId" gorm:"default:null;comment:邀请人id"`
	Username   string     `json:"username" gorm:"unique;size:50;comment:用户名"`
	Password   string     `json:"password" gorm:"size:100;comment:密码"`
	Phone      string     `json:"phone" gorm:"size:20;comment:手机号"`
	Name       string     `json:"name" gorm:"size:50;comment:名称"`
	AvatarId   *uint      `json:"avatarId" gorm:"default:null;comment:头像id"`
	Status     string     `json:"status" gorm:"size:50;comment:状态"`
	Remark     string     `json:"remark" gorm:"size:255;comment:备注"`
	LoginToken string     `json:"token" gorm:"size:50;comment:登录token"`
	LoginIp    string     `json:"loginIp" gorm:"size:255;comment:登录ip"`
	LoginTime  *time.Time `json:"loginTime" gorm:"comment:登录时间"`
	Avatar     *Image     `json:"avatar" gorm:"foreignKey:AvatarId"`
	Addresses  []Address  `json:"addresses" gorm:"foreignKey:UserId"`
}

type Address struct {
	BaseModel
	UserId    uint   `json:"userId" gorm:"not null;comment:用户id"`
	Name      string `json:"name" gorm:"size:50;not null;comment:姓名"`
	Phone     string `json:"phone" gorm:"size:20;not null;comment:手机号"`
	Province  string `json:"province" gorm:"size:50;not null;comment:省"`
	City      string `json:"city" gorm:"size:50;not null;comment:市"`
	District  string `json:"district" gorm:"size:50;not null;comment:区县"`
	Detail    string `json:"detail" gorm:"size:255;not null;comment:详细地址"`
	IsDefault bool   `json:"isDefault" gorm:"default:false;comment:是否默认地址"`
}

func (u *User) BeforeSave(tx *gorm.DB) error {
	if u.Password != "" {
		hashedPassword, err := bcrypt.GenerateFromPassword([]byte(u.Password), bcrypt.DefaultCost)
		if err != nil {
			return err
		}
		u.Password = string(hashedPassword)
	}
	return nil
}

func (u *User) CheckPassword(password string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(u.Password), []byte(password))
	return err == nil
}
