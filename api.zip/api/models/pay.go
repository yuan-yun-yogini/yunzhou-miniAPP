package models

import (
	"time"
)

type Pay struct {
	BaseModel
	UserId       uint       `json:"userId" gorm:"not null;comment:用户id"`
	TradeType    string     `json:"orderType" gorm:"size:50;not null;comment:交易类型"`
	TradeId      uint       `json:"orderId" gorm:"index;not null;comment:交易id"`
	TradeNo      string     `json:"tradeNo" gorm:"unique;size:128;not null;comment:交易号"`
	Channel      string     `json:"channel" gorm:"size:50;not null;comment:支付渠道"`
	AppId        string     `json:"appId" gorm:"size:100;comment:应用id"`
	MchId        string     `json:"mchId" gorm:"size:100;comment:商户id"`
	Amount       uint       `json:"amount" gorm:"not null;comment:金额"`
	Title        string     `json:"title" gorm:"size:128;not null;comment:标题"`
	Description  string     `json:"description" gorm:"size:255;comment:描述"`
	OutTradeNo   string     `json:"outTradeNo" gorm:"size:128;comment:外部交易号"`
	PaidTime     *time.Time `json:"paidTime" gorm:"comment:支付时间"`
	RefundAmount uint       `json:"refundAmount" gorm:"not null;comment:退款金额"`
	RefundTime   *time.Time `json:"refundTime" gorm:"comment:退款时间"`
	Status       string     `json:"status" gorm:"size:50;not null;comment:状态"`
	User         User       `json:"user" gorm:"foreignKey:UserId"`
}

type PayRefund struct {
	BaseModel
	PayId       uint       `json:"payId" gorm:"not null;comment:支付id"`
	UserId      uint       `json:"userId" gorm:"not null;comment:用户id"`
	TradeNo     string     `json:"tradeNo" gorm:"unique;size:128;not null;comment:交易号"`
	Amount      uint       `json:"amount" gorm:"not null;comment:金额"`
	Title       string     `json:"title" gorm:"size:128;not null;comment:标题"`
	Description string     `json:"description" gorm:"size:255;comment:描述"`
	OutTradeNo  string     `json:"outTradeNo" gorm:"size:128;comment:外部交易号"`
	RefundTime  *time.Time `json:"refundTime" gorm:"comment:退款时间"`
	Status      string     `json:"status" gorm:"size:50;not null;comment:状态"`
	Pay         Pay        `json:"pay" gorm:"foreignKey:PayId"`
	User        User       `json:"user" gorm:"foreignKey:UserId"`
}
