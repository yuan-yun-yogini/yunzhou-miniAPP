package models

type Timer struct {
	BaseModel
	ExecuteType string `json:"executeType" gorm:"size:50;comment:执行类型"`
	ExecuteId   uint   `json:"executeId" gorm:"not null;comment:执行id"`
	ExecuteTime int64  `json:"executeTime" gorm:"index;not null;comment:执行时间"`
	StartTime   int64  `json:"startTime" gorm:"not null;default:0;comment:开始时间"`
	EndTime     int64  `json:"endTime" gorm:"not null;default:0;comment:结束时间"`
	Status      string `json:"status" gorm:"size:50;not null;comment:状态"`
	Remark      string `json:"remark" gorm:"size:255;not null;comment:备注"`
}
