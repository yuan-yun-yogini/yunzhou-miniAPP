package models

import (
	"time"

	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

type SysAdmin struct {
	BaseModel
	Type      string     `json:"type" gorm:"size:50;comment:类型"`
	Username  string     `json:"username" gorm:"unique;size:50;not null;comment:用户名"`
	Password  string     `json:"password" gorm:"size:100;not null;comment:密码"`
	Phone     string     `json:"phone" gorm:"size:20;comment:手机号"`
	Name      string     `json:"name" gorm:"size:50;comment:名称"`
	AvatarId  *uint      `json:"avatarId" gorm:"default:null;comment:头像id"`
	Status    string     `json:"status" gorm:"size:50;comment:状态"`
	Remark    string     `json:"remark" gorm:"size:255;comment:备注"`
	LoginIp   string     `json:"loginIp" gorm:"size:255;comment:登录ip"`
	LoginTime *time.Time `json:"loginTime" gorm:"comment:登录时间"`
	Avatar    *Image     `json:"avatar" gorm:"foreignKey:AvatarId"`
	Roles     []SysRole  `json:"roles" gorm:"many2many:sys_admin_roles;"`
}

type SysRole struct {
	BaseModel
	Name        string          `json:"name" gorm:"size:50;not null;comment:名称"`
	Description string          `json:"description" gorm:"size:255;comment:描述"`
	Status      string          `json:"status" gorm:"size:50;comment:状态"`
	Users       []SysAdmin      `json:"users" gorm:"many2many:sys_admin_roles;"`
	Permissions []SysPermission `json:"permissions" gorm:"many2many:sys_role_permissions;"`
}

type SysPermission struct {
	BaseModel
	Method      string    `json:"method" gorm:"size:50;not null;comment:请求方式"`
	Path        string    `json:"path" gorm:"size:100;not null;comment:uri路径"`
	Name        string    `json:"name" gorm:"size:50;comment:名称"`
	Description string    `json:"description" gorm:"size:255;comment:描述"`
	GroupName   string    `json:"groupName" gorm:"size:50;comment:分组名称"`
	Roles       []SysRole `json:"roles" gorm:"many2many:sys_role_permissions;"`
}

func (u *SysAdmin) BeforeSave(tx *gorm.DB) error {
	if u.Password != "" {
		hashedPassword, err := bcrypt.GenerateFromPassword([]byte(u.Password), bcrypt.DefaultCost)
		if err != nil {
			return err
		}
		u.Password = string(hashedPassword)
	}
	return nil
}

func (u *SysAdmin) CheckPassword(password string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(u.Password), []byte(password))
	return err == nil
}
