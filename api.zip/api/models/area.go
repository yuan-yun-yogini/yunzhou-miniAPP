package models

type Area struct {
	BaseModel
	Code       string  `json:"code" gorm:"unique;size:50;not null;comment:编码"`
	ParentCode *string `json:"parentCode" gorm:"index;size:50;comment:上级编码"`
	Type       string  `json:"type" gorm:"size:50;not null;comment:类型"`
	Name       string  `json:"name" gorm:"size:50;not null;comment:名称"`
	FullName   string  `json:"fullName" gorm:"size:255;not null;comment:完整名称"`
	Level      uint    `json:"level" gorm:"not null;comment:级别"`
}
