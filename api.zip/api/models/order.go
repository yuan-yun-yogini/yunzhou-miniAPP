package models

import (
	"time"
)

type Order struct {
	BaseModel
	UserId         uint           `json:"userId" gorm:"not null;comment:用户id"`
	PayId          *uint          `json:"payId" gorm:"comment:支付id"`
	OrderNo        string         `json:"orderNo" gorm:"unique;size:50;not null;comment:订单号"`
	TotalAmount    uint           `json:"totalAmount" gorm:"not null;comment:总金额"`
	DiscountAmount uint           `json:"discountAmount" gorm:"not null;comment:优惠金额"`
	PayAmount      uint           `json:"payAmount" gorm:"not null;comment:支付金额"`
	PayTime        *time.Time     `json:"payTime" gorm:"comment:支付时间"`
	RefundAmount   uint           `json:"refundAmount" gorm:"not null;comment:退款金额"`
	RefundTime     *time.Time     `json:"refundTime" gorm:"comment:退款时间"`
	Description    string         `json:"description" gorm:"size:255;not null;comment:说明"`
	Remark         string         `json:"remark" gorm:"size:255;not null;comment:备注"`
	Status         string         `json:"status" gorm:"size:50;not null;comment:状态"`
	RefundStatus   string         `json:"refundStatus" gorm:"size:50;not null;comment:退款状态"`
	EvaluateStatus string         `json:"evaluateStatus" gorm:"size:50;not null;comment:评价状态"`
	UserDeletedAt  *time.Time     `json:"userDeletedAt" gorm:"comment:用户删除时间"`
	ShippedTime    *time.Time     `json:"shippedTime" gorm:"comment:发货时间"`
	DeliveredTime  *time.Time     `json:"deliveredTime" gorm:"comment:收货时间"`
	CompletedTime  *time.Time     `json:"completedTime" gorm:"comment:完成时间"`
	User           User           `json:"user" gorm:"foreignKey:UserId"`
	OrderAddress   *OrderAddress  `json:"orderAddress" gorm:"foreignKey:OrderId"`
	OrderProducts  []OrderProduct `json:"orderProducts" gorm:"foreignKey:OrderId"`
	OrderExpresses []OrderExpress `json:"orderExpresses" gorm:"foreignKey:OrderId"`
	OrderRefund    *OrderRefund   `json:"orderRefund" gorm:"foreignKey:OrderId"`
}

type OrderProduct struct {
	BaseModel
	OrderId             uint                  `json:"orderId" gorm:"not null;comment:订单id"`
	UserId              uint                  `json:"userId" gorm:"not null;comment:用户id"`
	ProductId           uint                  `json:"productId" gorm:"not null;comment:产品id"`
	ProductName         string                `json:"productName" gorm:"size:100;not null;comment:产品名称"`
	ProductImageId      uint                  `json:"productImageId" gorm:"not null;comment:产品图片"`
	ProductSpecAttrId   *uint                 `json:"productSpecAttrId" gorm:"comment:产品规格属性id"`
	ProductSpecAttrName string                `json:"productSpecAttrName" gorm:"size:255;comment:产品规格属性名称"`
	ResourceIds         string                `json:"resourceIdStr" gorm:"comment:资源id"`
	Quantity            uint                  `json:"quantity" gorm:"not null;comment:数量"`
	Price               uint                  `json:"price" gorm:"not null;comment:价格"`
	TotalAmount         uint                  `json:"totalAmount" gorm:"not null;comment:总金额"`
	DiscountAmount      uint                  `json:"discountAmount" gorm:"not null;comment:优惠金额"`
	PayAmount           uint                  `json:"payAmount" gorm:"not null;comment:支付金额"`
	Status              string                `json:"status" gorm:"size:50;not null;comment:状态"`
	User                User                  `json:"user" gorm:"foreignKey:UserId"`
	ProductImage        Image                 `json:"productImage" gorm:"foreignKey:ProductImageId"`
	Evaluate            *OrderProductEvaluate `json:"evaluate" gorm:"foreignKey:OrderProductId"`
}

type OrderAddress struct {
	BaseModel
	OrderId  uint   `json:"orderId" gorm:"not null;comment:订单id"`
	Name     string `json:"name" gorm:"size:50;not null;comment:姓名"`
	Phone    string `json:"phone" gorm:"size:20;not null;comment:手机号"`
	Province string `json:"province" gorm:"size:50;not null;comment:省"`
	City     string `json:"city" gorm:"size:50;not null;comment:市"`
	District string `json:"district" gorm:"size:50;not null;comment:区县"`
	Detail   string `json:"detail" gorm:"size:255;not null;comment:详细地址"`
}

type OrderExpress struct {
	BaseModel
	OrderId     uint   `json:"orderId" gorm:"not null;comment:订单id"`
	CompanyName string `json:"companyName" gorm:"size:50;not null;comment:快递公司名称"`
	ExpressNo   string `json:"expressNo" gorm:"size:100;not null;comment:快递单号"`
	Status      string `json:"status" gorm:"size:50;not null;comment:状态"`
}

type OrderRefund struct {
	BaseModel
	OrderId      uint       `json:"orderId" gorm:"not null;comment:订单id"`
	PayRefundId  *uint      `json:"payRefundId" gorm:"index,comment:退款id"`
	Amount       uint       `json:"amount" gorm:"not null;comment:退款金额"`
	Reason       string     `json:"reason" gorm:"size:255;not null;comment:退款原因"`
	ImageIds     string     `json:"imageIdStr" gorm:"size:255;not null;comment:退款图片id,多个逗号分隔"`
	ReplyContent string     `json:"replyContent" gorm:"size:255;not null;comment:回复内容"`
	ReplyTime    *time.Time `json:"replyTime" gorm:"comment:回复时间"`
	RefundTime   *time.Time `json:"refundTime" gorm:"comment:退款时间"`
	Status       string     `json:"status" gorm:"size:50;not null;comment:状态"`
}

type OrderProductEvaluate struct {
	BaseModel
	OrderProductId      uint       `json:"orderProductId" gorm:"unique;not null;comment:订单产品id"`
	OrderId             uint       `json:"orderId" gorm:"not null;comment:订单id"`
	UserId              uint       `json:"userId" gorm:"not null;comment:用户id"`
	ProductId           uint       `json:"productId" gorm:"not null;comment:产品id"`
	ProductSpecAttrId   *uint      `json:"productSpecAttrId" gorm:"comment:产品规格属性id"`
	ProductSpecAttrName string     `json:"productSpecAttrName" gorm:"size:255;comment:产品规格属性名称"`
	Score               uint       `json:"score" gorm:"not null;comment:评分"`
	Content             string     `json:"content" gorm:"size:255;not null;comment:评价内容"`
	ImageIds            string     `json:"imageIdStr" gorm:"size:255;not null;comment:评价图片id,多个逗号分隔"`
	AppendContent       string     `json:"appendContent" gorm:"size:255;not null;comment:追评内容"`
	AppendImageIds      string     `json:"appendImageIdStr" gorm:"size:255;not null;comment:追评图片id,多个逗号分隔"`
	AppendTime          *time.Time `json:"appendTime" gorm:"comment:追评时间"`
	Status              string     `json:"status" gorm:"size:50;not null;comment:状态"`
	User                User       `json:"user" gorm:"foreignKey:UserId"`
}
