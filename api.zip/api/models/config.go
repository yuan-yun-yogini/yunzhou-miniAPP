package models

type Config struct {
	BaseModel
	Acl         string `json:"acl" gorm:"size:50;not null;comment:访问权限"`
	Type        string `json:"type" gorm:"size:50;not null;comment:类型"`
	Name        string `json:"name" gorm:"size:50;not null;comment:名称"`
	Description string `json:"description" gorm:"size:255;comment:描述"`
	ConfigKey   string `json:"configKey" gorm:"unique;size:50;not null;comment:键"`
	ConfigValue string `json:"configvalue" gorm:"type:text;comment:值"`
}
