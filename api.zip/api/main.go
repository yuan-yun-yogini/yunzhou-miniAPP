package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"app/api"
	"app/command"
	"app/eapi"
	"app/global"
	"app/models"
	"app/service"
	"app/sys"
	"app/utils"

	"github.com/gin-gonic/gin"

	swaggerFiles "github.com/swaggo/files"     // swagger embed files
	ginSwagger "github.com/swaggo/gin-swagger" // gin-swagger middleware

	_ "app/docs"
)

// 添加注释以描述 server 信息
// @title           go项目
// @version         1.0
// @description     This is a sample server celler server.
// @host      localhost:8001
// @BasePath  /
func main() {
	// 加载配置
	global.InitGlobal()

	models.DbMigrate()

	command.InitCron()

	gin.SetMode(global.AppConfig.Server.Mode)

	router := gin.Default()

	utils.InitValidator()

	service.InitWxPayService()

	if err := service.CreateWxMpAccessToken(); err != nil {
		log.Fatalln("CreateWxMpAccessToken " + err.Error())
	}

	if gin.Mode() == gin.DebugMode {
		//跨域设置
		router.Use(func(c *gin.Context) {
			c.Writer.Header().Set("Access-Control-Allow-Origin", "*") // 允许所有源，也可以指定具体的源
			c.Writer.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE")
			c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Authorization")
			if c.Request.Method == "OPTIONS" {
				c.AbortWithStatus(204) // 对于OPTIONS请求，直接返回204状态码，不进行后续处理。
				return
			}
			c.Next()
		})

		router.GET("swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))
	}

	router.GET("/", func(c *gin.Context) {
		c.String(http.StatusOK, "Welcome")
	})

	for _, item := range global.AppConfig.Modules {
		log.Printf("%s %t", item.Name, item.IsStart)
		if item.IsStart {
			switch item.Name {
			case "api":
				api.Start(router, &item)
			case "sys":
				sys.Start(router, &item)
			case "eapi":
				eapi.Start(router, &item)
			}
		}
	}

	srv := &http.Server{
		Addr:    fmt.Sprintf(":%d", global.AppConfig.Server.Port),
		Handler: router.Handler(),
	}

	go func() {
		log.Println("Server start ", global.AppConfig.Server.Port)

		// service connections
		if global.AppConfig.Server.TlsCert != "" && global.AppConfig.Server.TlsKey != "" {
			if err := srv.ListenAndServeTLS(global.AppConfig.Server.TlsCert, global.AppConfig.Server.TlsKey); err != nil && err != http.ErrServerClosed {
				log.Fatalf("listen: %s\n", err)
			}
		} else {
			if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
				log.Fatalf("listen: %s\n", err)
			}
		}
	}()

	// Wait for interrupt signal to gracefully shutdown the server with
	// a timeout of 5 seconds.
	quit := make(chan os.Signal, 1)
	// kill (no params) by default sends syscall.SIGTERM
	// kill -2 is syscall.SIGINT
	// kill -9 is syscall.SIGKILL but can't be caught, so don't need add it
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Println("Shutdown Server ...")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		log.Println("Server Shutdown:", err)
	}
	log.Println("Server exiting")
}
