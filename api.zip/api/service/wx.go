package service

import (
	"app/global"
	"app/utils"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"time"
)

type WxMpAccessToken struct {
	AccessToken string `json:"accessToken"`
	ExpiresTime int64  `json:"expiresTime"`
}

var WxMpAccessTokenInstance *WxMpAccessToken

func GetWxMpAccessToken() (string, error) {
	if global.AppConfig.WxMp.AccessTokenUrl != "" {
		return RequestWxMpAccessToken()
	}

	at := WxMpAccessTokenInstance
	if at == nil {
		return "", errors.New("获取AccessToken失败")
	}

	if at.ExpiresTime <= time.Now().Unix() {
		return "", errors.New("获取AccessToken过期")
	}

	return at.AccessToken, nil
}

func RequestWxMpAccessToken() (string, error) {
	tm := time.Now().Unix()
	signStr := fmt.Sprintf("time=%d&key=%s", tm, global.AppConfig.WxMp.AccessTokenKey)
	sign := utils.Md5String(signStr)
	url := fmt.Sprintf("%s?time=%d&sign=%s", global.AppConfig.WxMp.AccessTokenUrl, tm, sign)

	resp, err := http.Get(url)
	if err != nil {
		return "", err
	}

	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	type RespData struct {
		AccessToken string `json:"accessToken"`
	}

	type Resp struct {
		Code    int       `json:"code"`
		Message string    `json:"message"`
		Data    *RespData `json:"data"`
	}

	var obj Resp
	err = json.Unmarshal(body, &obj)
	if err != nil {
		return "", err
	}

	if obj.Code != 0 {
		return "", errors.New(obj.Message)
	}

	return obj.Data.AccessToken, nil
}

func CreateWxMpAccessToken() error {
	if global.AppConfig.WxMp.AccessTokenUrl != "" {
		return nil
	}

	url := fmt.Sprintf("https://api.weixin.qq.com/cgi-bin/token?appid=%s&secret=%s&grant_type=client_credential", global.AppConfig.WxMp.AppId, global.AppConfig.WxMp.AppSecret)

	resp, err := http.Get(url)
	if err != nil {
		return err
	}

	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}

	type Resp struct {
		AccessToken string `json:"access_token"`
		ExpiresIn   int64  `json:"expires_in"`
	}

	var obj Resp
	err = json.Unmarshal(body, &obj)
	if err != nil {
		return err
	}

	var at WxMpAccessToken
	at.AccessToken = obj.AccessToken
	at.ExpiresTime = time.Now().Unix() + obj.ExpiresIn

	WxMpAccessTokenInstance = &at

	return nil
}
