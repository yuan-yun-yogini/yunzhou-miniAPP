package service

import (
	"app/global"
	"app/models"
	"app/utils"
)

func LoadImageListWithIds(idsList []string) [][]models.Image {
	idList := []uint{}
	for _, ids := range idsList {
		if ids != "" {
			list := utils.SplitToUintSlice(ids, ",")
			idList = append(idList, list...)
		}
	}

	var imageList []models.Image
	global.DB.Where("id in ?", idList).Find(&imageList)

	imageMap := map[uint]models.Image{}
	for _, item := range imageList {
		imageMap[item.Id] = item
	}

	resList := [][]models.Image{}
	for _, ids := range idsList {
		resItemList := []models.Image{}

		if ids != "" {
			list := utils.SplitToUintSlice(ids, ",")
			for _, id := range list {
				if image, ok := imageMap[id]; ok {
					resItemList = append(resItemList, image)
				}
			}
		}

		resList = append(resList, resItemList)
	}

	return resList
}
