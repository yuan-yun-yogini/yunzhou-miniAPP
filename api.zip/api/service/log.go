package service

import (
	"app/config"
	"app/global"
	"app/models"
	"encoding/json"
	"log"
)

func CreateLog(level string, name string, content any) {
	contentByte, err := json.Marshal(content)
	if err != nil {
		log.Println("CreateLog Marshal " + err.Error())
		return
	}

	global.DB.Create(&models.Log{
		Level:   level,
		Name:    name,
		Content: string(contentByte),
	})
}

func CreateLogDebug(name string, content any) {
	CreateLog(config.LogLevelDebug, name, content)
}

func CreateLogInfo(name string, content any) {
	CreateLog(config.LogLevelInfo, name, content)
}

func CreateLogWarn(name string, content any) {
	CreateLog(config.LogLevelWarn, name, content)
}

func CreateLogError(name string, content any) {
	CreateLog(config.LogLevelError, name, content)
}
