package service

import (
	"app/config"
	"app/global"
	"context"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"time"

	"github.com/tencentyun/cos-go-sdk-v5"
)

type CosService struct {
	Config *config.CosConfig
	Cos    *cos.Client
}

type CosHead struct {
	ContentType   string
	ContentLength int
	Etag          string
}

func (c *CosService) UploadFile(filepath string, name string) (string, error) {
	_, _, err := c.Cos.Object.Upload(context.Background(), name, filepath, nil)
	if err != nil {
		return "", err
	}

	return c.Config.Domain + "/" + name, nil
}

func (c *CosService) UploadReader(reader io.Reader, name string) (string, error) {
	_, err := c.Cos.Object.Put(context.Background(), name, reader, nil)
	if err != nil {
		return "", err
	}

	return c.Config.Domain + "/" + name, nil
}

func (c *CosService) DeleteFile(name string) error {
	_, err := c.Cos.Object.Delete(context.Background(), name)
	if err != nil {
		return err
	}

	return nil
}

func (c *CosService) UploadPresignedUrl(name string) (string, error) {
	presignedUrl, err := c.Cos.Object.GetPresignedURL(context.Background(), http.MethodPut, name, c.Config.SecretId, c.Config.SecretKey, 3*time.Hour, nil, false)
	if err != nil {
		return "", err
	}

	return presignedUrl.String(), nil
}

func (c *CosService) DownloadPresignedUrl(name string) (string, error) {
	//自定义域名预签名下载
	urlStr, _ := url.Parse(c.Config.Domain)
	baseURL := &cos.BaseURL{BucketURL: urlStr}
	client := cos.NewClient(baseURL, &http.Client{})

	presignedUrl, err := client.Object.GetPresignedURL(context.Background(), http.MethodGet, name, c.Config.SecretId, c.Config.SecretKey, 3*time.Hour, nil, false)
	if err != nil {
		return "", err
	}

	return presignedUrl.String(), nil
}

func (c *CosService) Head(name string) (*CosHead, error) {
	resp, err := c.Cos.Object.Head(context.Background(), name, nil)
	if err != nil {
		return nil, err
	}

	contentLenth, _ := strconv.Atoi(resp.Header.Get("Content-Length"))

	cosHead := CosHead{
		ContentType:   resp.Header.Get("Content-Type"),
		ContentLength: contentLenth,
		Etag:          resp.Header.Get("ETag"),
	}

	return &cosHead, nil
}

func NewCosService(name string) *CosService {
	c := CosService{}

	for _, item := range global.AppConfig.Coses {
		if item.Name == name {
			c.Config = &item
			break
		}
	}

	if c.Config == nil {
		return nil
	}

	urlStr, _ := url.Parse(c.Config.BucketUrl)
	baseURL := &cos.BaseURL{BucketURL: urlStr}
	client := cos.NewClient(baseURL, &http.Client{
		Transport: &cos.AuthorizationTransport{
			SecretID:  c.Config.SecretId,
			SecretKey: c.Config.SecretKey,
		},
	})

	c.Cos = client

	return &c
}
