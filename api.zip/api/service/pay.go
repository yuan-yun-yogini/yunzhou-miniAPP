package service

import (
	"app/config"
	"app/global"
	"app/models"
	"fmt"
	"time"

	"github.com/gin-gonic/gin"
)

func PaySuccess(pay *models.Pay) error {
	if pay.TradeType == config.PayTradeTypeOrder {
		var order models.Order
		global.DB.Where("id = ?", pay.TradeId).First(&order)

		return OrderPay(&order, pay)
	}

	return nil
}

func PayRefund(payRefund *models.PayRefund) error {
	if gin.Mode() == gin.DebugMode {
		//debug模式直接退款成功
		timeNow := time.Now()
		payRefund.OutTradeNo = fmt.Sprintf("%s%09d%d", time.Now().Format("20060102150405"), time.Now().Nanosecond(), payRefund.UserId)
		payRefund.RefundTime = &timeNow
		payRefund.Status = config.PayRefundStatusSuccess

		global.DB.Save(payRefund)

		payRefund.Pay.RefundAmount += payRefund.Amount
		payRefund.Pay.RefundTime = payRefund.RefundTime
		global.DB.Save(&payRefund.Pay)

		err := PayRefundSuccess(payRefund)

		return err
	}

	if payRefund.Pay.Channel == config.PayChannelWxH5 || payRefund.Pay.Channel == config.PayChannelWxJsapi || payRefund.Pay.Channel == config.PayChannelWxMp {
		_, err := PayRefundWx(payRefund)
		if err != nil {
			return err
		}
	}

	return nil
}

func PayRefundSuccess(payRefund *models.PayRefund) error {
	if payRefund.Pay.TradeType == config.PayTradeTypeOrder {
		var orderRefund models.OrderRefund
		global.DB.Where("pay_refund_id = ?", payRefund.Id).First(&orderRefund)

		return OrderRefundSuccess(&orderRefund, *payRefund.RefundTime)
	}

	return nil
}

func PayRefundFail(payRefund *models.PayRefund) error {
	if payRefund.Pay.TradeType == config.PayTradeTypeOrder {
		var orderRefund models.OrderRefund
		global.DB.Where("pay_refund_id = ?", payRefund.Id).First(&orderRefund)

		return OrderRefundFail(&orderRefund)
	}

	return nil
}
