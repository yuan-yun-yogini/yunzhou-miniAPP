package service

import (
	"app/config"
	"app/global"
	"app/models"
	"errors"
	"fmt"
	"slices"
	"strconv"
	"time"

	"gorm.io/gorm"
)

// 订单取消
func OrderCancel(order *models.Order) error {
	if order.Status != config.OrderStatusPending {
		return errors.New("订单状态不可取消")
	}

	var orderProducts []models.OrderProduct
	global.DB.Where("order_id = ?", order.Id).Find(&orderProducts)

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		result := tx.Model(&models.Order{}).Where("id = ?", order.Id).Where("status = ?", config.OrderStatusPending).Updates(
			models.Order{Status: config.OrderStatusCanceled})
		if result.Error != nil {
			return result.Error
		}

		if result.RowsAffected < 1 {
			return errors.New("状态异常")
		}

		tx.Model(&models.OrderProduct{}).Where("order_id = ?", order.Id).Update("status", config.OrderStatusCanceled)

		//释放库存
		for _, item := range orderProducts {
			if item.ProductSpecAttrId != nil {
				tx.Model(&models.ProductSpecAttr{}).Where("id = ?", item.ProductSpecAttrId).Where("stock >= 0").Update("stock", gorm.Expr("stock + ?", item.Quantity))
			} else {
				tx.Model(&models.Product{}).Where("id = ?", item.ProductId).Where("stock >= 0").Update("stock", gorm.Expr("stock + ?", item.Quantity))
			}
		}

		order.Status = config.OrderStatusCanceled

		return nil
	})

	return err
}

// 订单支付
func OrderPay(order *models.Order, pay *models.Pay) error {
	if order.Status != config.OrderStatusPending {
		return errors.New("订单状态不可支付")
	}

	var orderProducts []models.OrderProduct
	global.DB.Where("order_id = ?", order.Id).Find(&orderProducts)

	//如果订单的产品全部为数字产品，则订单直接交易完成
	isAllResource := true
	for _, item := range orderProducts {
		if item.ResourceIds == "" {
			isAllResource = false
			break
		}
	}

	status := config.OrderStatusPaid
	if isAllResource {
		status = config.OrderStatusCompleted
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		result := tx.Model(&models.Order{}).Where("id = ?", order.Id).Where("status = ?", config.OrderStatusPending).Updates(
			models.Order{Status: status, PayId: &pay.Id, PayTime: pay.PaidTime})
		if result.Error != nil {
			return result.Error
		}

		if result.RowsAffected < 1 {
			return errors.New("状态异常")
		}

		tx.Model(&models.OrderProduct{}).Where("order_id = ?", order.Id).Update("status", status)

		//增加销量
		for _, item := range orderProducts {
			tx.Model(&models.Product{}).Where("id = ?", item.ProductId).Update("sales_volumn", gorm.Expr("sales_volumn + ?", item.Quantity))
		}

		order.PayId = &pay.Id
		order.Status = config.OrderStatusPaid

		return nil
	})

	return err
}

// 订单发货
func OrderShip(order *models.Order, orderExpresses []models.OrderExpress) error {
	if order.Status != config.OrderStatusPaid {
		return errors.New("订单状态不可发货")
	}

	//自动收货
	var cfg models.Config
	var orderDeliverDuration int = 0
	if result := global.DB.Where("config_key = ?", "orderDeliverDuration").First(&cfg); result.Error == nil {
		orderDeliverDuration, _ = strconv.Atoi(cfg.ConfigValue)
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		timeNow := time.Now()
		result := tx.Model(&models.Order{}).Where("id = ?", order.Id).Where("status = ?", config.OrderStatusPaid).Updates(
			models.Order{Status: config.OrderStatusShipped, ShippedTime: &timeNow})
		if result.Error != nil {
			return result.Error
		}

		if result.RowsAffected < 1 {
			return errors.New("状态异常")
		}

		tx.Model(&models.OrderProduct{}).Where("order_id = ?", order.Id).Update("status", config.OrderStatusShipped)

		for _, item := range orderExpresses {
			tx.Create(&item)
		}

		if orderDeliverDuration > 0 {
			tx.Create(&models.Timer{
				ExecuteType: config.TimerExecuteTypeOrderDeliver,
				ExecuteId:   order.Id,
				ExecuteTime: time.Now().UnixMilli() + (int64(orderDeliverDuration) * 86400000),
				Status:      config.TimerStatusPending,
			})
		}

		order.Status = config.OrderStatusShipped

		return nil
	})

	return err
}

// 订单收货
func OrderDeliver(order *models.Order) error {
	if order.Status != config.OrderStatusShipped {
		return errors.New("订单状态不可收货")
	}

	//自动完成
	var cfg models.Config
	var orderCompleteDuration int = 0
	if result := global.DB.Where("config_key = ?", "orderCompleteDuration").First(&cfg); result.Error == nil {
		orderCompleteDuration, _ = strconv.Atoi(cfg.ConfigValue)
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		timeNow := time.Now()
		result := tx.Model(&models.Order{}).Where("id = ?", order.Id).Where("status = ?", config.OrderStatusShipped).Updates(
			models.Order{Status: config.OrderStatusDelivered, DeliveredTime: &timeNow})
		if result.Error != nil {
			return result.Error
		}

		if result.RowsAffected < 1 {
			return errors.New("状态异常")
		}

		tx.Model(&models.OrderProduct{}).Where("order_id = ?", order.Id).Update("status", config.OrderStatusDelivered)

		tx.Model(&models.OrderExpress{}).Where("order_id = ?", order.Id).Update("status", config.OrderExpressStatusDelivered)

		if orderCompleteDuration > 0 {
			tx.Create(&models.Timer{
				ExecuteType: config.TimerExecuteTypeOrderComplete,
				ExecuteId:   order.Id,
				ExecuteTime: time.Now().UnixMilli() + (int64(orderCompleteDuration) * 86400000),
				Status:      config.TimerStatusPending,
			})
		}

		order.Status = config.OrderStatusDelivered

		return nil
	})

	return err
}

// 订单完成
func OrderComplete(order *models.Order) error {
	if order.Status != config.OrderStatusDelivered {
		return errors.New("订单状态不可完成")
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		timeNow := time.Now()
		result := tx.Model(&models.Order{}).Where("id = ?", order.Id).Where("status = ?", config.OrderStatusDelivered).Updates(
			models.Order{Status: config.OrderStatusCompleted, CompletedTime: &timeNow})
		if result.Error != nil {
			return result.Error
		}

		if result.RowsAffected < 1 {
			return errors.New("状态异常")
		}

		tx.Model(&models.OrderProduct{}).Where("order_id = ?", order.Id).Update("status", config.OrderStatusCompleted)

		order.Status = config.OrderStatusCompleted
		return nil
	})

	return err
}

// 订单申请退款
func OrderRefundApply(order *models.Order, amount uint, reason string, imageIds string) error {
	statuses := []string{
		config.OrderStatusPaid,
		config.OrderStatusShipped,
		config.OrderStatusDelivered,
	}

	if !slices.Contains(statuses, order.Status) || order.RefundStatus != "" {
		return errors.New("订单状态不可申请退款")
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		result := tx.Model(&models.Order{}).Where("id = ?", order.Id).Where("status in ?", statuses).Where("refund_status = ?", "").Updates(
			models.Order{RefundStatus: config.OrderRefundStatusPending})
		if result.Error != nil {
			return result.Error
		}

		if result.RowsAffected < 1 {
			return errors.New("状态异常")
		}

		tx.Create(&models.OrderRefund{
			OrderId:  order.Id,
			Amount:   amount,
			Reason:   reason,
			ImageIds: imageIds,
			Status:   config.OrderRefundStatusPending,
		})

		order.RefundStatus = config.OrderRefundStatusPending

		return nil
	})

	return err
}

// 订单删除退款
func OrderRefundDelete(orderRefund *models.OrderRefund) error {
	if orderRefund.Status != config.OrderRefundStatusPending {
		return errors.New("订单状态不可取消退款")
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		result := tx.Where("id = ?", orderRefund.Id).Where("status = ?", config.OrderRefundStatusPending).Delete(&models.OrderRefund{})
		if result.Error != nil {
			return result.Error
		}

		if result.RowsAffected < 1 {
			return errors.New("状态异常")
		}

		tx.Model(&models.Order{}).Where("id = ?", orderRefund.OrderId).Update("refund_status", "")

		return nil
	})

	return err
}

// 订单同意退款
func OrderRefundAccept(orderRefund *models.OrderRefund, reply string) error {
	if orderRefund.Status != config.OrderRefundStatusPending {
		return errors.New("订单状态不可同意退款")
	}

	var pay models.Pay
	if result := global.DB.Where("trade_type = ?", config.PayTradeTypeOrder).Where("trade_id = ?", orderRefund.OrderId).First(&pay); result.Error != nil {
		return result.Error
	}

	payRefund := models.PayRefund{
		PayId:       pay.Id,
		UserId:      pay.UserId,
		TradeNo:     fmt.Sprintf("%s%09d%d", time.Now().Format("20060102150405"), time.Now().Nanosecond(), pay.UserId),
		Amount:      orderRefund.Amount,
		Title:       "订单退款",
		Description: orderRefund.Reason,
		Status:      config.PayRefundStatusPending,
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		tx.Create(&payRefund)

		timeNow := time.Now()
		result := tx.Model(&models.OrderRefund{}).Where("id = ?", orderRefund.Id).Where("status = ?", config.OrderRefundStatusPending).Updates(
			models.OrderRefund{Status: config.OrderRefundStatusRefunding, ReplyContent: reply, ReplyTime: &timeNow, PayRefundId: &payRefund.Id})
		if result.Error != nil {
			return result.Error
		}

		if result.RowsAffected < 1 {
			return errors.New("状态异常")
		}

		tx.Model(&models.Order{}).Where("id = ?", orderRefund.OrderId).Updates(
			models.Order{RefundStatus: config.OrderRefundStatusRefunding})

		orderRefund.Status = config.OrderRefundStatusRefunding
		orderRefund.ReplyContent = reply
		orderRefund.ReplyTime = &timeNow

		return nil
	})

	if err != nil {
		return err
	}

	payRefund.Pay = pay

	return PayRefund(&payRefund)
}

// 订单拒绝退款
func OrderRefundReject(orderRefund *models.OrderRefund, reply string) error {
	if orderRefund.Status != config.OrderRefundStatusPending {
		return errors.New("订单状态不可拒绝退款")
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		timeNow := time.Now()
		result := tx.Model(&models.OrderRefund{}).Where("id = ?", orderRefund.Id).Where("status = ?", config.OrderRefundStatusPending).Updates(
			models.OrderRefund{Status: config.OrderRefundStatusReject, ReplyContent: reply, ReplyTime: &timeNow})
		if result.Error != nil {
			return result.Error
		}

		if result.RowsAffected < 1 {
			return errors.New("状态异常")
		}

		tx.Model(&models.Order{}).Where("id = ?", orderRefund.OrderId).Updates(
			models.Order{RefundStatus: config.OrderRefundStatusReject})

		orderRefund.Status = config.OrderRefundStatusReject
		orderRefund.ReplyContent = reply
		orderRefund.ReplyTime = &timeNow

		return nil
	})

	return err
}

// 订单退款成功
func OrderRefundSuccess(orderRefund *models.OrderRefund, refundTime time.Time) error {
	if orderRefund.Status != config.OrderRefundStatusRefunding {
		return errors.New("订单状态不可退款成功")
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		result := tx.Model(&models.OrderRefund{}).Where("id = ?", orderRefund.Id).Where("status = ?", config.OrderRefundStatusRefunding).Updates(
			models.OrderRefund{Status: config.OrderRefundStatusSuccess, RefundTime: &refundTime})
		if result.Error != nil {
			return result.Error
		}

		if result.RowsAffected < 1 {
			return errors.New("状态异常")
		}

		tx.Model(&models.Order{}).Where("id = ?", orderRefund.OrderId).Updates(
			map[string]interface{}{
				"refund_status": config.OrderRefundStatusSuccess,
				"refund_amount": gorm.Expr("refund_amount + ?", orderRefund.Amount),
				"refund_time":   &refundTime,
			})

		orderRefund.Status = config.OrderRefundStatusSuccess
		orderRefund.RefundTime = &refundTime

		return nil
	})

	return err
}

// 订单退款失败
func OrderRefundFail(orderRefund *models.OrderRefund) error {
	if orderRefund.Status != config.OrderRefundStatusRefunding {
		return errors.New("订单状态不可退款失败")
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		result := tx.Model(&models.OrderRefund{}).Where("id = ?", orderRefund.Id).Where("status = ?", config.OrderRefundStatusRefunding).Updates(
			models.OrderRefund{Status: config.OrderRefundStatusFail})
		if result.Error != nil {
			return result.Error
		}

		if result.RowsAffected < 1 {
			return errors.New("状态异常")
		}

		tx.Model(&models.Order{}).Where("id = ?", orderRefund.OrderId).Updates(
			models.Order{RefundStatus: config.OrderRefundStatusFail})

		orderRefund.Status = config.OrderRefundStatusFail

		return nil
	})

	return err
}
