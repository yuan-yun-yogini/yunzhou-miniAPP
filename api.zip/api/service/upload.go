package service

import (
	"app/config"
	"errors"
	"io"
)

type UploadFileInfo struct {
	ContentType   string
	ContentLength uint
	Hash          string
}

func UploadPublicReader(reader io.Reader, name string) (string, error) {
	return UploadReader(reader, name, config.AclPublic)
}

func UploadPrivateReader(reader io.Reader, name string) (string, error) {
	return UploadReader(reader, name, config.AclPrivate)
}

func UploadReader(reader io.Reader, name string, acl string) (string, error) {
	cosName := "public"
	if acl == config.AclPrivate {
		cosName = "private"
	}

	cosService := NewCosService(cosName)
	if cosService == nil {
		return "", errors.New("云对象存储未配置")
	}

	res, err := cosService.UploadReader(reader, name)
	if err != nil {
		return "", err
	}

	return res, nil
}

func UploadPublicFile(filepath string, name string) (string, error) {
	return UploadFile(filepath, name, config.AclPublic)
}

func UploadPrivateFile(filepath string, name string) (string, error) {
	return UploadFile(filepath, name, config.AclPrivate)
}

func UploadFile(filepath string, name string, acl string) (string, error) {
	cosName := "public"
	if acl == config.AclPrivate {
		cosName = "private"
	}

	cosService := NewCosService(cosName)
	if cosService == nil {
		return "", errors.New("云对象存储未配置")
	}

	res, err := cosService.UploadFile(filepath, name)
	if err != nil {
		return "", err
	}

	return res, nil
}

func CreateUploadFileUrl(name string, acl string) (string, error) {
	cosName := "public"
	if acl == config.AclPrivate {
		cosName = "private"
	}

	cosService := NewCosService(cosName)
	if cosService == nil {
		return "", errors.New("云对象存储未配置")
	}

	res, err := cosService.UploadPresignedUrl(name)
	if err != nil {
		return "", err
	}

	return res, nil
}

func GetUploadFileUrl(name string, acl string) (string, error) {
	cosName := "public"
	if acl == config.AclPrivate {
		cosName = "private"
	}

	cosService := NewCosService(cosName)
	if cosService == nil {
		return "", errors.New("云对象存储未配置")
	}

	res, err := cosService.DownloadPresignedUrl(name)
	if err != nil {
		return "", err
	}

	return res, nil
}

func GetUploadFileInfo(name string, acl string) (*UploadFileInfo, error) {
	cosName := "public"
	if acl == config.AclPrivate {
		cosName = "private"
	}

	cosService := NewCosService(cosName)
	if cosService == nil {
		return nil, errors.New("云对象存储未配置")
	}

	res, err := cosService.Head(name)
	if err != nil {
		return nil, err
	}

	return &UploadFileInfo{
		ContentType:   res.ContentType,
		ContentLength: uint(res.ContentLength),
		Hash:          res.Etag,
	}, nil
}
