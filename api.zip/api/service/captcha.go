package service

import (
	"app/config"
	"app/global"
	"fmt"
	"strings"
	"time"

	"github.com/mojocn/base64Captcha"
)

type CaptchaRedisStore struct {
}

func (s CaptchaRedisStore) Set(id string, value string) error {
	key := fmt.Sprintf("%s_%s", config.CachePrefixCaptcha, id)

	return global.Cache.Set(key, value, 5*time.Minute)
}

func (s CaptchaRedisStore) Get(id string, clear bool) string {
	key := fmt.Sprintf("%s_%s", config.CachePrefixCaptcha, id)

	value, err := global.Cache.Get(key)
	if err != nil {
		return ""
	}

	if clear {
		global.Cache.Del(key)
	}

	return value
}

func (s CaptchaRedisStore) Verify(id string, answer string, clear bool) bool {
	if answer == "" {
		return false
	}

	value := s.Get(id, clear)

	return strings.EqualFold(answer, value)
}

func GenerateCaptcha() (id, b64s, answer string, err error) {
	store := CaptchaRedisStore{}
	source := "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	driver := base64Captcha.NewDriverString(60, 120, 4, base64Captcha.OptionShowHollowLine, 4, source, nil, nil, nil)
	captcha := base64Captcha.NewCaptcha(driver, store)

	return captcha.Generate()
}

func VerifyCaptcha(id string, answer string) bool {
	store := CaptchaRedisStore{}
	return store.Verify(strings.TrimSpace(id), strings.TrimSpace(answer), true)
}
