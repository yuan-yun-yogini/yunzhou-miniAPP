package service

import (
	"app/config"
	"app/global"
	"app/models"
	appUtils "app/utils"
	"context"
	"errors"
	"log"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/wechatpay-apiv3/wechatpay-go/core"
	"github.com/wechatpay-apiv3/wechatpay-go/core/auth/verifiers"
	"github.com/wechatpay-apiv3/wechatpay-go/core/notify"
	"github.com/wechatpay-apiv3/wechatpay-go/core/option"
	"github.com/wechatpay-apiv3/wechatpay-go/services/payments"
	"github.com/wechatpay-apiv3/wechatpay-go/services/payments/h5"
	"github.com/wechatpay-apiv3/wechatpay-go/services/payments/jsapi"
	"github.com/wechatpay-apiv3/wechatpay-go/services/refunddomestic"
	"github.com/wechatpay-apiv3/wechatpay-go/utils"
)

type WxPay struct {
	Config *config.PayConfig
	Client *core.Client
	Notify *notify.Handler
}

type WxPayService struct {
	WxPays []*WxPay
}

var WxPayServiceInstance *WxPayService

func InitWxPayService() {
	var wxPayService WxPayService

	for _, item := range global.AppConfig.Pays {
		for _, channel := range item.Channels {
			if channel == config.PayChannelWxH5 || channel == config.PayChannelWxJsapi || channel == config.PayChannelWxMp {
				var wxPay WxPay

				wxPay.Config = &item

				if gin.Mode() != gin.DebugMode {
					wxPay.createClient()
					wxPay.createNotify()
				}

				wxPayService.WxPays = append(wxPayService.WxPays, &wxPay)

				break
			}
		}
	}

	WxPayServiceInstance = &wxPayService
}

func (t *WxPay) createClient() error {
	// 1. 加载商户私钥
	mchPrivateKey, err := utils.LoadPrivateKeyWithPath(t.Config.PrivatePem)
	if err != nil {
		log.Fatalf("加载商户私钥失败: %v", err)
	}

	// 2. 加载微信支付公钥
	wechatPubKey, err := utils.LoadPublicKeyWithPath(t.Config.PublicPem)
	if err != nil {
		log.Fatalf("加载微信公钥失败: %v", err)
	}

	// 3. 创建验签器（直接用 public key，不需要 ParseCertificate！）
	verifier := verifiers.NewSHA256WithRSAPubkeyVerifier(t.Config.PublicNo, *wechatPubKey)

	// 4. 构建客户端
	opts := []core.ClientOption{
		option.WithMerchantCredential(t.Config.MchId, t.Config.MchNo, mchPrivateKey),
		option.WithVerifier(verifier), // 直接用公钥验签
	}

	client, err := core.NewClient(context.Background(), opts...)
	if err != nil {
		log.Fatalf("创建微信支付客户端失败: %v", err)
	}

	t.Client = client

	return nil
}

func (t *WxPay) createNotify() error {
	// 2. 加载微信支付公钥
	wechatPubKey, err := utils.LoadPublicKeyWithPath(t.Config.PublicPem)
	if err != nil {
		log.Fatalf("加载微信公钥失败: %v", err)
	}

	// 3. 创建验签器（直接用 public key，不需要 ParseCertificate！）
	verifier := verifiers.NewSHA256WithRSAPubkeyVerifier(t.Config.PublicNo, *wechatPubKey)

	// 初始化回调处理器（全局一个就行）
	handler, err := notify.NewRSANotifyHandler(
		t.Config.MchKey,
		verifier,
	)
	if err != nil {
		log.Fatalf("创建微信回调失败: %v", err)
	}

	t.Notify = handler

	return nil
}

func (t *WxPayService) GetWxPay(channel string) *WxPay {
	for _, item := range t.WxPays {
		for _, ch := range item.Config.Channels {
			if ch == channel {
				return item
			}
		}
	}

	return nil
}

func PayWxH5(pay *models.Pay, clientId string) (*h5.PrepayResponse, error) {
	wxPay := WxPayServiceInstance.GetWxPay(pay.Channel)
	if wxPay == nil {
		return nil, errors.New("支付渠道未配置支持")
	}

	svc := h5.H5ApiService{Client: wxPay.Client}

	req := h5.PrepayRequest{
		Appid:       core.String(wxPay.Config.AppId),
		Mchid:       core.String(wxPay.Config.MchId),
		Description: core.String(appUtils.SubstrRune(pay.Description, 0, 127)),
		OutTradeNo:  core.String(pay.TradeNo),
		NotifyUrl:   core.String(global.AppConfig.Server.Notify + "/eapi/notifyWxPayH5"),
		Amount: &h5.Amount{
			Total: core.Int64(int64(pay.Amount)),
		},
		SceneInfo: &h5.SceneInfo{
			PayerClientIp: core.String(clientId),
			H5Info: &h5.H5Info{
				Type: core.String("Wap"),
			},
		},
	}

	resp, _, err := svc.Prepay(context.Background(), req)

	CreateLogInfo("PayWxH5", map[string]any{
		"req":  req,
		"resp": resp,
		"err":  err,
	})

	return resp, err
}

func PayWxJsapi(pay *models.Pay, openId string) (*jsapi.PrepayWithRequestPaymentResponse, error) {
	wxPay := WxPayServiceInstance.GetWxPay(pay.Channel)
	if wxPay == nil {
		return nil, errors.New("支付渠道未配置支持")
	}

	svc := jsapi.JsapiApiService{Client: wxPay.Client}

	req := jsapi.PrepayRequest{
		Appid:       core.String(wxPay.Config.AppId),
		Mchid:       core.String(wxPay.Config.MchId),
		Description: core.String(appUtils.SubstrRune(pay.Description, 0, 127)),
		OutTradeNo:  core.String(pay.TradeNo),
		NotifyUrl:   core.String(global.AppConfig.Server.Notify + "/eapi/notifyWxPayJsapi"),
		Amount: &jsapi.Amount{
			Total: core.Int64(int64(pay.Amount)),
		},
		Payer: &jsapi.Payer{
			Openid: core.String(openId),
		},
	}

	resp, _, err := svc.PrepayWithRequestPayment(context.Background(), req)

	CreateLogInfo("PayWxJsapi", map[string]any{
		"req":  req,
		"resp": resp,
		"err":  err,
	})

	return resp, err
}

func PayWxMp(pay *models.Pay, openId string) (*jsapi.PrepayWithRequestPaymentResponse, error) {
	wxPay := WxPayServiceInstance.GetWxPay(pay.Channel)
	if wxPay == nil {
		return nil, errors.New("支付渠道未配置支持")
	}

	svc := jsapi.JsapiApiService{Client: wxPay.Client}

	req := jsapi.PrepayRequest{
		Appid:       core.String(wxPay.Config.AppId),
		Mchid:       core.String(wxPay.Config.MchId),
		Description: core.String(appUtils.SubstrRune(pay.Description, 0, 127)),
		OutTradeNo:  core.String(pay.TradeNo),
		NotifyUrl:   core.String(global.AppConfig.Server.Notify + "/eapi/notifyWxPayMp"),
		Amount: &jsapi.Amount{
			Total: core.Int64(int64(pay.Amount)),
		},
		Payer: &jsapi.Payer{
			Openid: core.String(openId),
		},
	}

	resp, _, err := svc.PrepayWithRequestPayment(context.Background(), req)

	CreateLogInfo("PayWxMp", map[string]any{
		"req":  req,
		"resp": resp,
		"err":  err,
	})

	return resp, err
}

func PayRefundWx(payRefund *models.PayRefund) (*refunddomestic.Refund, error) {
	wxPay := WxPayServiceInstance.GetWxPay(payRefund.Pay.Channel)
	if wxPay == nil {
		return nil, errors.New("支付渠道未配置支持")
	}

	notifyUri := "/eapi/notifyWxRefund"
	switch payRefund.Pay.Channel {
	case config.PayChannelWxH5:
		notifyUri += "H5"
	case config.PayChannelWxJsapi:
		notifyUri += "Jsapi"
	case config.PayChannelWxMp:
		notifyUri += "Mp"
	}

	svc := refunddomestic.RefundsApiService{Client: wxPay.Client}

	req := refunddomestic.CreateRequest{
		TransactionId: core.String(payRefund.Pay.OutTradeNo),
		OutTradeNo:    core.String(payRefund.Pay.TradeNo),
		OutRefundNo:   core.String(payRefund.TradeNo),
		Reason:        core.String(appUtils.SubstrRune(payRefund.Pay.Description, 0, 80)),
		NotifyUrl:     core.String(global.AppConfig.Server.Notify + notifyUri),
		Amount: &refunddomestic.AmountReq{
			Refund:   core.Int64(int64(payRefund.Amount)),
			Total:    core.Int64(int64(payRefund.Pay.Amount)),
			Currency: core.String("CNY"),
		},
	}

	resp, _, err := svc.Create(context.Background(), req)

	CreateLogInfo("PayRefundWx", map[string]any{
		"req":  req,
		"resp": resp,
		"err":  err,
	})

	if err != nil {
		return nil, err
	}

	switch *resp.Status {
	case "SUCCESS":
		payRefund.OutTradeNo = *resp.RefundId
		payRefund.RefundTime = resp.SuccessTime
		payRefund.Status = config.PayRefundStatusSuccess
	case "CLOSED":
		payRefund.OutTradeNo = *resp.RefundId
		payRefund.Status = config.PayRefundStatusFail
	case "PROCESSING":
		payRefund.OutTradeNo = *resp.RefundId
	case "ABNORMAL":
		payRefund.OutTradeNo = *resp.RefundId
		payRefund.Status = config.PayRefundStatusFail
	}

	global.DB.Save(payRefund)

	switch payRefund.Status {
	case config.PayRefundStatusSuccess:
		payRefund.Pay.RefundAmount += payRefund.Amount
		payRefund.Pay.RefundTime = payRefund.RefundTime
		global.DB.Save(&payRefund.Pay)

		err = PayRefundSuccess(payRefund)
	case config.PayRefundStatusFail:
		err = PayRefundFail(payRefund)
	}

	return resp, err
}

func NotifyWxPayH5(request *http.Request) error {
	return NotifyWxPay(config.PayChannelWxH5, request)
}

func NotifyWxPayJsapi(request *http.Request) error {
	return NotifyWxPay(config.PayChannelWxJsapi, request)
}

func NotifyWxPayMp(request *http.Request) error {
	return NotifyWxPay(config.PayChannelWxMp, request)
}

func NotifyWxPay(channel string, request *http.Request) error {
	wxPay := WxPayServiceInstance.GetWxPay(channel)
	if wxPay == nil {
		return errors.New("支付渠道未配置支持")
	}

	transaction := new(payments.Transaction)
	req, err := wxPay.Notify.ParseNotifyRequest(context.Background(), request, transaction)
	// 如果验签未通过，或者解密失败
	if err != nil {
		return err
	}

	var pay models.Pay
	if result := global.DB.Where("trade_no = ?", *transaction.OutTradeNo).First(&pay); result.Error != nil {
		err = errors.New("支付单不存在")
	} else {
		if pay.Status != config.PayStatusPending {
			err = errors.New("支付单已处理")
		} else {
			pay.AppId = *transaction.Appid
			pay.MchId = *transaction.Mchid
			pay.OutTradeNo = *transaction.TransactionId

			if *transaction.TradeState == "SUCCESS" {
				pay.Status = config.PayStatusPaid
			} else {
				pay.Status = config.PayStatusCanceled
			}

			if transaction.SuccessTime != nil {
				if tm, err := time.Parse(time.RFC3339, *transaction.SuccessTime); err == nil {
					pay.PaidTime = &tm
				} else {
					now := time.Now()
					pay.PaidTime = &now
				}
			}

			global.DB.Save(&pay)

			if pay.Status == config.PayStatusPaid {
				err = PaySuccess(&pay)
			}
		}
	}

	CreateLogInfo("NotifyWxPay", map[string]any{
		"req":         req,
		"transaction": transaction,
		"err":         err,
	})

	return err
}

func NotifyWxPayRefundH5(request *http.Request) error {
	return NotifyWxPayRefund(config.PayChannelWxH5, request)
}

func NotifyWxPayRefundJsapi(request *http.Request) error {
	return NotifyWxPayRefund(config.PayChannelWxJsapi, request)
}

func NotifyWxPayRefundMp(request *http.Request) error {
	return NotifyWxPayRefund(config.PayChannelWxMp, request)
}

type NotifyWxPayRefundData struct {
	refunddomestic.Refund
	RefundStatus *string `json:"refund_status"`
}

func NotifyWxPayRefund(channel string, request *http.Request) error {
	wxPay := WxPayServiceInstance.GetWxPay(channel)
	if wxPay == nil {
		return errors.New("支付渠道未配置支持")
	}

	transaction := new(NotifyWxPayRefundData)
	req, err := wxPay.Notify.ParseNotifyRequest(context.Background(), request, transaction)
	// 如果验签未通过，或者解密失败
	if err != nil {
		return err
	}

	var payRefund models.PayRefund
	if result := global.DB.Where("trade_no = ?", *transaction.OutRefundNo).Preload("Pay").First(&payRefund); result.Error != nil {
		err = errors.New("退款单不存在")
	} else {
		if payRefund.Status != config.PayRefundStatusPending {
			err = errors.New("退款单已处理")
		} else {
			switch *transaction.RefundStatus {
			case "SUCCESS":
				payRefund.RefundTime = transaction.SuccessTime
				payRefund.Status = config.PayRefundStatusSuccess
			case "CLOSED":
				payRefund.Status = config.PayRefundStatusFail
			case "PROCESSING":

			case "ABNORMAL":
				payRefund.Status = config.PayRefundStatusFail
			}

			global.DB.Save(&payRefund)

			switch payRefund.Status {
			case config.PayRefundStatusSuccess:
				payRefund.Pay.RefundAmount += payRefund.Amount
				payRefund.Pay.RefundTime = payRefund.RefundTime
				global.DB.Save(&payRefund.Pay)

				err = PayRefundSuccess(&payRefund)
			case config.PayRefundStatusFail:
				err = PayRefundFail(&payRefund)
			}
		}
	}

	CreateLogInfo("NotifyWxPay", map[string]any{
		"req":         req,
		"transaction": transaction,
		"err":         err,
	})

	return err
}
