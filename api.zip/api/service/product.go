package service

import (
	"app/config"
	"app/global"
	"app/models"
	"errors"
)

type ProductCheckRequest struct {
	Id         uint  `json:"id"`
	SpecAttrId *uint `json:"specAttrId"`
	Quantity   uint  `json:"quantity"`
}

// 检查产品
func CheckProduct(reqProduct *ProductCheckRequest) error {
	reqProducts := []ProductCheckRequest{*reqProduct}

	errs := CheckProducts(&reqProducts)

	return errs[0]
}

// 检查产品列表
func CheckProducts(reqProducts *[]ProductCheckRequest) []error {
	productIds := []uint{}
	productSpectAttrIds := []uint{}

	for _, item := range *reqProducts {
		productIds = append(productIds, item.Id)

		if item.SpecAttrId != nil {
			productSpectAttrIds = append(productSpectAttrIds, *item.SpecAttrId)
		}
	}

	products := []models.Product{}
	if len(productIds) > 0 {
		global.DB.Select("id", "name", "stock", "status").Where("id in ?", productIds).Find(&products)
	}

	productSpecAttrs := []models.ProductSpecAttr{}
	if len(productSpectAttrIds) > 0 {
		global.DB.Select("id", "stock").Where("id in ?", productSpectAttrIds).Find(&productSpecAttrs)
	}

	return CheckProductsWithModel(reqProducts, &products, &productSpecAttrs)
}

// 检查产品列表
func CheckProductsWithModel(reqProducts *[]ProductCheckRequest, products *[]models.Product, productSpecAttrs *[]models.ProductSpecAttr) []error {
	productMap := map[uint]models.Product{}
	productSpectAttrMap := map[uint]models.ProductSpecAttr{}

	for _, item := range *products {
		productMap[item.Id] = item
	}

	for _, item := range *productSpecAttrs {
		productSpectAttrMap[item.Id] = item
	}

	errs := make([]error, len(*reqProducts))
	for i, item := range *reqProducts {
		errs[i] = nil

		product, ok := productMap[item.Id]

		if !ok {
			errs[i] = errors.New("商品已下架")
		} else if product.Status != config.ProductStatusOnline {
			errs[i] = errors.New("商品已下架")
		} else {
			if item.SpecAttrId == nil {
				if product.Stock >= 0 && product.Stock < int(item.Quantity) {
					errs[i] = errors.New("商品库存不足")
				}
			} else {
				productSpectAttr, ok1 := productSpectAttrMap[*item.SpecAttrId]

				if !ok1 {
					errs[i] = errors.New("商品规格不存在")
				}

				if productSpectAttr.Stock >= 0 && productSpectAttr.Stock < int(item.Quantity) {
					errs[i] = errors.New("商品规格库存不足")
				}
			}
		}
	}

	return errs
}
