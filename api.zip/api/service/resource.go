package service

import (
	"app/global"
	"app/models"
	"app/utils"
)

func LoadResourceListWithIds(idsList []string) [][]models.Resource {
	idList := []uint{}
	for _, ids := range idsList {
		if ids != "" {
			list := utils.SplitToUintSlice(ids, ",")
			idList = append(idList, list...)
		}
	}

	var resourceList []models.Resource
	global.DB.Where("id in ?", idList).Find(&resourceList)

	resourceMap := map[uint]models.Resource{}
	for _, item := range resourceList {
		resourceMap[item.Id] = item
	}

	resList := [][]models.Resource{}
	for _, ids := range idsList {
		resItemList := []models.Resource{}

		if ids != "" {
			list := utils.SplitToUintSlice(ids, ",")
			for _, id := range list {
				if resource, ok := resourceMap[id]; ok {
					resItemList = append(resItemList, resource)
				}
			}
		}

		resList = append(resList, resItemList)
	}

	return resList
}
