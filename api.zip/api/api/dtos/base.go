package dtos

import (
	"time"
)

type BaseResponse struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    any    `json:"data"`
}

type PageRequest struct {
	Offset uint   `json:"offset" form:"offset"`
	Limit  uint   `json:"limit" form:"limit"`
	Sort   string `json:"sort" form:"sort"`
}

type TimeResponse time.Time

func (rt TimeResponse) MarshalJSON() ([]byte, error) {
	str := `"` + time.Time(rt).Format(time.DateTime) + `"`
	return []byte(str), nil
}

func (rt *TimeResponse) UnmarshalJSON(data []byte) error {
	var t time.Time
	err := t.UnmarshalJSON(data)
	if err != nil {
		return err
	}
	*rt = TimeResponse(t)
	return nil
}
