package dtos

type BannerSearchRequest struct {
	Types string `json:"types" form:"types"`
}

type BannerResponse struct {
	Id          uint          `json:"id"`
	Type        string        `json:"type"`
	Name        string        `json:"name"`
	Url         string        `json:"url"`
	Description string        `json:"description"`
	Image       ImageResponse `json:"image"`
}
