package dtos

type ResourceResponse struct {
	Id     uint   `json:"id"`
	Name   string `json:"name"`
	Type   string `json:"type"`
	Size   uint   `json:"size"`
	Hash   string `json:"hash"`
	Attr   string `json:"attr"`
	Status string `json:"status"`
	Url    string `json:"url"`
}
