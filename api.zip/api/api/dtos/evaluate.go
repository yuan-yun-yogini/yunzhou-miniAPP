package dtos

type EvaluateSearchRequest struct {
	PageRequest
	ProductId         uint   `json:"productId" form:"productId"`
	ProductSpecAttrId uint   `json:"productSpecAttrId" form:"productSpecAttrId"`
	MinScore          *uint  `json:"minScore" form:"minScore"`
	MaxScore          *uint  `json:"maxScore" form:"maxScore"`
	Status            string `json:"status" form:"status"`
}

type EvaluateResponse struct {
	Id                  uint             `json:"id"`
	ProductSpecAttrId   *uint            `json:"productSpecAttrId"`
	ProductSpecAttrName string           `json:"productSpecAttrName"`
	Score               uint             `json:"score"`
	Content             string           `json:"content"`
	CreatedAt           TimeResponse     `json:"createdAt"`
	AppendContent       string           `json:"appendContent"`
	AppendTime          *TimeResponse    `json:"appendTime"`
	Status              string           `json:"status"`
	Images              []ImageResponse  `json:"images"`
	AppendImages        []ImageResponse  `json:"appendImages"`
	User                UserViewResponse `json:"user"`
}
