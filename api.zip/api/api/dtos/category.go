package dtos

type CategoryResponse struct {
	Id       uint          `json:"id"`
	ParentId *uint         `json:"parentId"`
	Name     string        `json:"name"`
	Image    ImageResponse `json:"image"`
}
