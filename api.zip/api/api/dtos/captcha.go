package dtos

type CaptchaResponse struct {
	Id        string `json:"id"`        //图片id
	ImageData string `json:"imageData"` //图片内容
}
