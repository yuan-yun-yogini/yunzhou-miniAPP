package dtos

type AreaResponse struct {
	Code       string  `json:"code"`
	ParentCode *string `json:"parentCode"`
	Name       string  `json:"name"`
	Level      uint    `json:"level"`
}
