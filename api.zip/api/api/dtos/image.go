package dtos

type ImageResponse struct {
	Id     uint   `json:"id"`
	Type   string `json:"type"`
	Size   uint   `json:"size"`
	Width  int    `json:"width"`
	Height int    `json:"height"`
	Url    string `json:"url"`
}
