package dtos

type WxMpOpenIdRequest struct {
	Code string `json:"code" binding:"required"`
}

type WxMpOpenIdResponse struct {
	OpenId string `json:"openId"`
}

type WxMpPhoneLoginRequest struct {
	Code      string `json:"code" binding:"required"`
	InviterId *uint  `json:"inviterId"`
}

type WxMpAccessTokenRequest struct {
	Time int64  `json:"time" binding:"required"`
	Sign string `json:"sign" binding:"required"`
}

type WxMpAccessTokenResponse struct {
	AccessToken string `json:"accessToken"`
}
