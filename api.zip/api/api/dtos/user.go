package dtos

type UserRequest struct {
	OldPassword string `json:"oldPassword"`
	Password    string `json:"password" binding:"password"`
	Phone       string `json:"phone" binding:"phonenumber"`
	Name        string `json:"name"`
	AvatarId    *uint  `json:"avatarId"`
}

type UserResponse struct {
	Id        uint           `json:"id"`
	InviterId *uint          `json:"inviterId"`
	Username  string         `json:"username"`
	Phone     string         `json:"phone"`
	Name      string         `json:"name"`
	Avatar    *ImageResponse `json:"avatar"`
	Status    string         `json:"status"`
	CreatedAt string         `json:"createdAt"`
}

type UserLoginRequest struct {
	Username      string `json:"username" binding:"required" example:"admin"`  //用户名
	Password      string `json:"password" binding:"required" example:"123456"` //密码
	CaptchaId     string `json:"captchaId" binding:"required"`                 //验证码id
	CaptchaAnswer string `json:"captchaAnswer" binding:"required"`             //验证码答案
}

type UserLoginResponse struct {
	Token  string       `json:"token"`
	Expire uint         `json:"expire"`
	User   UserResponse `json:"user"`
}

type UserRegisterRequest struct {
	Username      string `json:"username" binding:"required,username" example:"admin"`  //用户名
	Password      string `json:"password" binding:"required,password" example:"123456"` //密码
	CaptchaId     string `json:"captchaId" binding:"required"`                          //验证码id
	CaptchaAnswer string `json:"captchaAnswer" binding:"required"`                      //验证码答案
	InviterId     *uint  `json:"inviterId"`
}

type UserViewResponse struct {
	Name   string         `json:"name"`
	Avatar *ImageResponse `json:"avatar"`
}
