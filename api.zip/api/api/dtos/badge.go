package dtos

type BadgeResponse struct {
	CartCount    uint `json:"cartCount"`
	MessageCount uint `json:"messageCount"`
	MyCount      uint `json:"myCount"`
}
