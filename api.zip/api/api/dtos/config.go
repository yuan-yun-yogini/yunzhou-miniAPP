package dtos

type ConfigSearchRequest struct {
	ConfigKeys string `json:"configKeys" form:"configKeys"`
}

type ConfigResponse struct {
	Id          uint           `json:"id"`
	Type        string         `json:"type"`
	Name        string         `json:"name"`
	ConfigKey   string         `json:"configKey"`
	ConfigValue string         `json:"configValue"`
	Image       *ImageResponse `json:"image"`
}
