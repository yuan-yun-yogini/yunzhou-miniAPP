package dtos

type SettleRequest struct {
	CartIds  []uint             `json:"cartIds"`
	Product  *ProductAddRequest `json:"product"`
	CouponId *uint              `json:"couponId"`
}

type SettleResponse struct {
	TotalAmount    uint                    `json:"totalAmount"`
	DiscountAmount uint                    `json:"discountAmount"`
	PayAmount      uint                    `json:"payAmount"`
	Products       []SettleProductResponse `json:"products"`
}

type SettleProductResponse struct {
	Price           uint                     `json:"price"`
	Quantity        uint                     `json:"quantity"`
	TotalAmount     uint                     `json:"totalAmount"`
	DiscountAmount  uint                     `json:"discountAmount"`
	PayAmount       uint                     `json:"payAmount"`
	Product         ProductListResponse      `json:"product"`
	ProductSpecAttr *ProductSpecAttrResponse `json:"productSpecAttr"`
}
