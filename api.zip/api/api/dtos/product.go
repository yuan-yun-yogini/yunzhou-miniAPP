package dtos

type ProductSearchRequest struct {
	PageRequest
	Id         uint   `json:"id" form:"id"`
	CategoryId uint   `json:"categoryId" form:"categoryId"`
	Name       string `json:"name" form:"name"`
}

type ProductAddRequest struct {
	Id         uint  `json:"id"`
	SpecAttrId *uint `json:"specAttrId"`
	Quantity   uint  `json:"quantity"`
}

type ProductSpecResponse struct {
	Id    uint     `json:"id"`
	Name  string   `json:"name"`
	Attrs []string `json:"attrs"`
}

type ProductSpecAttrResponse struct {
	Id            uint          `json:"id"`
	Name          string        `json:"name"`
	Image         ImageResponse `json:"image"`
	OriginalPrice uint          `json:"originalPrice"`
	Price         uint          `json:"price"`
	Stock         int           `json:"stock"`
}

type ProductListResponse struct {
	Id            uint          `json:"id"`
	Sku           string        `json:"sku"`
	Name          string        `json:"name"`
	OriginalPrice uint          `json:"originalPrice"`
	Price         uint          `json:"price"`
	Stock         int           `json:"stock"`
	Flag          string        `json:"flag"`
	Status        string        `json:"status"`
	OnlineTime    *TimeResponse `json:"onlineTime"`
	SalesVolumn   uint          `json:"salesVolumn"`
	Image         ImageResponse `json:"image"`
}

type ProductResponse struct {
	Id                 uint                      `json:"id"`
	Sku                string                    `json:"sku"`
	Name               string                    `json:"name"`
	Description        string                    `json:"description"`
	OriginalPrice      uint                      `json:"originalPrice"`
	Price              uint                      `json:"price"`
	Stock              int                       `json:"stock"`
	Flag               string                    `json:"flag"`
	Status             string                    `json:"status"`
	OnlineTime         *TimeResponse             `json:"onlineTime"`
	SalesVolumn        uint                      `json:"salesVolumn"`
	CreatedAt          TimeResponse              `json:"createdAt"`
	Category           CategoryResponse          `json:"category"`
	Images             []ImageResponse           `json:"images"`
	DetailImages       []ImageResponse           `json:"detailImages"`
	Specs              []ProductSpecResponse     `json:"specs"`
	SpecAttrs          []ProductSpecAttrResponse `json:"specAttrs"`
	EvaluateStatistics ProductEvaluateStatistics `json:"ealuateStatistics"`
}

type ProductEvaluateStatistics struct {
	TotalCount   uint               `json:"totalCount"`
	AverageScore float64            `json:"averageScore"`
	Evaluates    []EvaluateResponse `json:"evaluates"`
}
