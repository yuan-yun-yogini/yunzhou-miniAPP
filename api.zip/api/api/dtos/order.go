package dtos

type OrderSearchRequest struct {
	PageRequest
	Statuses  string `json:"statuses" form:"statuses"`
	ApiStatus string `json:"apiStatus" form:"apiStatus"`
}

type OrderCreateRequest struct {
	AddressId   uint               `json:"addressId" binding:"required"`
	CartIds     []uint             `json:"cartIds"`
	Product     *ProductAddRequest `json:"product"`
	CouponId    *uint              `json:"couponId"`
	Description string             `json:"description"`
}

type OrderUpdateRequest struct {
	Status string `json:"status" binding:"required"`
}

type OrderRefundRequest struct {
	OrderId  uint   `json:"orderId" binding:"required"`
	Amount   uint   `json:"amount" binding:"required"`
	Reason   string `json:"reason" binding:"required"`
	ImageIds []uint `json:"imageIds"`
}

type OrderEvaluateRequest struct {
	OrderId   uint                          `json:"orderId" binding:"required"`
	Evaluates []OrderProductEvaluateRequest `json:"evaluates"`
}

type OrderProductEvaluateRequest struct {
	OrderProductId uint   `json:"orderProductId"`
	Score          uint   `json:"score"`
	Content        string `json:"content"`
	ImageIds       []uint `json:"imageIds"`
}

type OrderResponse struct {
	Id             uint                   `json:"id"`
	OrderNo        string                 `json:"orderNo"`
	TotalAmount    uint                   `json:"totalAmount"`
	DiscountAmount uint                   `json:"discountAmount"`
	PayAmount      uint                   `json:"payAmount"`
	RefundAmount   uint                   `json:"refundAmount"`
	Description    string                 `json:"description"`
	Status         string                 `json:"status"`
	RefundStatus   string                 `json:"refundStatus"`
	EvaluateStatus string                 `json:"evaluateStatus"`
	CreatedAt      TimeResponse           `json:"createdAt"`
	OrderAddress   *OrderAddressResponse  `json:"orderAddress"`
	OrderProducts  []OrderProductResponse `json:"orderProducts"`
	OrderExpresses []OrderExpressResponse `json:"orderExpresses"`
	OrderRefund    *OrderRefundResponse   `json:"orderRefund"`
}

type OrderProductResponse struct {
	Id                  uint               `json:"id"`
	ProductId           uint               `json:"productId"`
	ProductName         string             `json:"productName"`
	ProductSpecAttrId   *uint              `json:"productSpecAttrId"`
	ProductSpecAttrName string             `json:"productSpecAttrName"`
	Quantity            uint               `json:"quantity"`
	Price               uint               `json:"price"`
	TotalAmount         uint               `json:"totalAmount"`
	DiscountAmount      uint               `json:"discountAmount"`
	PayAmount           uint               `json:"payAmount"`
	ProductImage        ImageResponse      `json:"productImage"`
	Resources           []ResourceResponse `json:"resources"`
	Evaluate            *EvaluateResponse  `json:"evaluate"`
}

type OrderAddressResponse struct {
	Id       uint   `json:"id"`
	Name     string `json:"name"`
	Phone    string `json:"phone"`
	Province string `json:"province"`
	City     string `json:"city"`
	District string `json:"district"`
	Detail   string `json:"detail"`
}

type OrderExpressResponse struct {
	Id          uint   `json:"id"`
	CompanyName string `json:"companyName"`
	ExpressNo   string `json:"expressNo"`
	Status      string `json:"status"`
}

type OrderRefundResponse struct {
	Id           uint            `json:"id"`
	Amount       uint            `json:"amount"`
	Reason       string          `json:"reason"`
	ReplyContent string          `json:"replyContent"`
	ReplyTime    *TimeResponse   `json:"replyTime"`
	RefundTime   *TimeResponse   `json:"refundTime"`
	Status       string          `json:"status"`
	Images       []ImageResponse `json:"images"`
}

type OrderStatisticsResponse struct {
	TotalCount    uint `json:"totalCount"`
	PendingCount  uint `json:"pendingCount"`
	PaidCount     uint `json:"paidCount"`
	ShippedCount  uint `json:"shippedCount"`
	EvaluateCount uint `json:"evaluateCount"`
	RefundCount   uint `json:"refundCount"`
}
