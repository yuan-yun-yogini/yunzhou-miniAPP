package dtos

type PayOrderRequest struct {
	OrderId    uint   `json:"orderId" binding:"required"`
	PayChannel string `json:"payChannel" binding:"required"`
	OpenId     string `json:"openId"`
}

type PayWxMpResponse struct {
	AppId     string `json:"appId"`
	TimeStamp string `json:"timeStamp"`
	NonceStr  string `json:"nonceStr"`
	Package   string `json:"package"`
	SignType  string `json:"signType"`
	PaySign   string `json:"paySign"`
}

type PayWxH5Response struct {
	Url string `json:"url"`
}

type PayWxJsapiResponse struct {
	AppId     string `json:"appId"`
	TimeStamp string `json:"timeStamp"`
	NonceStr  string `json:"nonceStr"`
	Package   string `json:"package"`
	SignType  string `json:"signType"`
	PaySign   string `json:"paySign"`
}
