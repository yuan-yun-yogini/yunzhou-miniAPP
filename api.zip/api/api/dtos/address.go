package dtos

type AddressRequest struct {
	Name      string `json:"name" binding:"required"`
	Phone     string `json:"phone" binding:"required,phonenumber"`
	Province  string `json:"province" binding:"required"`
	City      string `json:"city" binding:"required"`
	District  string `json:"district" binding:"required"`
	Detail    string `json:"detail" binding:"required"`
	IsDefault bool   `json:"isDefault"`
}

type AddressResponse struct {
	Id        uint   `json:"id"`
	Name      string `json:"name"`
	Phone     string `json:"phone"`
	Province  string `json:"province"`
	City      string `json:"city"`
	District  string `json:"district"`
	Detail    string `json:"detail"`
	IsDefault bool   `json:"isDefault"`
}
