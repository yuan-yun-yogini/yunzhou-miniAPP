package dtos

type CartRequest struct {
	ProductId         uint  `json:"productId"`
	ProductSpecAttrId *uint `json:"productSpecAttrId"`
	Quantity          uint  `json:"quantity"`
}

type CartResponse struct {
	Id              uint                     `json:"id"`
	Quantity        uint                     `json:"quantity"`
	Product         ProductListResponse      `json:"product"`
	ProductSpecAttr *ProductSpecAttrResponse `json:"productSpecAttr"`
	ErrorMessage    string                   `json:"errorMessage"`
}

type CartStatisticsResponse struct {
	TotalCount uint `json:"totalCount"`
}
