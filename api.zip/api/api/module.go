package api

import (
	"app/api/module"
	"app/api/router"
	"app/config"

	"github.com/gin-gonic/gin"
)

func Start(r *gin.Engine, cfg *config.ModuleConfig) {
	module.ModuleConfig = cfg

	router.InitRouter(r)
}
