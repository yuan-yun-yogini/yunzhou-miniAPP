package router

import (
	"app/api/controller"
	"app/api/middlewares"

	"github.com/gin-gonic/gin"
)

func InitRouter(r *gin.Engine) {
	public := r.Group("/api")
	{
		public.GET("/captcha", controller.GetCaptcha)
		public.POST("/login", controller.Login)
		public.POST("/register", controller.Register)
		public.POST("/wxMpOpenId", controller.CreateWxMpOpenId)
		public.POST("/loginWxMpPhone", controller.LoginWxMpPhone)
		public.GET("/wxMpAccessToken", controller.GetWxMpAccessToken)

		categorys := public.Group("/categorys")
		{
			categorys.GET("", controller.GetCategorys)
			categorys.GET("/:id", controller.GetCategory)
		}

		products := public.Group("/products")
		{
			products.GET("", controller.GetProducts)
			products.GET("/:id", controller.GetProduct)
		}

		evaluates := public.Group("/evaluates")
		{
			evaluates.GET("", controller.GetEvaluates)
		}

		configs := public.Group("/configs")
		{
			configs.GET("", controller.GetConfigs)
			configs.GET("/:id", controller.GetConfig)
		}

		public.GET("/areas", controller.GetAreas)
	}

	useUser := r.Group("/api")
	{
		useUser.Use(middlewares.UserMiddleware())

		banners := useUser.Group("/banners")
		{
			banners.GET("", controller.GetBanners)
			banners.GET("/:id", controller.GetBanner)
		}
	}

	private := r.Group("/api")
	{
		private.Use(middlewares.AuthMiddleware())

		private.POST("/images", controller.CreateImage)
		private.GET("/badges", controller.GetBadges)

		my := private.Group("/my")
		{
			my.GET("", controller.GetMyUser)
			my.PUT("", controller.UpdateMyUser)
		}

		addresses := private.Group("/addresses")
		{
			addresses.GET("", controller.GetAddresses)
			addresses.GET("/:id", controller.GetAddress)
			addresses.POST("", controller.CreateAddress)
			addresses.PUT("/:id", controller.UpdateAddress)
			addresses.DELETE("/:id", controller.DeletedAddress)
		}

		carts := private.Group("/carts")
		{
			carts.GET("", controller.GetCarts)
			carts.POST("", controller.CreateCart)
			carts.PUT("/:id", controller.UpdateCart)
			carts.DELETE("/:id", controller.DeletedCart)
		}
		private.GET("/cartStatistics", controller.GetCartStatistics)

		private.POST("/settles", controller.CreateSettle)
		private.POST("/payOrder", controller.CreatePayOrder)

		orders := private.Group("/orders")
		{
			orders.GET("", controller.GetOrders)
			orders.GET("/:id", controller.GetOrder)
			orders.POST("", controller.CreateOrder)
			orders.PUT("/:id", controller.UpdateOrder)
			orders.DELETE("/:id", controller.DeletedOrder)
		}
		private.GET("/orderStatistics", controller.GetOrderStatistics)

		orderRefunds := private.Group("/orderRefunds")
		{
			orderRefunds.POST("", controller.CreateOrderRefund)
			orderRefunds.DELETE("/:id", controller.DeletedOrderRefund)
		}

		orderEvaluates := private.Group("/orderEvaluates")
		{
			orderEvaluates.POST("", controller.CreateOrderEvaluate)
		}

		orderProductResources := private.Group("/orderProductResources")
		{
			orderProductResources.GET("", controller.GetOrderProductResources)
			orderProductResources.GET("/:id", controller.GetOrderProductResource)
		}
	}
}
