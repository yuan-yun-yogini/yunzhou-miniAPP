package module

import (
	"app/config"
)

var ModuleConfig *config.ModuleConfig
