package module

import (
	"errors"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

type Claims struct {
	UserId uint   `json:"userId"`
	Token  string `json:"token"`
	jwt.RegisteredClaims
}

// GenerateToken 生成JWT token
func GenerateToken(userId uint, refreshToken string) (string, time.Time, error) {
	expirationTime := time.Now().Add(time.Duration(ModuleConfig.JWT.Expiry) * time.Second)
	claims := &Claims{
		UserId: userId,
		Token:  refreshToken,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(expirationTime),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString([]byte(ModuleConfig.JWT.Secret))
	if err != nil {
		return "", expirationTime, err
	}

	return tokenString, expirationTime, nil
}

// ParseToken 解析JWT token
func ParseToken(tokenString string) (*Claims, error) {
	claims := &Claims{}

	token, err := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (any, error) {
		return []byte(ModuleConfig.JWT.Secret), nil
	})

	if err != nil {
		return nil, err
	}

	if !token.Valid {
		return nil, errors.New("invalid token")
	}

	return claims, nil
}
