package middlewares

import (
	"app/api/module"
	"app/global"
	"app/models"
	"strings"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
)

var userIdTokenMap sync.Map

type UserIdTokenValue struct {
	Token  string
	Expiry int64
}

// AuthMiddleware JWT认证中间件
func AuthMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		tokenString := ""
		authHeader := c.GetHeader("Authorization")
		if authHeader != "" {
			parts := strings.SplitN(authHeader, " ", 2)
			if !(len(parts) == 2 && parts[0] == "Bearer") {
				module.SendFailUnauthorizedResponse(c, "请登录")
				c.Abort()
				return
			}

			tokenString = parts[1]
		} else {
			if gin.Mode() == gin.DebugMode {
				cookie, err := c.Cookie("token")
				if err != nil {
					module.SendFailUnauthorizedResponse(c, "请登录")
					c.Abort()
					return
				}

				tokenString = cookie
			} else {
				module.SendFailUnauthorizedResponse(c, "请登录")
				c.Abort()
				return
			}
		}

		claims, err := module.ParseToken(tokenString)
		if err != nil {
			module.SendFailUnauthorizedResponse(c, "请重新登录")
			c.Abort()
			return
		}

		if !validRefreshToken(claims) {
			module.SendFailUnauthorizedResponse(c, "请重新登录")
			c.Abort()
			return
		}

		// 将用户信息存储到上下文中
		c.Set("userId", claims.UserId)

		c.Next()
	}
}

// 获取用户中间件
func UserMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		var userId uint = 0
		tokenString := ""
		authHeader := c.GetHeader("Authorization")
		if authHeader != "" {
			parts := strings.SplitN(authHeader, " ", 2)
			if len(parts) == 2 && parts[0] == "Bearer" {
				tokenString = parts[1]
			}

		} else {
			if gin.Mode() == gin.DebugMode {
				cookie, err := c.Cookie("token")
				if err == nil {
					tokenString = cookie
				}
			}
		}

		if tokenString != "" {
			claims, err := module.ParseToken(tokenString)
			if err == nil {
				userId = claims.UserId
			}
		}

		// 将用户信息存储到上下文中
		c.Set("userId", userId)

		c.Next()
	}
}

// 验证refreshToken
func validRefreshToken(claims *module.Claims) bool {
	//从内存中获取
	if value, ok := userIdTokenMap.Load(claims.UserId); ok {
		if v, o := value.(*UserIdTokenValue); o {
			if v.Expiry <= time.Now().UnixMilli() { //已过期
				userIdTokenMap.Delete(claims.UserId)
			} else {
				if v.Token == claims.Token {
					return true
				}
			}
		}
	}

	//从数据库中获取
	var user models.User
	if result := global.DB.Where("id = ?", claims.UserId).First(&user); result.Error != nil {
		return false
	}

	if user.LoginToken == "" {
		return false
	}

	userIdTokenMap.Store(user.Id, &UserIdTokenValue{
		Token:  user.LoginToken,
		Expiry: time.Now().UnixMilli() + 600000, //有效时间10分钟
	})

	if user.LoginToken == claims.Token {
		return true
	}

	return false
}
