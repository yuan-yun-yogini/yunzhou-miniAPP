package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"app/utils"
	"image"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"log"
	"path/filepath"
	"strings"

	"github.com/gin-gonic/gin"
)

// @Tags Api图片管理
// @Summary 创建图片
// @Produce json
// @Param file formData file true "图片"
// @Success 200 {object} dtos.ImageResponse "图片信息"
// @Router /api/images [post]
func CreateImage(c *gin.Context) {
	file, err := c.FormFile("file")
	if err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}
	log.Println(file.Filename)

	// 验证文件扩展名
	ext := strings.ToLower(filepath.Ext(file.Filename))
	if ext != ".jpg" && ext != ".jpeg" && ext != ".png" {
		module.SendFailBadRequestResponse(c, "不支持的文件格式")
		return
	}

	// 验证图片大小
	if file.Size >= 2*1024*1024 {
		module.SendFailBadRequestResponse(c, "图片大小不能超过2MB")
		return
	}

	// 读取文件流
	reader, err := file.Open()
	if err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}
	defer reader.Close()

	imgConfig, _, err := image.DecodeConfig(reader)
	if err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	reader.Seek(0, io.SeekStart)
	hash := utils.Md5Reader(reader)

	var img models.Image
	if result := global.DB.Where("hash = ?", hash).Where("acl = ?", config.AclPublic).First(&img); result.Error != nil {
		reader.Seek(0, io.SeekStart)
		url, err1 := service.UploadPublicReader(reader, "images/"+hash+ext)
		if err1 != nil {
			module.SendErrorInternalServerResponse(c, err1)
			return
		}

		img = models.Image{
			Acl:    config.AclPublic,
			Type:   ext,
			Size:   uint(file.Size),
			Hash:   hash,
			Width:  imgConfig.Width,
			Height: imgConfig.Height,
			Url:    url,
		}

		global.DB.Create(&img)
	}

	dto := dtos.ImageResponse{}
	utils.CopyObject(&img, &dto)

	module.SendSuccessResponse(c, "上传成功", dto)
}
