package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"app/utils"
	"strconv"

	"github.com/gin-gonic/gin"
)

// @Tags Api数字产品管理
// @Summary 获取数字产品列表
// @Produce json
// @Param offset query int false "跳过条数"
// @Param limit query int false "获取条数"
// @Param sort query string false "排序"
// @Success 200 {array} dtos.OrderProductResponse "数字产品列表"
// @Router /api/orderProductResources [get]
func GetOrderProductResources(c *gin.Context) {
	var req dtos.PageRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	userId := c.MustGet("userId").(uint)
	statuses := []string{config.OrderStatusPaid, config.OrderStatusShipped, config.OrderStatusDelivered, config.OrderStatusCompleted}

	db := global.DB.Model(&models.OrderProduct{}).Where("user_id = ?", userId).Where("resource_ids <> ?", "").Where("status in ?", statuses)

	db = db.Order("id desc")

	if req.Limit == 0 {
		req.Limit = 10
	}
	if req.Limit > 50 {
		req.Limit = 50
	}
	db = db.Offset(int(req.Offset)).Limit(int(req.Limit))

	db = db.Preload("ProductImage")

	var orderProducts []models.OrderProduct
	db.Find(&orderProducts)

	var dtoList []dtos.OrderProductResponse
	utils.CopyObject(&orderProducts, &dtoList)

	module.SendSuccessResponse(c, "", dtoList)
}

// @Tags Api数字产品管理
// @Summary 获取数字产品信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.OrderProductResponse "数字产品信息"
// @Router /sys/orderProductResources/{id} [get]
func GetOrderProductResource(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	userId := c.MustGet("userId").(uint)
	statuses := []string{config.OrderStatusPaid, config.OrderStatusShipped, config.OrderStatusDelivered, config.OrderStatusCompleted}

	var orderProduct models.OrderProduct
	if result := global.DB.Where("id = ?", id).Where("user_id = ?", userId).Where("resource_ids <> ?", "").Where("status in ?", statuses).Preload("ProductImage").First(&orderProduct); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.OrderProductResponse
	utils.CopyObject(&orderProduct, &dto)

	resourceList := service.LoadResourceListWithIds([]string{orderProduct.ResourceIds})
	if len(resourceList[0]) == 0 {
		module.SendFailBadRequestResponse(c, "数字产品已被删除，请联系客服")
		return
	}

	utils.CopyObject(&resourceList[0], &dto.Resources)

	for i := range resourceList[0] {
		url, err := service.GetUploadFileUrl(resourceList[0][i].Filename, resourceList[0][i].Acl)
		if err != nil {
			module.SendErrorInternalServerResponse(c, err)
			return
		}

		dto.Resources[i].Url = url
	}

	module.SendSuccessResponse(c, "", dto)
}
