package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/config"
	"app/global"
	"app/models"
	"app/utils"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

// @Tags Api配置管理
// @Summary 获取配置列表
// @Produce json
// @Param configKeys query []string false "类型" collectionFormat(csv)
// @Success 200 {array} dtos.ConfigResponse "配置列表"
// @Router /api/configs [get]
func GetConfigs(c *gin.Context) {
	var req dtos.ConfigSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	db := global.DB.Model(&models.Config{}).Where("acl = ?", config.AclPublic)

	if req.ConfigKeys != "" {
		configKeys := strings.Split(req.ConfigKeys, ",")
		db = db.Where("config_key in ?", configKeys)
	}

	db = db.Order("config_key asc")

	var configs []models.Config
	db.Find(&configs)

	var dtoList []dtos.ConfigResponse
	utils.CopyObject(&configs, &dtoList)

	for i := range dtoList {
		if dtoList[i].Type == config.ConfigTypeImage && dtoList[i].ConfigValue != "" {
			imageId, _ := strconv.Atoi(dtoList[i].ConfigValue)

			var image models.Image
			global.DB.Where("id = ?", imageId).First(&image)

			imageDto := dtos.ImageResponse{}
			utils.CopyObject(&image, &imageDto)

			dtoList[i].Image = &imageDto
		}
	}

	module.SendSuccessResponse(c, "", dtoList)
}

// @Tags Api配置管理
// @Summary 获取配置信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.ConfigResponse "配置信息"
// @Router /api/configs/{id} [get]
func GetConfig(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var model models.Config
	if result := global.DB.Where("acl = ?", config.AclPublic).Where("id = ?", id).First(&model); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.ConfigResponse
	utils.CopyObject(&model, &dto)

	if dto.Type == config.ConfigTypeImage && dto.ConfigValue != "" {
		imageId, _ := strconv.Atoi(dto.ConfigValue)

		var image models.Image
		global.DB.Where("id = ?", imageId).First(&image)

		imageDto := dtos.ImageResponse{}
		utils.CopyObject(&image, &imageDto)

		dto.Image = &imageDto
	}

	module.SendSuccessResponse(c, "", dto)
}
