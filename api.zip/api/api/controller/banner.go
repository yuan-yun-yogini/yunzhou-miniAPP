package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/config"
	"app/global"
	"app/models"
	"app/utils"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

// @Tags Api广告管理
// @Summary 获取广告列表
// @Produce json
// @Param types query []string false "类型" collectionFormat(csv)
// @Success 200 {array} dtos.BannerResponse "广告列表"
// @Router /api/banners [get]
func GetBanners(c *gin.Context) {
	var req dtos.BannerSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	db := global.DB.Model(&models.Banner{}).Where("status = ?", config.CommonStatusEnable)

	if req.Types != "" {
		types := strings.Split(req.Types, ",")
		db = db.Where("type in ?", types)
	}

	userId := c.MustGet("userId").(uint)
	if userId > 0 {
		db = db.Where(global.DB.Where("login_status = ?", "").Or("login_status = ?", config.BannerLoginStatusYes))
	} else {
		db = db.Where(global.DB.Where("login_status = ?", "").Or("login_status = ?", config.BannerLoginStatusNo))
	}

	db = db.Order("type asc,sort desc")

	var banners []models.Banner
	db.Preload("Image").Find(&banners)

	var dtoList []dtos.BannerResponse
	utils.CopyObject(&banners, &dtoList)

	module.SendSuccessResponse(c, "", dtoList)
}

// @Tags Api广告管理
// @Summary 获取广告信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.BannerResponse "广告信息"
// @Router /api/banners/{id} [get]
func GetBanner(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var banner models.Banner
	if result := global.DB.Where("id = ?", id).Preload("Image").First(&banner); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.BannerResponse
	utils.CopyObject(&banner, &dto)

	module.SendSuccessResponse(c, "", dto)
}
