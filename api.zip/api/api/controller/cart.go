package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/global"
	"app/models"
	"app/service"
	"app/utils"
	"strconv"

	"github.com/gin-gonic/gin"
)

// @Tags Api购物车管理
// @Summary 获取购物车列表
// @Produce json
// @Success 200 {array} dtos.CartResponse "购物车列表"
// @Router /api/carts [get]
func GetCarts(c *gin.Context) {
	userId := c.MustGet("userId").(uint)

	var carts []models.Cart
	global.DB.Where("user_id = ?", userId).Preload("Product.Image").Preload("ProductSpecAttr.Image").Order("id desc").Find(&carts)

	reqProducts := make([]service.ProductCheckRequest, len(carts))
	for i, item := range carts {
		reqProducts[i] = service.ProductCheckRequest{
			Id:         item.ProductId,
			SpecAttrId: item.ProductSpecAttrId,
			Quantity:   item.Quantity,
		}
	}

	errs := service.CheckProducts(&reqProducts)

	dtoList := []dtos.CartResponse{}
	dtoErrorList := []dtos.CartResponse{}

	for i, item := range carts {
		dto := dtos.CartResponse{}
		utils.CopyObject(&item, &dto)

		if errs[i] == nil {
			dto.ErrorMessage = ""
			dtoList = append(dtoList, dto)
		} else {
			dto.ErrorMessage = errs[i].Error()
			dtoErrorList = append(dtoErrorList, dto)
		}
	}

	for _, item := range dtoErrorList {
		dtoList = append(dtoList, item)
	}

	module.SendSuccessResponse(c, "", dtoList)
}

// @Tags Api购物车管理
// @Summary 创建购物车信息
// @Produce json
// @Param body body []dtos.CartRequest true "购物车信息"
// @Success 200 {object} dtos.CartStatisticsResponse "购物车统计信息"
// @Router /api/carts [post]
func CreateCart(c *gin.Context) {
	var reqs []dtos.CartRequest
	if err := c.ShouldBind(&reqs); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	if len(reqs) == 0 {
		module.SendFailBadRequestResponse(c, "参数错误")
		return
	}

	userId := c.MustGet("userId").(uint)

	reqProducts := []service.ProductCheckRequest{}
	carts := []models.Cart{}

	for _, req := range reqs {
		db := global.DB.Where("user_id = ?", userId).Where("product_id = ?", req.ProductId)
		if req.ProductSpecAttrId != nil && *req.ProductSpecAttrId != 0 {
			db = db.Where("product_spec_attr_id = ?", req.ProductSpecAttrId)
		}

		var cart models.Cart
		if result := db.First(&cart); result.Error != nil { //增加
			cart = models.Cart{
				UserId: userId,
			}
			utils.CopyObject(&req, &cart)
		} else { //修改
			cart.Quantity += uint(req.Quantity)
		}

		carts = append(carts, cart)

		reqProduct := service.ProductCheckRequest{
			Id:         req.ProductId,
			SpecAttrId: req.ProductSpecAttrId,
			Quantity:   cart.Quantity,
		}
		reqProducts = append(reqProducts, reqProduct)
	}

	errs := service.CheckProducts(&reqProducts)

	var addCount uint = 0

	for i, cart := range carts {
		if errs[i] == nil {
			addCount++

			if cart.Id > 0 {
				global.DB.Save(&cart)
			} else {
				global.DB.Create(&cart)
			}
		}
	}

	if addCount == 0 {
		module.SendErrorBadRequestResponse(c, errs[0])
		return
	}

	dto := getCartStatisticsData(userId)

	module.SendSuccessResponse(c, "创建成功", dto)
}

// @Tags Api购物车管理
// @Summary 更新购物车信息
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.CartRequest true "购物车信息"
// @Success 200 {object} dtos.CartStatisticsResponse "购物车统计信息"
// @Router /api/carts/{id} [put]
func UpdateCart(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.CartRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	reqProduct := service.ProductCheckRequest{
		Id:         req.ProductId,
		SpecAttrId: req.ProductSpecAttrId,
		Quantity:   req.Quantity,
	}
	if err := service.CheckProduct(&reqProduct); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	userId := c.MustGet("userId").(uint)

	var cart models.Cart
	if result := global.DB.Where("user_id = ?", userId).Where("id = ?", id).First(&cart); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	cart.Quantity = req.Quantity
	global.DB.Save(&cart)

	dto := getCartStatisticsData(userId)

	module.SendSuccessResponse(c, "更新成功", dto)
}

// @Tags Api购物车管理
// @Summary 删除购物车信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.CartStatisticsResponse "购物车统计信息"
// @Router /api/carts/{id} [delete]
func DeletedCart(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	userId := c.MustGet("userId").(uint)

	if result := global.DB.Where("user_id = ?", userId).Where("id = ?", id).Delete(&models.Cart{}); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	dto := getCartStatisticsData(userId)

	module.SendSuccessResponse(c, "删除成功", dto)
}

// @Tags Api购物车管理
// @Summary 获取购物车统计信息
// @Produce json
// @Success 200 {object} dtos.CartStatisticsResponse "购物车列表"
// @Router /api/cartStatistics [get]
func GetCartStatistics(c *gin.Context) {
	userId := c.MustGet("userId").(uint)

	dto := getCartStatisticsData(userId)

	module.SendSuccessResponse(c, "", dto)
}

func getCartStatisticsData(userId uint) dtos.CartStatisticsResponse {
	var count int64
	global.DB.Model(&models.Cart{}).Where("user_id = ?", userId).Count(&count)

	return dtos.CartStatisticsResponse{
		TotalCount: uint(count),
	}
}
