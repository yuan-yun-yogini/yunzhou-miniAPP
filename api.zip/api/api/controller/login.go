package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"app/utils"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
)

// @Tags Api登录
// @Summary 登录
// @Produce json
// @Param body body dtos.UserLoginRequest true "登录信息"
// @Success 200 {object} dtos.UserLoginResponse "登录结果"
// @Router /api/login [post]
func Login(c *gin.Context) {
	var req dtos.UserLoginRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	if gin.Mode() != gin.DebugMode {
		if !service.VerifyCaptcha(req.CaptchaId, req.CaptchaAnswer) {
			module.SendFailBadRequestResponse(c, "验证码错误")
			return
		}
	}

	var user models.User
	if result := global.DB.Where("username = ?", strings.ToLower(req.Username)).Preload("Avatar").First(&user); result.Error != nil {
		module.SendFailBadRequestResponse(c, "用户名或密码错误")
		return
	}

	if !user.CheckPassword(req.Password) {
		module.SendFailBadRequestResponse(c, "用户名或密码错误")
		return
	}

	if user.Status == config.CommonStatusDisable {
		module.SendFailForbiddenResponse(c, "用户已被禁用，请联系客服")
		return
	}

	user.LoginToken = utils.GenerateRandomString(32)

	token, expire, err := module.GenerateToken(user.Id, user.LoginToken)
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	user.LoginIp = c.ClientIP()
	loginTime := time.Now()
	user.LoginTime = &loginTime
	global.DB.Select("LoginToken", "LoginIp", "LoginTime").Save(&user)

	var userDto dtos.UserResponse
	utils.CopyObject(&user, &userDto)

	if gin.Mode() == gin.DebugMode {
		c.SetCookie("token", token, int(expire.Unix()-time.Now().Unix()), "/", "localhost", false, false)
	}

	module.SendSuccessResponse(c, "", dtos.UserLoginResponse{
		Token:  token,
		Expire: uint(expire.UnixMilli()),
		User:   userDto,
	})
}

// @Tags Api登录
// @Summary 注册
// @Produce json
// @Param body body dtos.UserRegisterRequest true "注册信息"
// @Success 200 {object} dtos.BaseResponse "注册结果"
// @Router /api/register [post]
func Register(c *gin.Context) {
	var req dtos.UserRegisterRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	if !service.VerifyCaptcha(req.CaptchaId, req.CaptchaAnswer) {
		module.SendFailBadRequestResponse(c, "验证码错误")
		return
	}

	var user models.User
	if result := global.DB.Where("username = ?", strings.ToLower(req.Username)).First(&user); result.Error == nil {
		module.SendFailBadRequestResponse(c, "用户名已存在")
		return
	}

	user = models.User{}
	user.Username = strings.ToLower(req.Username)
	user.Password = req.Password
	user.Name = "用户" + utils.GenerateRandomString(4)

	if req.InviterId != nil && *req.InviterId != 0 {
		user.InviterId = req.InviterId
	}

	user.Status = config.CommonStatusEnable

	if result := global.DB.Create(&user); result.Error != nil {
		module.SendErrorInternalServerResponse(c, result.Error)
		return
	}

	module.SendSuccessResponse(c, "", nil)
}
