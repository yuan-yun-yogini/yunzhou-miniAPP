package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/service"

	"github.com/gin-gonic/gin"
)

// @Tags Api登录
// @Summary 获取图形验证码
// @Produce json
// @Success 200 {object} dtos.CaptchaResponse "验证码信息"
// @Router /api/captcha [get]
func GetCaptcha(c *gin.Context) {
	id, b64s, _, err := service.GenerateCaptcha()
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	module.SendSuccessResponse(c, "", dtos.CaptchaResponse{
		Id:        id,
		ImageData: b64s,
	})
}
