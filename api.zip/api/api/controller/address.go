package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/global"
	"app/models"
	"app/utils"
	"strconv"

	"github.com/gin-gonic/gin"
)

// @Tags Api收货地址管理
// @Summary 获取收货地址列表
// @Produce json
// @Success 200 {array} dtos.AddressResponse "收货地址列表"
// @Router /api/addresses [get]
func GetAddresses(c *gin.Context) {
	userId := c.MustGet("userId").(uint)

	var addresses []models.Address
	global.DB.Where("user_id = ?", userId).Order("is_default desc, id desc").Find(&addresses)

	var dtoList []dtos.AddressResponse
	utils.CopyObject(&addresses, &dtoList)

	module.SendSuccessResponse(c, "", dtoList)
}

// @Tags Api收货地址管理
// @Summary 获取收货地址信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.BannerResponse "收货地址信息"
// @Router /sys/addresses/{id} [get]
func GetAddress(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	userId := c.MustGet("userId").(uint)

	var address models.Address
	if id == 0 {
		if result := global.DB.Where("user_id = ?", userId).Where("is_default = ?", true).First(&address); result.Error != nil {
			if result1 := global.DB.Where("user_id = ?", userId).Order("id desc").First(&address); result1.Error != nil {
				module.SendSuccessResponse(c, "", nil)
				return
			}
		}
	} else {
		if result := global.DB.Where("user_id = ?", userId).Where("id = ?", id).First(&address); result.Error != nil {
			module.SendErrorBadRequestResponse(c, result.Error)
			return
		}
	}

	var dto dtos.AddressResponse
	utils.CopyObject(&address, &dto)

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Api收货地址管理
// @Summary 创建收货地址信息
// @Produce json
// @Param body body dtos.AddressRequest true "收货地址信息"
// @Success 200 {object} dtos.AddressResponse "收货地址信息"
// @Router /api/addresses [post]
func CreateAddress(c *gin.Context) {
	var req dtos.AddressRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var address models.Address
	utils.CopyObject(&req, &address)

	userId := c.MustGet("userId").(uint)
	address.UserId = userId

	global.DB.Create(&address)

	if address.IsDefault {
		global.DB.Model(&models.Address{}).Where("user_id = ?", userId).Where("id <> ?", address.Id).Update("is_default", 0)
	}

	var dto dtos.AddressResponse
	utils.CopyObject(&address, &dto)

	module.SendSuccessResponse(c, "创建成功", dto)
}

// @Tags Api收货地址管理
// @Summary 更新收货地址信息
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.AddressRequest true "收货地址信息"
// @Success 200 {object} dtos.AddressResponse "收货地址信息"
// @Router /api/addresses/{id} [put]
func UpdateAddress(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.AddressRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	userId := c.MustGet("userId").(uint)

	var address models.Address
	if result := global.DB.Where("user_id = ?", userId).Where("id = ?", id).First(&address); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	utils.CopyObject(&req, &address)
	global.DB.Save(&address)

	if address.IsDefault {
		global.DB.Model(&models.Address{}).Where("user_id = ?", userId).Where("id <> ?", id).Update("is_default", 0)
	}

	GetAddress(c)
}

// @Tags Api收货地址管理
// @Summary 删除收货地址信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.BaseResponse "删除结果"
// @Router /api/addresses/{id} [delete]
func DeletedAddress(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	userId := c.MustGet("userId").(uint)

	if result := global.DB.Where("user_id = ?", userId).Where("id = ?", id).Delete(&models.Address{}); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	module.SendSuccessResponse(c, "删除成功", nil)
}
