package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/global"
	"app/models"
	"app/service"
	"app/utils"

	"github.com/gin-gonic/gin"
)

// @Tags Api评价管理
// @Summary 获取评价列表
// @Produce json
// @Param offset query int false "跳过条数"
// @Param limit query int false "获取条数"
// @Param sort query string false "排序"
// @Param productId query int false "产品id"
// @Param productSpecAttrId query int false "产品规格id"
// @Param minScore query int false "最小分数"
// @Param maxScore query int false "最大分数"
// @Param status query string false "状态"
// @Success 200 {array} dtos.EvaluateResponse "评价列表"
// @Router /api/evaluates [get]
func GetEvaluates(c *gin.Context) {
	var req dtos.EvaluateSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	db := global.DB.Model(&models.OrderProductEvaluate{})

	if req.ProductId > 0 {
		db = db.Where("product_id = ?", req.ProductId)
	}
	if req.ProductSpecAttrId > 0 {
		db = db.Where("product_spec_attr_id = ?", req.ProductSpecAttrId)
	}
	if req.MinScore != nil {
		db = db.Where("score >= ?", req.MinScore)
	}
	if req.MaxScore != nil {
		db = db.Where("score <= ?", req.MaxScore)
	}
	if req.Status != "" {
		db = db.Where("status = ?", req.Status)
	}

	switch req.Sort {
	case "scoreAsc":
		db = db.Order("score asc")
	case "scoreDesc":
		db = db.Order("score desc")
	default:
		db = db.Order("id desc")
	}

	if req.Limit == 0 {
		req.Limit = 10
	}
	if req.Limit > 50 {
		req.Limit = 50
	}
	db = db.Offset(int(req.Offset)).Limit(int(req.Limit))

	db = db.Preload("User.Avatar")

	var evaluates []models.OrderProductEvaluate
	db.Find(&evaluates)

	imageIdsList := []string{}
	appendImageIdsList := []string{}
	for _, item := range evaluates {
		imageIdsList = append(imageIdsList, item.ImageIds)
		appendImageIdsList = append(appendImageIdsList, item.AppendImageIds)
	}

	imagesList := service.LoadImageListWithIds(imageIdsList)
	appendImagesList := service.LoadImageListWithIds(appendImageIdsList)

	var dtoList []dtos.EvaluateResponse
	utils.CopyObject(&evaluates, &dtoList)

	for i := range dtoList {
		utils.CopyObject(&imagesList[i], &dtoList[i].Images)
		utils.CopyObject(&appendImagesList[i], &dtoList[i].AppendImages)

		dtoList[i].User.Name = utils.AnonymousName(dtoList[i].User.Name)
	}

	module.SendSuccessResponse(c, "", dtoList)
}
