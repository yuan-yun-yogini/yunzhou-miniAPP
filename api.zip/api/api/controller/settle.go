package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"app/utils"

	"github.com/gin-gonic/gin"
)

// @Tags Api结算管理
// @Summary 创建结算信息
// @Produce json
// @Param body body dtos.SettleRequest true "结算信息"
// @Success 200 {object} dtos.SettleResponse "结算信息"
// @Router /api/settles [post]
func CreateSettle(c *gin.Context) {
	var req dtos.SettleRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	userId := c.MustGet("userId").(uint)

	reqProducts := []dtos.ProductAddRequest{}

	if len(req.CartIds) > 0 {
		var carts []models.Cart
		global.DB.Where("user_id = ?", userId).Where("id in ?", req.CartIds).Find(&carts)
		for _, item := range carts {
			reqProducts = append(reqProducts, dtos.ProductAddRequest{
				Id:         item.ProductId,
				SpecAttrId: item.ProductSpecAttrId,
				Quantity:   item.Quantity,
			})
		}
	}

	if req.Product != nil {
		reqProducts = append(reqProducts, *req.Product)
	}

	if len(reqProducts) == 0 {
		module.SendFailBadRequestResponse(c, "请选择商品")
		return
	}

	productIds := []uint{}
	productSpecAttrIds := []uint{}

	for _, item := range reqProducts {
		productIds = append(productIds, item.Id)

		if item.SpecAttrId != nil {
			productSpecAttrIds = append(productSpecAttrIds, *item.SpecAttrId)
		}
	}

	var products []models.Product
	global.DB.Where("status = ?", config.ProductStatusOnline).Where("id in ?", productIds).Preload("Image").Find(&products)

	productSpecAttrs := []models.ProductSpecAttr{}
	if len(productSpecAttrIds) > 0 {
		global.DB.Where("id in ?", productSpecAttrIds).Preload("Image").Find(&productSpecAttrs)
	}

	var reqCheckProducts []service.ProductCheckRequest
	utils.CopyObject(&reqProducts, &reqCheckProducts)
	errs := service.CheckProductsWithModel(&reqCheckProducts, &products, &productSpecAttrs)
	for _, item := range errs {
		if item != nil {
			module.SendErrorBadRequestResponse(c, item)
			return
		}
	}

	productMap := map[uint]models.Product{}
	productSpecAttrMap := map[uint]models.ProductSpecAttr{}

	for _, item := range products {
		productMap[item.Id] = item
	}

	for _, item := range productSpecAttrs {
		productSpecAttrMap[item.Id] = item
	}

	settle := dtos.SettleResponse{}

	for _, item := range reqProducts {
		var settleProduct dtos.SettleProductResponse

		product := productMap[item.Id]
		utils.CopyObject(&product, &settleProduct.Product)

		if item.SpecAttrId != nil {
			productSpecAttr := productSpecAttrMap[*item.SpecAttrId]

			var dto dtos.ProductSpecAttrResponse
			utils.CopyObject(&productSpecAttr, &dto)

			settleProduct.ProductSpecAttr = &dto

			settleProduct.Price = settleProduct.ProductSpecAttr.Price
		} else {
			settleProduct.Price = settleProduct.Product.Price
		}

		settleProduct.Quantity = item.Quantity
		settleProduct.TotalAmount = settleProduct.Price * settleProduct.Quantity
		settleProduct.DiscountAmount = 0
		settleProduct.PayAmount = settleProduct.TotalAmount - settleProduct.DiscountAmount

		settle.TotalAmount += settleProduct.TotalAmount
		settle.DiscountAmount += settle.DiscountAmount

		settle.Products = append(settle.Products, settleProduct)
	}

	settle.PayAmount = settle.TotalAmount - settle.DiscountAmount

	module.SendSuccessResponse(c, "创建成功", settle)
}
