package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/global"
	"app/models"
	"app/utils"
	"strconv"

	"github.com/gin-gonic/gin"
)

// @Tags Api产品管理
// @Summary 获取产品分类列表
// @Produce json
// @Success 200 {array} dtos.CategoryResponse "产品分类列表"
// @Router /api/categorys [get]
func GetCategorys(c *gin.Context) {
	var categorys []models.Category

	global.DB.Model(&models.Category{}).Order("id asc").Preload("Image").Find(&categorys)

	var dtoList []dtos.CategoryResponse
	utils.CopyObject(&categorys, &dtoList)

	module.SendSuccessResponse(c, "", dtoList)
}

// @Tags Api产品管理
// @Summary 获取产品分类信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.CategoryResponse "产品分类信息"
// @Router /api/categorys/{id} [get]
func GetCategory(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var category models.Category
	if result := global.DB.Where("id = ?", id).Preload("Image").First(&category); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.CategoryResponse
	utils.CopyObject(&category, &dto)

	module.SendSuccessResponse(c, "", dto)
}
