package controller

import (
	"app/api/dtos"
	"app/api/module"

	"github.com/gin-gonic/gin"
)

// @Tags Api角标管理
// @Summary 获取角标信息
// @Produce json
// @Success 200 {object} dtos.BadgeResponse "角标列表"
// @Router /api/badges [get]
func GetBadges(c *gin.Context) {
	userId := c.MustGet("userId").(uint)

	var dto dtos.BadgeResponse

	cart := getCartStatisticsData(userId)
	dto.CartCount = cart.TotalCount

	order := getOrderStatisticsData(userId)
	if order.PendingCount > 0 {
		dto.MyCount += 1
	}
	if order.PaidCount > 0 {
		dto.MyCount += 1
	}
	if order.ShippedCount > 0 {
		dto.MyCount += 1
	}
	if order.EvaluateCount > 0 {
		dto.MyCount += 1
	}
	if order.RefundCount > 0 {
		dto.MyCount += 1
	}

	module.SendSuccessResponse(c, "", dto)
}
