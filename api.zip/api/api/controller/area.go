package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/global"
	"app/models"
	"app/utils"

	"github.com/gin-gonic/gin"
)

// @Tags Api区域管理
// @Summary 获取区域列表
// @Produce json
// @Success 200 {array} dtos.AreaResponse "区域列表"
// @Router /api/areas [get]
func GetAreas(c *gin.Context) {
	var areas []models.Area
	global.DB.Select("code", "parent_code", "name", "level").Order("id asc").Find(&areas)

	var dtoList []dtos.AreaResponse
	utils.CopyObject(&areas, &dtoList)

	module.SendSuccessResponse(c, "", dtoList)
}
