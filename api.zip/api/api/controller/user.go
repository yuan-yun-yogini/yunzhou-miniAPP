package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/global"
	"app/models"
	"app/utils"

	"github.com/gin-gonic/gin"
)

// @Tags Api用户管理
// @Summary 获取我的信息
// @Produce json
// @Success 200 {object} dtos.UserResponse "用户信息"
// @Router /api/my [get]
func GetMyUser(c *gin.Context) {
	id := c.MustGet("userId").(uint)

	var user models.User
	if result := global.DB.Where("id = ?", id).Preload("Avatar").First(&user); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.UserResponse
	utils.CopyObject(&user, &dto)

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Api用户管理
// @Summary 更新我的信息
// @Produce json
// @Param body body dtos.UserRequest true "用户信息"
// @Success 200 {object} dtos.UserResponse "用户信息"
// @Router /api/my [put]
func UpdateMyUser(c *gin.Context) {
	id := c.MustGet("userId").(uint)

	var req dtos.UserRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	var user models.User
	if result := global.DB.Where("id = ?", id).First(&user); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	db := global.DB

	if req.Password != "" && req.OldPassword != "" {
		if !user.CheckPassword(req.OldPassword) {
			module.SendFailBadRequestResponse(c, "旧密码错误")
			return
		}

		user.Password = req.Password
	} else {
		db = db.Omit("Password")
	}

	if req.Name != "" {
		user.Name = req.Name
	}
	if req.Phone != "" {
		user.Phone = req.Phone
	}
	if req.AvatarId != nil {
		user.AvatarId = req.AvatarId
	}

	db.Save(&user)

	GetMyUser(c)
}
