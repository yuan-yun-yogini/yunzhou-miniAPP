package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"app/utils"
	"encoding/json"
	"fmt"
	"math"
	"strconv"

	"github.com/gin-gonic/gin"
)

// @Tags Api产品管理
// @Summary 获取产品列表
// @Produce json
// @Param offset query int false "跳过条数"
// @Param limit query int false "获取条数"
// @Param sort query string false "排序"
// @Param id query int false "id"
// @Param categoryId query int false "分类id"
// @Param name query string false "名称"
// @Success 200 {array} dtos.ProductListResponse "产品列表"
// @Router /api/products [get]
func GetProducts(c *gin.Context) {
	var req dtos.ProductSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	categoryIds := ""
	if req.CategoryId > 0 {
		var category models.Category
		if result := global.DB.Where("id = ?", req.CategoryId).First(&category); result.Error != nil {
			module.SendErrorBadRequestResponse(c, result.Error)
			return
		}

		if category.ParentIds != "" {
			categoryIds = fmt.Sprintf("%s%d,", category.ParentIds, category.Id)
		} else {
			categoryIds = fmt.Sprintf(",%d,", category.Id)
		}
	}

	db := global.DB.Model(&models.Product{}).Where("status = ?", config.ProductStatusOnline)

	if req.Id > 0 {
		db = db.Where("id = ?", req.Id)
	}
	if categoryIds != "" {
		db = db.Where("category_ids like ?", fmt.Sprintf("%s%%", categoryIds))
	}
	if req.Name != "" {
		db = db.Where("name like ?", fmt.Sprintf("%%%s%%", req.Name))
	}

	switch req.Sort {
	case "priceAsc":
		db = db.Order("price asc")
	case "priceDesc":
		db = db.Order("price desc")
	case "salesVolumnAsc":
		db = db.Order("sales_volumn asc")
	case "salesVolumnDesc":
		db = db.Order("sales_volumn desc")
	default:
		db = db.Order("sort desc,id desc")
	}

	if req.Limit == 0 {
		req.Limit = 10
	}
	if req.Limit > 50 {
		req.Limit = 50
	}
	db = db.Offset(int(req.Offset)).Limit(int(req.Limit))

	db = db.Preload("Image")

	var products []models.Product
	db.Find(&products)

	var dtoList []dtos.ProductListResponse
	utils.CopyObject(&products, &dtoList)

	module.SendSuccessResponse(c, "", dtoList)
}

// @Tags Api产品管理
// @Summary 获取产品信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.ProductResponse "产品信息"
// @Router /api/products/{id} [get]
func GetProduct(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var product models.Product
	if result := global.DB.Where("id = ?", id).Where("status = ?", config.ProductStatusOnline).Preload("Category").First(&product); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.ProductResponse
	utils.CopyObject(&product, &dto)

	if product.ImageIds != "" {
		imageList := service.LoadImageListWithIds([]string{product.ImageIds})
		utils.CopyObject(&imageList[0], &dto.Images)
	}

	if product.DetailImageIds != "" {
		imageList := service.LoadImageListWithIds([]string{product.DetailImageIds})
		utils.CopyObject(&imageList[0], &dto.DetailImages)
	}

	var specs []models.ProductSpec
	global.DB.Where("product_id = ?", product.Id).Order("id asc").Find(&specs)

	specDtos := []dtos.ProductSpecResponse{}
	for _, item := range specs {
		specDto := dtos.ProductSpecResponse{
			Id:   item.Id,
			Name: item.Name,
		}

		json.Unmarshal([]byte(item.Attrs), &specDto.Attrs)
		specDtos = append(specDtos, specDto)
	}

	dto.Specs = specDtos

	var specAttrs []models.ProductSpecAttr
	global.DB.Where("product_id = ?", product.Id).Preload("Image").Order("id asc").Find(&specAttrs)
	utils.CopyObject(&specAttrs, &dto.SpecAttrs)

	type CountAvg struct {
		TotalCount   uint
		AverageScore float64
	}
	var countAvg CountAvg
	global.DB.Model(&models.OrderProductEvaluate{}).Where("product_id = ?", product.Id).Select("count(*) as total_count,IFNULL(avg(score),0) as average_score").Find(&countAvg)

	dto.EvaluateStatistics.TotalCount = countAvg.TotalCount
	dto.EvaluateStatistics.AverageScore = math.Round(countAvg.AverageScore*100) / 100

	if dto.EvaluateStatistics.TotalCount > 0 {
		var evaluates []models.OrderProductEvaluate
		global.DB.Where("product_id = ?", product.Id).Preload("User.Avatar").Order("id desc").Limit(2).Find(&evaluates)

		utils.CopyObject(&evaluates, &dto.EvaluateStatistics.Evaluates)

		imageIdsList := []string{}
		for _, item := range evaluates {
			imageIdsList = append(imageIdsList, item.ImageIds)
		}

		imagesList := service.LoadImageListWithIds(imageIdsList)

		for i := range dto.EvaluateStatistics.Evaluates {
			utils.CopyObject(&imagesList[i], &dto.EvaluateStatistics.Evaluates[i].Images)

			dto.EvaluateStatistics.Evaluates[i].User.Name = utils.AnonymousName(dto.EvaluateStatistics.Evaluates[i].User.Name)
		}
	}

	module.SendSuccessResponse(c, "", dto)
}
