package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"app/utils"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// @Tags Api订单管理
// @Summary 获取订单列表
// @Produce json
// @Param offset query int false "跳过条数"
// @Param limit query int false "获取条数"
// @Param sort query string false "排序"
// @Param statuses query []string false "状态" collectionFormat(csv)
// @Param apiStatus query string false "接口状态"
// @Success 200 {array} dtos.OrderResponse "订单列表"
// @Router /api/orders [get]
func GetOrders(c *gin.Context) {
	var req dtos.OrderSearchRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	userId := c.MustGet("userId").(uint)

	db := global.DB.Model(&models.Order{}).Where("user_id = ?", userId).Where("user_deleted_at is null").Where("status <> ?", config.OrderStatusCanceled)

	if req.Statuses != "" {
		statuses := strings.Split(req.Statuses, ",")
		db = db.Where("status in ?", statuses)
	}

	switch req.ApiStatus {
	case "pending": //待支付
		db = db.Where("status = ?", config.OrderStatusPending)
	case "paid": //待发货
		db = db.Where("status = ?", config.OrderStatusPaid)
	case "shipped": //待收货
		db = db.Where("status = ?", config.OrderStatusShipped)
	case "evaluate": //待评价
		db = db.Where("evaluate_status = ?", "").Where("status in ?", []string{config.OrderStatusDelivered, config.OrderStatusCompleted}).Where("refund_status = ?", "")
	case "refund": //退款/售后
		db = db.Where("refund_status <> ?", "")
	}

	db = db.Order("id desc")

	if req.Limit == 0 {
		req.Limit = 10
	}
	if req.Limit > 20 {
		req.Limit = 20
	}
	db = db.Offset(int(req.Offset)).Limit(int(req.Limit))

	db = db.Preload("OrderProducts.ProductImage").Preload("OrderExpresses")

	var orders []models.Order
	db.Find(&orders)

	var dtoList []dtos.OrderResponse
	utils.CopyObject(&orders, &dtoList)

	module.SendSuccessResponse(c, "", dtoList)
}

// @Tags Api订单管理
// @Summary 获取订单信息
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.OrderResponse "订单信息"
// @Router /api/orders/{id} [get]
func GetOrder(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	userId := c.MustGet("userId").(uint)

	var order models.Order
	if result := global.DB.Where("user_id = ?", userId).Where("id = ?", id).Preload("OrderAddress").Preload("OrderProducts.ProductImage").Preload("OrderProducts.Evaluate").Preload("OrderExpresses").Preload("OrderRefund").First(&order); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var dto dtos.OrderResponse
	utils.CopyObject(&order, &dto)

	if order.OrderRefund != nil {
		if order.OrderRefund.ImageIds != "" {
			imageList := service.LoadImageListWithIds([]string{order.OrderRefund.ImageIds})
			utils.CopyObject(&imageList[0], &dto.OrderRefund.Images)
		}
	}

	imageIdsList := []string{}
	appendImageIdsList := []string{}
	for _, item := range order.OrderProducts {
		if item.Evaluate != nil {
			imageIdsList = append(imageIdsList, item.Evaluate.ImageIds)
			appendImageIdsList = append(appendImageIdsList, item.Evaluate.AppendImageIds)
		} else {
			imageIdsList = append(imageIdsList, "")
			appendImageIdsList = append(appendImageIdsList, "")
		}
	}

	imagesList := service.LoadImageListWithIds(imageIdsList)
	appendImagesList := service.LoadImageListWithIds(appendImageIdsList)

	for i := range dto.OrderProducts {
		if dto.OrderProducts[i].Evaluate != nil {
			utils.CopyObject(&imagesList[i], &dto.OrderProducts[i].Evaluate.Images)
			utils.CopyObject(&appendImagesList[i], &dto.OrderProducts[i].Evaluate.AppendImages)
		}
	}

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Api订单管理
// @Summary 创建订单
// @Produce json
// @Param body body dtos.OrderCreateRequest true "订单信息"
// @Success 200 {object} dtos.OrderResponse "订单信息"
// @Router /api/orders [post]
func CreateOrder(c *gin.Context) {
	var req dtos.OrderCreateRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	userId := c.MustGet("userId").(uint)

	var address models.Address
	if result := global.DB.Where("user_id = ?", userId).Where("id = ?", req.AddressId).First(&address); result.Error != nil {
		module.SendFailBadRequestResponse(c, "请选择收货地址")
		return
	}

	reqProducts := []dtos.ProductAddRequest{}

	if len(req.CartIds) > 0 {
		var carts []models.Cart
		global.DB.Where("user_id = ?", userId).Where("id in ?", req.CartIds).Find(&carts)
		for _, item := range carts {
			reqProducts = append(reqProducts, dtos.ProductAddRequest{
				Id:         item.ProductId,
				SpecAttrId: item.ProductSpecAttrId,
				Quantity:   item.Quantity,
			})
		}
	}

	if req.Product != nil {
		reqProducts = append(reqProducts, *req.Product)
	}

	if len(reqProducts) == 0 {
		module.SendFailBadRequestResponse(c, "请选择商品")
		return
	}

	productIds := []uint{}
	productSpecAttrIds := []uint{}

	for _, item := range reqProducts {
		productIds = append(productIds, item.Id)

		if item.SpecAttrId != nil {
			productSpecAttrIds = append(productSpecAttrIds, *item.SpecAttrId)
		}
	}

	var products []models.Product
	global.DB.Where("status = ?", config.ProductStatusOnline).Where("id in ?", productIds).Find(&products)

	productSpecAttrs := []models.ProductSpecAttr{}
	if len(productSpecAttrIds) > 0 {
		global.DB.Where("id in ?", productSpecAttrIds).Find(&productSpecAttrs)
	}

	//检查商品
	var reqCheckProducts []service.ProductCheckRequest
	utils.CopyObject(&reqProducts, &reqCheckProducts)
	errs := service.CheckProductsWithModel(&reqCheckProducts, &products, &productSpecAttrs)
	for _, item := range errs {
		if item != nil {
			module.SendErrorBadRequestResponse(c, item)
			return
		}
	}

	productMap := map[uint]models.Product{}
	productSpecAttrMap := map[uint]models.ProductSpecAttr{}

	for _, item := range products {
		productMap[item.Id] = item
	}

	for _, item := range productSpecAttrs {
		productSpecAttrMap[item.Id] = item
	}

	//生成订单数据
	var order models.Order
	var orderProducts []models.OrderProduct

	order.UserId = userId
	order.OrderNo = fmt.Sprintf("%s%09d%d", time.Now().Format("20060102150405"), time.Now().Nanosecond(), userId)
	order.Description = req.Description
	order.Status = config.OrderStatusPending

	for _, item := range reqProducts {
		var orderProduct models.OrderProduct

		product := productMap[item.Id]

		orderProduct.UserId = userId
		orderProduct.ProductId = product.Id
		orderProduct.ProductName = product.Name
		orderProduct.Status = config.OrderStatusPending

		if item.SpecAttrId != nil {
			productSpecAttr := productSpecAttrMap[*item.SpecAttrId]

			orderProduct.ProductSpecAttrId = &productSpecAttr.Id
			orderProduct.ProductSpecAttrName = productSpecAttr.Name

			orderProduct.ProductImageId = productSpecAttr.ImageId
			orderProduct.Price = productSpecAttr.Price
			orderProduct.ResourceIds = productSpecAttr.ResourceIds
		} else {
			orderProduct.ProductImageId = product.ImageId
			orderProduct.Price = product.Price
			orderProduct.ResourceIds = product.ResourceIds
		}

		orderProduct.Quantity = item.Quantity
		orderProduct.TotalAmount = orderProduct.Price * orderProduct.Quantity
		orderProduct.DiscountAmount = 0
		orderProduct.PayAmount = orderProduct.TotalAmount - orderProduct.DiscountAmount

		order.TotalAmount += orderProduct.TotalAmount
		order.DiscountAmount += orderProduct.DiscountAmount

		orderProducts = append(orderProducts, orderProduct)
	}

	order.PayAmount = order.TotalAmount - order.DiscountAmount

	//生成收货信息
	var orderAddress models.OrderAddress
	orderAddress.Name = address.Name
	orderAddress.Phone = address.Phone
	orderAddress.Province = address.Province
	orderAddress.City = address.City
	orderAddress.District = address.District
	orderAddress.Detail = address.Detail

	//自动取消
	var cfg models.Config
	var orderCancelDuration int = 0
	if result := global.DB.Where("config_key = ?", "orderCancelDuration").First(&cfg); result.Error == nil {
		orderCancelDuration, _ = strconv.Atoi(cfg.ConfigValue)
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		//库存处理
		for _, item := range reqProducts {
			if item.SpecAttrId != nil {
				productSpecAttr := productSpecAttrMap[*item.SpecAttrId]

				if productSpecAttr.Stock >= 0 {
					result := tx.Model(&models.ProductSpecAttr{}).Where("id = ?", item.SpecAttrId).Where("stock >= ?", item.Quantity).Update("stock", gorm.Expr("stock - ?", item.Quantity))
					if result.Error != nil {
						return result.Error
					}

					if result.RowsAffected < 1 {
						return errors.New("商品已被购买，请重新查看库存")
					}
				}
			} else {
				product := productMap[item.Id]

				if product.Stock >= 0 {
					result := tx.Model(&models.Product{}).Where("id = ?", item.Id).Where("stock >= ?", item.Quantity).Update("stock", gorm.Expr("stock - ?", item.Quantity))
					if result.Error != nil {
						return result.Error
					}

					if result.RowsAffected < 1 {
						return errors.New("商品已被购买，请重新查看库存")
					}
				}
			}
		}

		if result := tx.Create(&order); result.Error != nil {
			return result.Error
		}

		for i := range orderProducts {
			orderProducts[i].OrderId = order.Id
		}

		if result := tx.CreateInBatches(orderProducts, 50); result.Error != nil {
			return result.Error
		}

		orderAddress.OrderId = order.Id
		if result := tx.Create(&orderAddress); result.Error != nil {
			return result.Error
		}

		if len(req.CartIds) > 0 {
			tx.Where("user_id = ?", userId).Where("id in ?", req.CartIds).Delete(&models.Cart{})
		}

		if orderCancelDuration > 0 {
			tx.Create(&models.Timer{
				ExecuteType: config.TimerExecuteTypeOrderCancel,
				ExecuteId:   order.Id,
				ExecuteTime: time.Now().UnixMilli() + (int64(orderCancelDuration) * 1000),
				Status:      config.TimerStatusPending,
			})
		}

		return nil
	})

	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	var orderResponse dtos.OrderResponse
	utils.CopyObject(&order, &orderResponse)

	module.SendSuccessResponse(c, "创建成功", orderResponse)
}

// @Tags Api订单管理
// @Summary 更新订单信息
// @Produce json
// @Param id path int true "id"
// @Param body body dtos.OrderUpdateRequest true "订单信息"
// @Success 200 {object} dtos.OrderResponse "订单信息"
// @Router /api/orders/{id} [put]
func UpdateOrder(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	var req dtos.OrderUpdateRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	userId := c.MustGet("userId").(uint)

	var order models.Order
	if result := global.DB.Where("user_id = ?", userId).Where("id = ?", id).First(&order); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	if req.Status == order.Status {
		module.SendFailBadRequestResponse(c, "请刷新订单再操作")
		return
	}

	var err error

	switch req.Status {
	case config.OrderStatusCanceled:
		err = service.OrderCancel(&order)
	case config.OrderStatusDelivered:
		err = service.OrderDeliver(&order)
	default:
		err = errors.New("参数错误")
	}

	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	GetOrder(c)
}

// @Tags Api订单管理
// @Summary 删除订单
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.BaseResponse "删除结果"
// @Router /sys/orders/{id} [delete]
func DeletedOrder(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	userId := c.MustGet("userId").(uint)

	global.DB.Model(&models.Order{}).Where("user_id = ?", userId).Where("id = ?", id).Update("user_deleted_at", time.Now())

	module.SendSuccessResponse(c, "删除成功", nil)
}

// @Tags Api订单管理
// @Summary 订单申请退款
// @Produce json
// @Param body body dtos.OrderRefundRequest true "退款信息"
// @Success 200 {object} dtos.BaseResponse "结果"
// @Router /api/orderRefunds [post]
func CreateOrderRefund(c *gin.Context) {
	var req dtos.OrderRefundRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	if len(req.ImageIds) > 6 {
		module.SendFailBadRequestResponse(c, "图片不能超过6张")
		return
	}

	userId := c.MustGet("userId").(uint)

	var order models.Order
	if result := global.DB.Where("user_id = ?", userId).Where("id = ?", req.OrderId).First(&order); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	if req.Amount == 0 {
		module.SendFailBadRequestResponse(c, "请输入退款金额")
		return
	}

	if req.Amount > order.PayAmount {
		module.SendFailBadRequestResponse(c, "退款金额不能大于付款金额")
		return
	}

	if req.Reason == "" {
		module.SendFailBadRequestResponse(c, "请输入退款原因")
		return
	}

	err := service.OrderRefundApply(&order, req.Amount, req.Reason, utils.JoinFromUintSlice(req.ImageIds, ","))
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	module.SendSuccessResponse(c, "申请成功", nil)
}

// @Tags Api订单管理
// @Summary 删除订单退款
// @Produce json
// @Param id path int true "id"
// @Success 200 {object} dtos.BaseResponse "结果"
// @Router /sys/orderRefunds/{id} [delete]
func DeletedOrderRefund(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))

	userId := c.MustGet("userId").(uint)

	var orderRefund models.OrderRefund
	if result := global.DB.Where("id = ?", id).First(&orderRefund); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	var order models.Order
	if result := global.DB.Where("user_id = ?", userId).Where("id = ?", orderRefund.OrderId).First(&order); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	service.OrderRefundDelete(&orderRefund)

	module.SendSuccessResponse(c, "删除成功", nil)
}

// @Tags Api订单管理
// @Summary 订单评价
// @Produce json
// @Param body body dtos.OrderEvaluateRequest true "评价信息"
// @Success 200 {object} dtos.BaseResponse "结果"
// @Router /api/orderevaluates [post]
func CreateOrderEvaluate(c *gin.Context) {
	var req dtos.OrderEvaluateRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	for _, item := range req.Evaluates {
		if len(item.ImageIds) > 6 {
			module.SendFailBadRequestResponse(c, "图片不能超过6张")
			return
		}

		if item.Score < 1 || item.Score > 5 {
			module.SendFailBadRequestResponse(c, "请选择评分")
			return
		}
	}

	userId := c.MustGet("userId").(uint)

	var order models.Order
	if result := global.DB.Where("user_id = ?", userId).Where("id = ?", req.OrderId).Preload("OrderProducts.Evaluate").First(&order); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	if order.EvaluateStatus == config.OrderEvaluateStatusAppend {
		module.SendFailBadRequestResponse(c, "订单已评价")
		return
	}

	if !(order.Status == config.OrderStatusDelivered || order.Status == config.OrderStatusCompleted) {
		module.SendFailBadRequestResponse(c, "订单状态不可评价")
		return
	}

	if order.RefundStatus != "" {
		module.SendFailBadRequestResponse(c, "退款订单不可评价")
		return
	}

	orderProductMap := map[uint]*models.OrderProduct{}

	if order.OrderProducts != nil {
		for _, item := range order.OrderProducts {
			orderProductMap[item.Id] = &item
		}
	}

	insertList := []*models.OrderProductEvaluate{}
	updateList := []*models.OrderProductEvaluate{}

	timeNow := time.Now()

	for _, item := range req.Evaluates {
		if orderProduct, ok := orderProductMap[item.OrderProductId]; ok {
			if orderProduct.Evaluate != nil {
				evaluate := orderProduct.Evaluate
				if evaluate.Status == config.OrderEvaluateStatusEvaluated {
					evaluate.Score = item.Score
					evaluate.AppendContent = item.Content
					evaluate.AppendImageIds = utils.JoinFromUintSlice(item.ImageIds, ",")
					evaluate.AppendTime = &timeNow
					evaluate.Status = config.OrderEvaluateStatusAppend
					updateList = append(updateList, evaluate)
				}
			} else {
				evaluate := &models.OrderProductEvaluate{
					OrderProductId:      orderProduct.Id,
					OrderId:             orderProduct.OrderId,
					UserId:              orderProduct.UserId,
					ProductId:           orderProduct.ProductId,
					ProductSpecAttrId:   orderProduct.ProductSpecAttrId,
					ProductSpecAttrName: orderProduct.ProductSpecAttrName,
					Score:               item.Score,
					Content:             item.Content,
					ImageIds:            utils.JoinFromUintSlice(item.ImageIds, ","),
					Status:              config.OrderEvaluateStatusEvaluated,
				}
				insertList = append(insertList, evaluate)
			}
		}
	}

	err := global.DB.Transaction(func(tx *gorm.DB) error {
		switch order.EvaluateStatus {
		case "":
			result := tx.Model(&models.Order{}).Where("id = ?", order.Id).Where("evaluate_status = ?", "").Update("evaluate_status", config.OrderEvaluateStatusEvaluated)
			if result.Error != nil {
				return result.Error
			}

			if result.RowsAffected < 1 {
				return errors.New("状态异常")
			}
		case config.OrderEvaluateStatusEvaluated:
			result := tx.Model(&models.Order{}).Where("id = ?", order.Id).Where("evaluate_status = ?", config.OrderEvaluateStatusEvaluated).Update("evaluate_status", config.OrderEvaluateStatusAppend)
			if result.Error != nil {
				return result.Error
			}

			if result.RowsAffected < 1 {
				return errors.New("状态异常")
			}
		}

		for _, item := range insertList {
			tx.Create(item)
		}

		for _, item := range updateList {
			tx.Save(item)
		}

		return nil
	})

	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	module.SendSuccessResponse(c, "评价成功", nil)
}

// @Tags Api订单管理
// @Summary 获取订单统计信息
// @Produce json
// @Success 200 {object} dtos.OrderStatisticsResponse "订单列表"
// @Router /api/orderStatistics [get]
func GetOrderStatistics(c *gin.Context) {
	userId := c.MustGet("userId").(uint)

	dto := getOrderStatisticsData(userId)

	module.SendSuccessResponse(c, "", dto)
}

func getOrderStatisticsData(userId uint) dtos.OrderStatisticsResponse {
	var dto dtos.OrderStatisticsResponse
	var count int64

	global.DB.Model(&models.Order{}).Where("user_id = ?", userId).Where("user_deleted_at is null").Count(&count)
	dto.TotalCount = uint(count)

	global.DB.Model(&models.Order{}).Where("user_id = ?", userId).Where("user_deleted_at is null").Where("status = ?", config.OrderStatusPending).Count(&count)
	dto.PendingCount = uint(count)

	global.DB.Model(&models.Order{}).Where("user_id = ?", userId).Where("user_deleted_at is null").Where("status = ?", config.OrderStatusPaid).Count(&count)
	dto.PaidCount = uint(count)

	global.DB.Model(&models.Order{}).Where("user_id = ?", userId).Where("user_deleted_at is null").Where("status = ?", config.OrderStatusShipped).Count(&count)
	dto.ShippedCount = uint(count)

	global.DB.Model(&models.Order{}).Where("user_id = ?", userId).Where("user_deleted_at is null").Where("evaluate_status = ?", "").Where("status in ?", []string{config.OrderStatusDelivered, config.OrderStatusCompleted}).Where("refund_status = ?", "").Count(&count)
	dto.EvaluateCount = uint(count)

	global.DB.Model(&models.Order{}).Where("user_id = ?", userId).Where("user_deleted_at is null").Where("refund_status <> ?", "").Count(&count)
	dto.RefundCount = uint(count)

	return dto
}
