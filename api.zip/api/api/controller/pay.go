package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"fmt"
	"time"

	"github.com/gin-gonic/gin"
)

// @Tags Api支付管理
// @Summary 创建订单支付
// @Produce json
// @Param body body dtos.PayOrderRequest true "支付信息"
// @Success 200 {object} dtos.BaseResponse "支付信息，每个支付渠道不一样"
// @Router /api/payOrder [post]
func CreatePayOrder(c *gin.Context) {
	var req dtos.PayOrderRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	if req.PayChannel != config.PayChannelWxH5 && req.PayChannel != config.PayChannelWxJsapi && req.PayChannel != config.PayChannelWxMp {
		module.SendFailBadRequestResponse(c, "请选择支付渠道")
		return
	}

	if gin.Mode() != gin.DebugMode {
		if req.PayChannel == config.PayChannelWxJsapi || req.PayChannel == config.PayChannelWxMp {
			if req.OpenId == "" {
				module.SendFailBadRequestResponse(c, "获取openid失败")
				return
			}
		}
	}

	userId := c.MustGet("userId").(uint)

	var order models.Order
	if result := global.DB.Where("user_id = ?", userId).Where("id = ?", req.OrderId).First(&order); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	if order.Status != config.OrderStatusPending {
		module.SendFailBadRequestResponse(c, "订单不可支付")
		return
	}

	var orderProduct models.OrderProduct
	if result := global.DB.Where("order_id = ?", req.OrderId).First(&orderProduct); result.Error != nil {
		module.SendErrorBadRequestResponse(c, result.Error)
		return
	}

	pay := models.Pay{
		UserId:      userId,
		TradeType:   config.PayTradeTypeOrder,
		TradeId:     order.Id,
		TradeNo:     fmt.Sprintf("%s%09d%d", time.Now().Format("20060102150405"), time.Now().Nanosecond(), userId),
		Channel:     req.PayChannel,
		Amount:      order.PayAmount,
		Title:       "购买商品",
		Description: orderProduct.ProductName,
		Status:      config.PayStatusPending,
	}
	global.DB.Create(&pay)

	if gin.Mode() == gin.DebugMode {
		//debug模式直接支付成功
		pay.AppId = "debug"
		pay.MchId = "debug"
		pay.OutTradeNo = fmt.Sprintf("%s%09d%d", time.Now().Format("20060102150405"), time.Now().Nanosecond(), userId)
		pay.Status = config.PayStatusPaid
		now := time.Now()
		pay.PaidTime = &now

		global.DB.Save(&pay)

		service.PaySuccess(&pay)

		module.SendSuccessResponse(c, "创建成功", nil)
		return
	} else {
		switch req.PayChannel {
		case config.PayChannelWxH5:
			resp, err := service.PayWxH5(&pay, c.ClientIP())
			if err != nil {
				module.SendErrorInternalServerResponse(c, err)
			}

			dto := dtos.PayWxH5Response{
				Url: *resp.H5Url,
			}

			module.SendSuccessResponse(c, "创建成功", dto)
			return
		case config.PayChannelWxJsapi:
			resp, err := service.PayWxJsapi(&pay, req.OpenId)
			if err != nil {
				module.SendErrorInternalServerResponse(c, err)
			}

			dto := dtos.PayWxJsapiResponse{
				AppId:     *resp.Appid,
				TimeStamp: *resp.TimeStamp,
				NonceStr:  *resp.NonceStr,
				Package:   *resp.Package,
				SignType:  *resp.SignType,
				PaySign:   *resp.PaySign,
			}

			module.SendSuccessResponse(c, "创建成功", dto)
			return
		case config.PayChannelWxMp:
			resp, err := service.PayWxMp(&pay, req.OpenId)
			if err != nil {
				module.SendErrorInternalServerResponse(c, err)
			}

			dto := dtos.PayWxMpResponse{
				AppId:     *resp.Appid,
				TimeStamp: *resp.TimeStamp,
				NonceStr:  *resp.NonceStr,
				Package:   *resp.Package,
				SignType:  *resp.SignType,
				PaySign:   *resp.PaySign,
			}

			module.SendSuccessResponse(c, "创建成功", dto)
			return
		}
	}

	module.SendFailBadRequestResponse(c, "请选择支付渠道")
}
