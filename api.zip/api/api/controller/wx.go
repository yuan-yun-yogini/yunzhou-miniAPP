package controller

import (
	"app/api/dtos"
	"app/api/module"
	"app/config"
	"app/global"
	"app/models"
	"app/service"
	"app/utils"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
)

// @Tags Api微信
// @Summary 创建微信小程序openid
// @Produce json
// @Param body body dtos.WxMpOpenIdRequest true "请求信息"
// @Success 200 {object} dtos.WxMpOpenIdResponse "结果"
// @Router /api/wxMpOpenId [post]
func CreateWxMpOpenId(c *gin.Context) {
	var req dtos.WxMpOpenIdRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	if gin.Mode() == gin.DebugMode {
		dto := dtos.WxMpOpenIdResponse{
			OpenId: utils.GenerateRandomString(32),
		}

		module.SendSuccessResponse(c, "", dto)
		return
	}

	url := fmt.Sprintf("https://api.weixin.qq.com/sns/jscode2session?appid=%s&secret=%s&js_code=%s&grant_type=GRANT_TYPE", global.AppConfig.WxMp.AppId, global.AppConfig.WxMp.AppSecret, req.Code)

	resp, err := http.Get(url)
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	type Resp struct {
		OpenId     string `json:"openid"`
		SessionKey string `json:"session_key"`
		UinonId    string `json:"unionid"`
		ErrCode    int    `json:"errcode"`
		ErrMsg     string `json:"errmsg"`
	}

	var obj Resp
	err = json.Unmarshal(body, &obj)
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	if obj.ErrCode != 0 {
		module.SendErrorInternalServerResponse(c, errors.New(obj.ErrMsg))
		return
	}

	dto := dtos.WxMpOpenIdResponse{
		OpenId: obj.OpenId,
	}

	module.SendSuccessResponse(c, "", dto)
}

// @Tags Api微信
// @Summary 微信小程序手机号登录
// @Produce json
// @Param body body dtos.WxMpPhoneLoginRequest true "请求信息"
// @Success 200 {object} dtos.UserLoginResponse "结果"
// @Router /api/loginWxMpPhone [post]
func LoginWxMpPhone(c *gin.Context) {
	var req dtos.WxMpPhoneLoginRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	accessToken, err := service.GetWxMpAccessToken()
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	url := fmt.Sprintf("https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token=%s", accessToken)

	params := map[string]string{"code": req.Code}
	bts, _ := json.Marshal(params)

	request, _ := http.NewRequest("POST", url, bytes.NewBuffer(bts))
	request.Header.Set("Content-Type", "application/json")

	client := &http.Client{Timeout: 5 * time.Second}
	resp, err := client.Do(request)
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	type RespData struct {
		PhoneNumber     string `json:"phoneNumber"`
		PurePhoneNumber string `json:"purePhoneNumber"`
		CountryCode     string `json:"countryCode"`
	}

	type Resp struct {
		Code    int       `json:"errcode"`
		Message string    `json:"errmsg"`
		Data    *RespData `json:"phone_info"`
	}

	var obj Resp
	err = json.Unmarshal(body, &obj)
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	if obj.Code != 0 {
		module.SendErrorInternalServerResponse(c, errors.New(obj.Message))
		return
	}

	phone := obj.Data.PurePhoneNumber

	var user models.User
	if result := global.DB.Where("username = ?", phone).Preload("Avatar").First(&user); result.Error != nil {
		//注册
		user.Username = phone
		user.Phone = phone
		user.Name = "用户" + utils.SubstrRune(phone, 7, 11)

		if req.InviterId != nil && *req.InviterId != 0 {
			user.InviterId = req.InviterId
		}

		user.Status = config.CommonStatusEnable

		if res := global.DB.Create(&user); res.Error != nil {
			module.SendErrorInternalServerResponse(c, res.Error)
			return
		}
	} else {
		if user.Status == config.CommonStatusDisable {
			module.SendFailForbiddenResponse(c, "用户已被禁用，请联系客服")
			return
		}
	}

	user.LoginToken = utils.GenerateRandomString(32)

	token, expire, err := module.GenerateToken(user.Id, user.LoginToken)
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	user.LoginIp = c.ClientIP()
	loginTime := time.Now()
	user.LoginTime = &loginTime
	global.DB.Select("LoginToken", "LoginIp", "LoginTime").Save(&user)

	var userDto dtos.UserResponse
	utils.CopyObject(&user, &userDto)

	module.SendSuccessResponse(c, "", dtos.UserLoginResponse{
		Token:  token,
		Expire: uint(expire.UnixMilli()),
		User:   userDto,
	})
}

func GetWxMpAccessToken(c *gin.Context) {
	var req dtos.WxMpAccessTokenRequest
	if err := c.ShouldBind(&req); err != nil {
		module.SendErrorBadRequestResponse(c, err)
		return
	}

	signStr := fmt.Sprintf("time=%d&key=%s", req.Time, global.AppConfig.WxMp.AccessTokenKey)
	sign := utils.Md5String(signStr)
	if req.Sign != sign {
		module.SendFailBadRequestResponse(c, "签名错误")
		return
	}

	diffTime := time.Now().Unix() - req.Time
	if diffTime > 10 || diffTime < -10 {
		module.SendFailBadRequestResponse(c, "签名失败")
		return
	}

	accessToken, err := service.GetWxMpAccessToken()
	if err != nil {
		module.SendErrorInternalServerResponse(c, err)
		return
	}

	dto := dtos.WxMpAccessTokenResponse{
		AccessToken: accessToken,
	}

	module.SendSuccessResponse(c, "", dto)
}
