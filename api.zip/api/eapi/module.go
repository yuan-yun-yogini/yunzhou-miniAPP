package eapi

import (
	"app/config"
	"app/eapi/module"
	"app/eapi/router"

	"github.com/gin-gonic/gin"
)

func Start(r *gin.Engine, cfg *config.ModuleConfig) {
	module.ModuleConfig = cfg

	router.InitRouter(r)
}
