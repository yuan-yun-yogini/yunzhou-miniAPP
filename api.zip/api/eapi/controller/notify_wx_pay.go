package controller

import (
	"app/service"
	"net/http"

	"github.com/gin-gonic/gin"
)

func NotifyWxPayH5(c *gin.Context) {
	err := service.NotifyWxPayH5(c.Request)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": "FAIL", "message": err.Error()})
	}

	c.JSON(http.StatusOK, nil)
}

func NotifyWxPayJsapi(c *gin.Context) {
	err := service.NotifyWxPayJsapi(c.Request)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": "FAIL", "message": err.Error()})
	}

	c.JSON(http.StatusOK, nil)
}

func NotifyWxPayMp(c *gin.Context) {
	err := service.NotifyWxPayMp(c.Request)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": "FAIL", "message": err.Error()})
	}

	c.JSON(http.StatusOK, nil)
}
