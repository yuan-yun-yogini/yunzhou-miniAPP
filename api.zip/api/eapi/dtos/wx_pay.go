package dtos

type NotifyWxPayRequest struct {
	Id           string              `json:"id"`
	CreateTime   string              `json:"create_time"`
	ResourceType string              `json:"resource_type"`
	EventType    string              `json:"event_type"`
	Summary      string              `json:"summary"`
	Resource     NotifyWxPayResource `json:"resource"`
}

type NotifyWxPayResource struct {
	OriginalType   string `json:"original_type"`
	Algorithm      string `json:"algorithm"`
	Ciphertext     string `json:"ciphertext"`
	AssociatedData string `json:"associated_data"`
	Nonce          string `json:"nonce"`
}
