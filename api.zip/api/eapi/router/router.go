package router

import (
	"app/eapi/controller"

	"github.com/gin-gonic/gin"
)

func InitRouter(r *gin.Engine) {
	public := r.Group("/eapi")
	{
		public.POST("/notifyWxPayH5", controller.NotifyWxPayH5)
		public.POST("/notifyWxPayJsapi", controller.NotifyWxPayJsapi)
		public.POST("/notifyWxPayMp", controller.NotifyWxPayMp)
	}
}
