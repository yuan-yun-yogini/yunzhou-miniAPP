import {
	useBadgeStore
} from '@/store/badge'
import {
	getBadges as apiGetbadges
} from '@/api/badge'

export function loadBadges() {
	apiGetbadges().then(res => {
		var store = useBadgeStore()

		store.cartCount = res.data.cartCount
		store.messageCount = res.data.messageCount
		store.myCount = res.data.myCount

		var pages = getCurrentPages()
		if (pages.length > 0 && (pages[pages.length - 1].route == 'pages/index/index' ||
				pages[pages.length - 1].route == 'pages/category/category' ||
				pages[pages.length - 1].route == 'pages/cart/cart' ||
				pages[pages.length - 1].route == 'pages/my/my')) {
			showBadges()
		}
	})
}

export function resetBadges() {
	var store = useBadgeStore()
	store.$reset()
}

export function getBadges() {
	var store = useBadgeStore()

	return {
		cartCount: store.cartCount,
		messageCount: store.messageCount,
		myCount: store.myCount,
	}
}

export function setBadges(data) {
	var store = useBadgeStore()

	if (data.hasOwnProperty('cartCount')) {
		store.cartCount = data.cartCount
	}

	if (data.hasOwnProperty('messageCount')) {
		store.messageCount = data.messageCount
	}

	if (data.hasOwnProperty('myCount')) {
		store.myCount = data.myCount
	}
}

export function showBadges() {
	try {
		var store = useBadgeStore()

		if (store.cartCount > 0) {
			uni.setTabBarBadge({
				index: 2,
				text: store.cartCount > 99 ? '99+' : '' + store.cartCount,
			})
		} else {
			uni.removeTabBarBadge({
				index: 2,
			})
		}

		if (store.myCount > 0) {
			uni.setTabBarBadge({
				index: 3,
				text: store.myCount > 99 ? '99+' : '' + store.myCount,
			})
		} else {
			uni.removeTabBarBadge({
				index: 3,
			})
		}
	} catch (err) {

	}
}