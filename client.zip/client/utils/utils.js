export default {
	formatDate(date, fmt = 'yyyy-MM-dd hh:mm:ss') {
		let o = {
			'M+': date.getMonth() + 1,
			'd+': date.getDate(),
			'h+': date.getHours(),
			'm+': date.getMinutes(),
			's+': date.getSeconds()
		};

		if (/(y+)/.test(fmt)) {
			fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
		}

		for (let k in o) {
			if (new RegExp(`(${k})`).test(fmt)) {
				let str = o[k] + '';
				fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? str : ('00' + str).substr(str.length));
			}
		}
		return fmt;
	},

	newDateWithStr(dateStr) {
		return new Date(dateStr.replace(/-/g, '/')); //兼容ios
	},

	inputMoneyToApi(money) {
		if (!money) {
			return 0
		}

		return Math.round(parseFloat(money) * 100)
	},

	apiMoneyToShow(money, digit = 0) {
		var m = money / 100
		if (digit > 0) {
			return m.toFixed(digit)
		} else {
			return m
		}
	},

	getNavBarInfo() {
		var windowInfo = uni.getWindowInfo()
		var statusBarHeight = windowInfo.statusBarHeight

		var menu = {
			top: 0,
			left: 0,
			right: 0,
			bottom: 0,
			width: 0,
			height: 0,
		}

		var navBar = {
			top: 0,
			left: 0,
			right: uni.upx2px(750),
			bottom: 44,
		}

		// #ifdef MP
		menu = uni.getMenuButtonBoundingClientRect();

		navBar = {
			top: statusBarHeight,
			left: 0,
			right: menu.left,
			bottom: menu.bottom + (menu.top - statusBarHeight),
		}
		// #endif

		navBar.width = navBar.right - navBar.left
		navBar.height = navBar.bottom - navBar.top

		return {
			statusBarHeight: statusBarHeight,
			navBar: navBar,
			menu: menu,
		}
	},
}