import api from './api'

export function getProducts(data) {
	return api.get('/products', data)
}

export function getProduct(id) {
	return api.get('/products/' + id)
}

export function getEvaluates(data) {
	return api.get('/evaluates', data)
}