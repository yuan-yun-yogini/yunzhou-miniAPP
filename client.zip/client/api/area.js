import api from './api'

export function getAreas() {
	return api.get('/areas')
}