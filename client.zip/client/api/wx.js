import api from './api'

export function createWxMpOpenId(data) {
	return api.post('/wxMpOpenId', data)
}

export function loginWxMpPhone(data) {
	return api.post('/loginWxMpPhone', data)
}