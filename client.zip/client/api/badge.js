import api from './api'

export function getBadges() {
	return api.get('/badges')
}