import api from './api'

export function getAddresses() {
	return api.get('/addresses')
}

export function getAddress(id) {
	return api.get('/addresses/' + id)
}

export function createAddress(data) {
	return api.post('/addresses', data)
}

export function updateAddress(id, data) {
	return api.put('/addresses/' + id, data)
}

export function deleteAddress(id) {
	return api.del('/addresses/' + id)
}