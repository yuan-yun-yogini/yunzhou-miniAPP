import api from './api'

export function getCategorys() {
	return api.get('/categorys')
}