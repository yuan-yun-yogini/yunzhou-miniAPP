import api from './api'

export function getBanners(data) {
	return api.get('/banners', data)
}

export function getBanner(id) {
	return api.get('/banners/' + id)
}