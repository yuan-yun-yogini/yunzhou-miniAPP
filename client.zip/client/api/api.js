import {
	useUserStore
} from '@/store/user'

// const baseUrl = 'http://localhost:8001/api' //开发
const baseUrl = 'https://api.yuanyun.fun:11001/api' //正式
// const baseUrl = '/api' //正式h5

const request = (options) => {
	return new Promise((resolve, reject) => {
		var token = null
		var store = useUserStore()
		if (store.isLogin()) {
			token = store.login.token
		}

		uni.request({
			url: baseUrl + options.url,
			method: options.method || 'GET',
			data: options.data || {},
			header: {
				'Content-Type': 'application/json',
				'Authorization': token ? `Bearer ${token}` : ''
			},
			success: (res) => {
				if (res.statusCode >= 200 && res.statusCode < 300) {
					resolve(res.data)
				} else {
					var message = '网络错误'

					switch (res.statusCode) {
						case 401:
							// 未授权，跳转到登录页面
							useUserStore().setLogin(null)
							var pages = getCurrentPages()
							if (!(pages.length > 0 && pages[pages.length - 1].route == 'pages/login/login')) {
								uni.navigateTo({
									url: '/pages/login/login?from=api'
								})
							}
							
							message = '请登录'
							break
						case 403:
							// 禁止访问
							message = '没有权限'
							break
						case 404:
							// 资源不存在
							message = '资源不存在'
							break
						case 500:
							// 服务器错误
							message = '服务器错误'
							break
					}

					if (res.data && res.data.message) {
						message = res.data.message
					}

					uni.showToast({
						title: message,
						icon: 'none',
						duration: 3000,
					})

					reject(res)
				}
			},
			fail: (err) => {
				uni.showToast({
					title: '网络错误',
					icon: 'none',
					duration: 3000,
				})
				reject({
					statusCode: 400,
					data: {
						code: 400,
						message: "网络错误",
						data: null,
					}
				})
			}
		})
	})
}

const get = (url, data) => {
	return request({
		url: url,
		method: 'GET',
		data: data
	})
}

const post = (url, data) => {
	return request({
		url: url,
		method: 'POST',
		data: data
	})
}

const put = (url, data) => {
	return request({
		url: url,
		method: 'PUT',
		data: data
	})
}

const del = (url, data) => {
	return request({
		url: url,
		method: 'DELETE',
		data: data
	})
}

export default {
	baseUrl: baseUrl,
	request: request,
	get: get,
	post: post,
	put: put,
	del: del,
}