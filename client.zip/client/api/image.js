import api from './api'
import {
	useUserStore
} from '@/store/user'

export const uploadImageUrl = api.baseUrl + "/images"

export function uploadImageHeader() {
	var token = null
	var store = useUserStore()
	if (store.isLogin()) {
		token = store.login.token
	}

	return {
		'Authorization': token ? `Bearer ${token}` : ''
	}
}

export function uploadImagesList(pathsList) {
	return new Promise((resolve, reject) => {
		var imageMap = new Map()
		pathsList.forEach(paths => {
			paths.forEach(path => {
				imageMap.set(path, null)
			})
		})

		var pathUniqueList = []
		imageMap.forEach((value, key) => {
			pathUniqueList.push(key)
		})

		if (pathUniqueList.length == 0) {
			var resultList = []
			pathsList.forEach(paths => {
				resultList.push([])
			})
			resolve(resultList)
			return
		}

		var uploadPromiseList = []
		pathUniqueList.forEach(item => {
			var p = new Promise((resolveItem, rejectItem) => {
				uni.uploadFile({
					url: uploadImageUrl,
					filePath: item,
					name: 'file',
					header: uploadImageHeader(),
					success: res => {
						var resData = JSON.parse(res.data)

						imageMap.set(item, resData.data)

						resolveItem()
					},
					fail: () => {
						rejectItem()
					},
				});
			})

			uploadPromiseList.push(p)
		})

		Promise.all(uploadPromiseList).then(() => {
			var resultList = []
			pathsList.forEach(paths => {
				var list = []

				paths.forEach(path => {
					list.push(imageMap.get(path))
				})

				resultList.push(list)
			})

			resolve(resultList)
		}).catch(() => {
			reject()
		})
	})
}