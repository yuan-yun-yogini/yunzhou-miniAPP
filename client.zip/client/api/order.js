import api from './api'

export function getOrders(data) {
	return api.get('/orders', data)
}

export function getOrder(id) {
	return api.get('/orders/' + id)
}

export function createOrder(data) {
	return api.post('/orders', data)
}

export function updateOrder(id, data) {
	return api.put('/orders/' + id, data)
}

export function deleteOrder(id) {
	return api.del('/orders/' + id)
}

export function createOrderRefund(data) {
	return api.post('/orderRefunds', data)
}

export function deleteOrderRefund(id) {
	return api.del('/orderRefunds/' + id)
}

export function createOrderEvaluate(data) {
	return api.post('/orderEvaluates', data)
}

export function getOrderStatistics() {
	return api.get('/orderStatistics')
}

export function getOrderProductResources(data) {
	return api.get('/orderProductResources', data)
}

export function getOrderProductResource(id) {
	return api.get('/orderProductResources/' + id)
}