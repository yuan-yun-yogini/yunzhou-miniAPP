import api from './api'

export function getConfigs(data) {
	return api.get('/configs', data)
}

export function getConfig(id) {
	return api.get('/configs/' + id)
}