import api from './api'

export function createSettle(data) {
	return api.post('/settles', data)
}

export function createPayOrder(data) {
	return api.post('/payOrder', data)
}