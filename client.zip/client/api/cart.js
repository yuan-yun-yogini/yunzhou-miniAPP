import api from './api'

export function getCarts() {
	return api.get('/carts')
}

export function createCart(data) {
	return api.post('/carts', data)
}

export function updateCart(id, data) {
	return api.put('/carts/' + id, data)
}

export function deleteCart(id) {
	return api.del('/carts/' + id)
}

export function getCartStatistics() {
	return api.get('/cartStatistics')
}