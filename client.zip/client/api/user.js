import api from './api'

export function getMy() {
	return api.get('/my')
}

export function updateMy(data) {
	return api.put('/my', data)
}