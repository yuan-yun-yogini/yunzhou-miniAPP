<template>
	<view class="flex-column bg-page" style="padding-bottom: 140rpx;" v-if="settle">
		<view class="flex-row-center bg-section space-mt-10 space-mx-10 space-pa-10 uni-radius-lg"
			@click="selectAddress">
			<uni-icons class="space-mr-10" type="location-filled" size="48rpx" color="#c70000"></uni-icons>
			<view class="flex-column flex-width-fill">
				<text class="font-title">{{address ? address.detail : '请选择收货地址'}}</text>
				<text class="font-base space-mt-3" v-if="address">{{address.name}} {{address.phone}}</text>
			</view>
			<uni-icons class="space-ml-10" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
		</view>
		<view class="flex-column bg-section space-mt-10 space-mx-10 uni-radius-lg">
			<template v-for="(item, index) in settle.products" :key="index">
				<view class="sep-line-x" v-if="index > 0"></view>
				<view class="flex-row-center space-pa-10">
					<image style="width: 160rpx;height: 160rpx;border-radius: 10rpx;"
						:src="item.productSpecAttr ? item.productSpecAttr.image.url : item.product.image.url"
						mode="aspectFill"></image>
					<view class="flex-column flex-width-fill space-ml-5">
						<view class="flex-row-center space-mt-5">
							<text class="flex-width-fill font-line1 font-main-l">{{item.product.name}}</text>
							<text class="font-main-l space-ml-10">x{{item.quantity}}</text>
						</view>
						<text class="font-base space-mt-5"
							v-if="item.productSpecAttr">{{item.productSpecAttr.name}}</text>
						<view class="flex-row-center space-mt-5">
							<text class="flex-width-fill font-main">￥{{$utils.apiMoneyToShow(item.price)}}</text>
							<text class="font-price">￥{{$utils.apiMoneyToShow(item.payAmount)}}</text>
						</view>
					</view>
				</view>
			</template>
		</view>
		<view class="flex-column bg-section space-mt-10 space-mx-10 space-pa-10 uni-radius-lg">
			<text class="font-main">备注说明</text>
			<uni-easyinput class="space-mt-10" type="textarea" v-model="description" :maxlength="100"
				placeholder="请输入备注说明内容"></uni-easyinput>
		</view>
		<view class="flex-column bg-section space-mt-10 space-mx-10 uni-radius-lg">
			<view class="flex-row-center space-pa-10">
				<uni-icons class="space-mr-10" type="weixin" size="48rpx" color="#18bc37"></uni-icons>
				<text class="flex-width-fill font-title">微信支付</text>
				<radio class="space-ml-5" style="transform:scale(0.8)" :disabled="payChannel == ''"
					:checked="payChannel != ''"></radio>
			</view>
		</view>
		<view class="flex-row-center bg-section space-px-10"
			style="position: fixed;left: 0;bottom: 0;right: 0;height: 120rpx;">
			<button size="default" type="warn" class="flex-width-fill" style="height: 80rpx;line-height: 80rpx;"
				@click="clickPay">立即支付￥{{$utils.apiMoneyToShow(settle.payAmount)}}</button>
		</view>
	</view>
</template>

<script>
	import {
		setBadges
	} from '@/utils/badge'
	import {
		getCartStatistics
	} from '@/api/cart'
	import {
		getAddress,
	} from '@/api/address'
	import {
		createSettle,
		createPayOrder,
	} from '@/api/settle'
	import {
		createOrder,
	} from '@/api/order'
	import {
		createWxMpOpenId,
	} from '@/api/wx'
	export default {
		data() {
			return {
				pageParams: {},
				address: null,
				payChannel: '',
				description: '',
				settle: null,
				payLoading: false,
				order: null,
				openId: '',
			}
		},
		onLoad(options) {
			// #ifdef MP-WEIXIN
			this.payChannel = 'wxMp'
			this.loadWxMpOpenId()
			// #endif
			// #ifdef WEB
			// var agent = navigator.userAgent.toLowerCase()
			// if (agent.match(/MicroMessenger/i) == 'micromessenger') {
			// 	this.payChannel = 'wxJsapi'
			// } else {
			// 	this.payChannel = 'wxH5'
			// }
			this.payChannel = 'wxH5'
			// #endif

			var params = {}
			if (options.cartIds) {
				var cartIdList = options.cartIds.split(',')
				params.cartIds = []
				cartIdList.forEach(item => {
					params.cartIds.push(parseInt(item))
				})
			}
			if (options.productId && options.quantity) {
				params.product = {
					id: parseInt(options.productId),
					quantity: parseInt(options.quantity),
				}
				if (options.productSpecAttrId) {
					params.product.specAttrId = parseInt(options.productSpecAttrId)
				}
			}
			this.pageParams = params

			this.loadData()
			this.loadAddress()
		},
		methods: {
			loadData() {
				createSettle(this.pageParams).then(res => {
					this.settle = res.data
				})
			},

			loadAddress() {
				getAddress(0).then(res => {
					if (res.data) {
						this.address = res.data
					}
				})
			},

			loadWxMpOpenId() {
				var that = this
				var openId = uni.getStorageSync('openId')
				console.log('openId', openId)
				if (openId) {
					this.openId = openId
				} else {
					uni.login({
						provider: 'weixin',
						success: function(loginRes) {
							createWxMpOpenId({
								code: loginRes.code
							}).then(res => {
								that.openId = res.data.openId
								uni.setStorageSync('openId', res.data.openId)
							})
						}
					});
				}
			},

			selectAddress() {
				var that = this
				uni.navigateTo({
					url: '/pages/my/address?isSelect=1&selectId=' + (this.address ? this.address.id : 0),
					events: {
						acceptDataFromOpenedPage: function(data) {
							that.address = data
						}
					}
				})
			},

			clickPay() {
				if (this.payLoading) {
					return
				}

				if (!this.address) {
					uni.showToast({
						title: '请选择收货地址',
						icon: 'none',
						duration: 3000,
					})
					return
				}

				if (!this.payChannel) {
					uni.showToast({
						title: '请选择支付方式',
						icon: 'none',
						duration: 3000,
					})
					return
				}
				
				if (!this.openId) {
					uni.showToast({
						title: '获取openid失败',
						icon: 'none',
						duration: 3000,
					})
					return
				}

				this.payLoading = true

				uni.showLoading({
					title: '加载中...'
				})

				if (this.order) {
					this.doCreatePay()
				} else {
					this.doCreateOrder()
				}
			},

			doCreateOrder() {
				var params = {
					addressId: this.address.id,
					description: this.description,
				}
				if (this.pageParams.cartIds) {
					params.cartIds = this.pageParams.cartIds
				}
				if (this.pageParams.product) {
					params.product = this.pageParams.product
				}

				createOrder(params).then(res => {
					this.order = res.data

					if (this.pageParams.cartIds) {
						getCartStatistics().then(res => {
							setBadges({
								cartCount: res.data.totalCount
							})
						})
					}

					this.doCreatePay()
				}).catch(err => {
					uni.hideLoading()
					this.payLoading = false
				})
			},

			doCreatePay() {
				var params = {
					orderId: this.order.id,
					payChannel: this.payChannel,
					openId: this.openId,
				}
				createPayOrder(params).then(res => {
					if (res.data) {
						this.pay(res.data)
					} else {
						uni.hideLoading()
						this.payLoading = false

						uni.redirectTo({
							url: '/pages/pay/success'
						})
					}
				}).catch(err => {
					uni.hideLoading()
					this.payLoading = false
				})
			},

			pay(payInfo) {
				if (this.payChannel == 'wxH5') {
					uni.hideLoading()
					this.payLoading = false

					window.location.replace(payInfo.url);
				} else if (this.payChannel == 'wxJsapi') {
					uni.hideLoading()
					this.payLoading = false

					uni.showToast({
						title: '暂未支持',
						icon: 'none',
						duration: 3000,
					})
				} else if (this.payChannel == 'wxMp') {
					var that = this
					uni.requestPayment({
						provider: 'wxpay',
						timeStamp: payInfo.timeStamp,
						nonceStr: payInfo.nonceStr,
						package: payInfo.package,
						signType: payInfo.signType,
						paySign: payInfo.paySign,
						success: (res) => {
							uni.hideLoading()
							that.payLoading = false

							uni.redirectTo({
								url: '/pages/pay/success'
							})
						},
						fail: (res) => {
							uni.hideLoading()
							that.payLoading = false
						},
					})
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-bg-color;
	}
</style>