<template>
	<view class="flex-column bg-page" style="padding-bottom: 140rpx;">
		<view class="navigation flex-column bg-section">
			<view class="flex-row-center flex-content-space" v-if="navBarInfo"
				:style="{width: navBarInfo.navBar.width + 'px', height: navBarInfo.navBar.height + 'px', marginTop: navBarInfo.navBar.top + 'px'}">
				<text class="font-title-l space-mx-10">购物车</text>
				<text class="font-main-l space-mx-10" @click="clickManager">{{isManager ? '完成' : '管理'}}</text>
			</view>
		</view>
		<template v-if="isLogin">
			<view class="flex-column" v-if="list.length > 0">
				<view class="flex-row-center bg-section space-pa-10 space-mt-10"
					:style="{opacity: item.errorMessage ? 0.8 : 1}" v-for="(item, index) in list" :key="item.id">
					<radio class="space-mr-5" @click="selectItem(index)" :disabled="item.errorMessage != ''"
						:checked="item.isSelected" v-if="!isManager">
					</radio>
					<image style="width: 160rpx;height: 160rpx;border-radius: 10rpx;"
						:src="item.productSpecAttr ? item.productSpecAttr.image.url : (item.product.image.url ? item.product.image.url : '/static/logo.png')"
						mode="aspectFill" @click="clickProduct(index)"></image>
					<view class="flex-column flex-width-fill space-ml-5">
						<text class="font-line1 font-main-l" @click="clickProduct(index)">{{item.product.name}}</text>
						<text class="font-base space-mt-5"
							v-if="item.productSpecAttr">{{item.productSpecAttr.name}}</text>
						<view class="flex-row-center flex-content-space space-mt-5">
							<text
								class="font-price space-mt-5">￥{{$utils.apiMoneyToShow(item.productSpecAttr ? item.productSpecAttr.price : item.product.price)}}</text>
							<uni-number-box v-model="item.quantity" :min="1"
								@change="($value) => {changeQuantity(index, $value)}" v-if="!isManager" />
						</view>
						<text class="font-main color-active space-mt-5"
							v-if="item.errorMessage">{{item.errorMessage}}</text>
					</view>
					<uni-icons class="space-ml-10" type="minus-filled" size="48rpx" color="#e64340" v-if="isManager"
						@click="deleteItem(index)"></uni-icons>
				</view>
			</view>
			<data-empty v-else></data-empty>
			<view class="settle flex-row-center bg-section space-px-10" v-if="!isManager">
				<radio :checked="isAllSelected" @click="selectAll"></radio>
				<text class="flex-width-fill font-base space-ml-3" @click="selectAll">全选</text>
				<text class="font-title-s">合计:</text>
				<text class="font-price space-mr-10">￥{{$utils.apiMoneyToShow(totalAmount)}}</text>
				<button size="default" type="warn" style="width: 180rpx;height: 80rpx;line-height: 80rpx;"
					@click="clickSettle">结算</button>
			</view>
		</template>
		<template v-else>
			<button size="default" type="warn" style="margin-top: 100rpx;" @click="clickLogin">请登录</button>
		</template>
	</view>
</template>

<script>
	import {
		useUserStore
	} from '@/store/user'
	import {
		setBadges,
		showBadges
	} from '@/utils/badge'
	import {
		getCarts,
		updateCart,
		deleteCart,
	} from '@/api/cart'
	export default {
		data() {
			return {
				navBarInfo: null,
				isLogin: false,
				list: [],
				isManager: false,
				isAllSelected: false,
				selectIdMap: new Map(),
				totalAmount: 0,
			}
		},
		onLoad() {
			this.navBarInfo = this.$utils.getNavBarInfo()
		},
		onShow() {
			showBadges()

			this.isLogin = useUserStore().isLogin()
			if (this.isLogin) {
				this.loadData()
			}
		},
		methods: {
			clickLogin() {
				uni.navigateTo({
					url: '/pages/login/login'
				})
			},

			loadData() {
				getCarts().then(res => {
					var list = res.data

					list.forEach(item => {
						if (this.selectIdMap.has(item.id) && item.errorMessage == '') {
							item.isSelected = true
						} else {
							item.isSelected = false
						}
					})

					this.list = list

					this.calcSelectAll()
				})
			},

			clickManager() {
				this.isManager = !this.isManager
			},

			clickProduct(index) {
				if (this.list[index].product.id > 0) {
					uni.navigateTo({
						url: '/pages/product/detail?id=' + this.list[index].product.id
					})
				}
			},

			changeQuantity(index, value) {
				var item = this.list[index]
				var params = {
					productId: item.product.id,
					quantity: value
				}

				if (item.productSpecAttr) {
					params.productSpecAttrId = item.productSpecAttr.id
				}

				updateCart(item.id, params).then(res => {
					this.loadData()
				}).catch(err => {
					this.loadData()
				})
			},

			selectItem(index) {
				if (this.list[index].errorMessage != "") {
					return
				}

				this.list[index].isSelected = !this.list[index].isSelected

				this.calcSelectAll()
			},

			deleteItem(index) {
				var that = this
				uni.showModal({
					title: '提示',
					content: '确定删除吗？',
					success: function(res) {
						if (res.confirm) {
							deleteCart(that.list[index].id).then(res => {
								that.list.splice(index, 1)

								setBadges({
									cartCount: res.data.totalCount
								})
								showBadges()

								that.calcSelectAll()
							})
						}
					}
				});
			},

			selectAll() {
				var selectIdMap = new Map()

				this.isAllSelected = !this.isAllSelected

				this.list.forEach(item => {
					if (item.errorMessage == '') {
						item.isSelected = this.isAllSelected
					}

					if (item.isSelected) {
						selectIdMap.set(item.id, true)
					}
				})

				this.selectIdMap = selectIdMap

				this.calcTotal()
			},

			calcSelectAll() {
				var isCanSelected = false
				var isAllSelected = true
				var selectIdMap = new Map()

				this.list.forEach(item => {
					if (item.isSelected) {
						isCanSelected = true
						selectIdMap.set(item.id, true)
					} else {
						if (item.errorMessage == '') {
							isCanSelected = true
							isAllSelected = false
						}
					}
				})

				this.isAllSelected = isCanSelected && isAllSelected
				this.selectIdMap = selectIdMap

				this.calcTotal()
			},

			calcTotal() {
				var totalAmount = 0

				this.list.forEach(item => {
					if (item.isSelected) {
						var price = item.productSpecAttr ? item.productSpecAttr.price : item.product.price
						totalAmount += price * item.quantity
					}
				})

				this.totalAmount = totalAmount
			},

			clickSettle() {
				var cartIdList = []

				this.list.forEach(item => {
					if (item.isSelected) {
						cartIdList.push(item.id)
					}
				})

				if (cartIdList.length == 0) {
					uni.showToast({
						title: '请选择商品',
						icon: 'none',
						duration: 3000,
					})
					return
				}

				uni.navigateTo({
					url: '/pages/cart/settle?cartIds=' + cartIdList.join(',')
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-bg-color;
	}

	.navigation {
		position: sticky;
		top: 0;
		z-index: 20;
	}

	.settle {
		position: fixed;
		left: 0;
		bottom: var(--window-bottom);
		right: 0;
		height: 120rpx;
		border-top: 1px solid $uni-border-2;
	}
</style>