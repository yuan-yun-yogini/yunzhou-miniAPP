<template>
	<view class="flex-column">
		<view class="header flex-column bg-section">
			<view class="flex-column" v-if="navBarInfo">
				<view class="flex-row-center"
					:style="{width: navBarInfo.navBar.width + 'px', marginTop: searchTop + 'px'}">
					<uni-icons class="space-ml-10" type="back" size="48rpx" @click="clickBack"></uni-icons>
					<view class="flex-width-fill space-mr-10">
						<uni-search-bar placeholder="请输入产品名称" v-model="searchValue" :focus="isSearch"
							@confirm="clickSearch" @clear="clickClearSearch"
							@cancel="clickClearSearch"></uni-search-bar>
					</view>
				</view>
			</view>
			<view class="sort-container flex-row space-py-5 space-px-20">
				<view class="flex-row-center" v-for="(item, index) in sortList" :key="item.sort"
					@click="clickSort(index)">
					<text class="font-base space-pb-4"
						:class="{'title-active': item.isActive, 'color-active': item.isActive}">{{item.title}}</text>
					<view class="arrow flex-column space-ml-2" v-if="item.isArrow">
						<view class="up" :class="[sortValue == item.sort + 'Asc' ? 'up-active' : 'up-inactive']"></view>
						<view class="down" :class="[sortValue == item.sort + 'Desc' ? 'down-active' : 'down-inactive']">
						</view>
					</view>
				</view>
			</view>
		</view>
		<product-waterfall class="bg-container" :class="{'space-pa-10': list.length > 0}" :column-num="2"
			:column-width="340" @clickItem="clickProduct" ref="productWaterfall"></product-waterfall>
		<uni-load-more iconType="auto" status="loading" v-if="loading" />
		<data-empty v-if="loaded && list.length == 0"></data-empty>
	</view>
</template>

<script>
	import {
		getProducts
	} from '@/api/product'
	export default {
		data() {
			return {
				navBarInfo: undefined,
				searchTop: 0,
				searchValue: '',
				isSearch: false,
				categoryId: 0,
				list: [],
				loading: false,
				loaded: false,
				loadingType: 'nomore',
				sortList: [{
					title: '综合排序',
					sort: '',
					isArrow: false,
					isActive: true,
				}, {
					title: '销量',
					sort: 'salesVolumnDesc',
					isArrow: false,
					isActive: false,
				}, {
					title: '价格',
					sort: 'price',
					isArrow: true,
					isActive: false,
				}],
				sortValue: '',
				paramsCache: '',
			}
		},
		onLoad(options) {
			this.navBarInfo = this.$utils.getNavBarInfo()
			//uni-search-bar高56px
			this.searchTop = Math.max(this.navBarInfo.menu.top + (this.navBarInfo.menu.height / 2) - (56 / 2), 0)

			if (options.categoryId) {
				this.categoryId = options.categoryId
			}

			if (options.isSearch) {
				this.isSearch = true
			}

			this.loadData()
		},
		onReachBottom() {
			if (this.loadingType == 'more') {
				this.loadData('more')
			}
		},
		methods: {
			loadData(source) {
				var params = {
					offset: 0,
					limit: 10
				}

				if (source == 'more') {
					params.offset = this.list.length
					this.loadingType = 'loading'
				} else {
					this.loadingType = 'nomore'
				}

				if (this.categoryId > 0) {
					params.categoryId = this.categoryId
				}
				if (this.searchValue) {
					params.name = this.searchValue
				}
				if (this.sortValue) {
					params.sort = this.sortValue
				}

				var paramsCache = JSON.stringify(params)
				if (this.paramsCache == paramsCache) {
					return
				}
				this.paramsCache = paramsCache

				if (this.loading) {
					return
				}

				this.loading = true

				getProducts(params).then(res => {
					var list = res.data

					if (source == 'more') {
						this.list = this.list.concat(list)
						this.$refs.productWaterfall.addDataList(list)
					} else {
						this.list = list
						this.$refs.productWaterfall.setDataList(list)
					}

					this.loadingType = res.data.length < params.limit ? 'nomore' : 'more'

					this.loading = false
					this.loaded = true
				}).catch(() => {
					this.loading = false
				})
			},

			clickBack() {
				if (getCurrentPages().length > 1) {
					uni.navigateBack()
				} else {
					uni.switchTab({
						url: '/pages/index/index'
					})
				}
			},

			clickSearch() {
				this.loadData('refresh')
			},

			clickClearSearch() {
				this.searchValue = ''
				this.loadData('refresh')
			},

			clickSort(index) {
				var list = this.sortList
				for (var i = 0; i < list.length; i++) {
					list[i].isActive = (index == i)
				}
				this.sortList = list

				var item = list[index]
				if (item.isArrow) {
					if (this.sortValue == item.sort + 'Asc') {
						this.sortValue = item.sort + 'Desc'
					} else {
						this.sortValue = item.sort + 'Asc'
					}
				} else {
					this.sortValue = item.sort
				}

				this.loadData('refresh')
			},

			clickProduct(item) {
				uni.navigateTo({
					url: '/pages/product/detail?id=' + item.id
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	.header {
		position: sticky;
		top: 0;
		z-index: 20;
	}

	.sort-container {
		column-gap: 80rpx;

		.title-active {
			border-bottom: 4rpx solid $color-active;
		}

		.arrow {
			display: flex;
			flex-direction: column;

			.up {
				width: 0;
				height: 0;
				margin-top: -12rpx;
			}

			.up-inactive {
				border: solid 6rpx transparent;
				border-bottom-color: $uni-secondary-color;
			}

			.up-active {
				border: solid 6rpx transparent;
				border-bottom-color: $color-active;
			}

			.down {
				margin-top: 2rpx;
				width: 0;
				height: 0;
				border: solid 6rpx transparent;
				border-top-color: $uni-secondary-color;
				margin-bottom: -4rpx;
			}

			.down-inactive {
				border: solid 6rpx transparent;
				border-top-color: $uni-secondary-color;
			}

			.down-active {
				border: solid 6rpx transparent;
				border-top-color: $color-active;
			}
		}
	}
</style>