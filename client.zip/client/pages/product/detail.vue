<template>
	<view class="flex-column" style="padding-bottom: 120rpx;">
		<view class="navigation flex-row-center" v-if="navBarInfo"
			:style="{height: navBarInfo.navBar.height + 'px', marginTop: navBarInfo.navBar.top + 'px'}">
			<view class="back flex-column-center space-ml-10">
				<uni-icons type="back" size="40rpx" color="#ffffff" @click="clickBack"></uni-icons>
			</view>
		</view>
		<view class="flex-column" v-if="product">
			<swiper style="height: 750rpx;" circular :indicator-dots="true" :autoplay="false">
				<swiper-item v-for="(item, index) in product.images" :key="item.id">
					<image style="width: 100%;height: 750rpx;" :src="item.url" mode="aspectFill"
						@click="clickProductImage(index)"></image>
				</swiper-item>
			</swiper>
			<view class="flex-column space-pa-10">
				<text class="font-title font-line2">{{product.name}}</text>
				<view class="flex-row-center flex-content-space space-mt-10">
					<view class="flex-row" style="align-items: flex-end;" v-if="specAttr">
						<text class="font-price">￥{{$utils.apiMoneyToShow(specAttr.price)}}</text>
						<text class="font-secondary space-ml-5" style="text-decoration: line-through;"
							v-if="specAttr.originalPrice > 0 && specAttr.originalPrice != specAttr.price">￥{{ $utils.apiMoneyToShow(specAttr.originalPrice) }}</text>
					</view>
					<view class="flex-row" style="align-items: flex-end;" v-if="!specAttr">
						<text class="font-price">￥{{$utils.apiMoneyToShow(product.price)}}</text>
						<text class="font-secondary space-ml-5" style="text-decoration: line-through;"
							v-if="product.originalPrice > 0 && product.originalPrice != product.price">￥{{ $utils.apiMoneyToShow(product.originalPrice) }}</text>
					</view>
					<text class="font-base">已售 {{product.salesVolumn}}</text>
				</view>
				<text class="font-base space-mt-10" v-if="!specAttr">{{getStockText(product.stock)}}</text>
				<view class="flex-row-center space-mt-20" v-if="specAttr" @click="openSpec">
					<text class="font-base">购买类型</text>
					<text class="flex-width-fill font-line1 font-secondary space-ml-10"
						style="text-align: right;">{{specAttr.name}}</text>
					<uni-icons class="space-ml-5" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
				</view>
			</view>
			<view class="sep bg-container"></view>
			<view class="flex-column space-pa-10">
				<view class="flex-row-center flex-content-space">
					<text class="font-title">商品评价({{product.ealuateStatistics.averageScore}}分)</text>
					<view class="flex-row-center" @click="clickEvaluateDetail">
						<text class="font-base">查看全部({{product.ealuateStatistics.totalCount}})</text>
						<uni-icons class="space-ml-5" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
					</view>
				</view>
				<view class="flex-row-center space-mt-10" v-for="(item, index) in product.ealuateStatistics.evaluates"
					:key="item.id"
					v-if="product.ealuateStatistics.evaluates && product.ealuateStatistics.evaluates.length > 0">
					<view class="flex-column flex-width-fill">
						<view class="flex-row-center">
							<image style="width: 40rpx;height: 40rpx;border-radius: 50%;"
								:src="item.user.avatar ? item.user.avatar.url : '/static/avatar.png'" mode="aspectFill">
							</image>
							<text class="font-main space-ml-5 space-mr-10">{{item.user.name}}</text>
							<uni-rate size="18" :readonly="true" :value="item.score" />
						</view>
						<text class="font-line3 font-base space-mt-10">{{item.content}}</text>
					</view>
					<image class="space-ml-10" style="width: 100rpx;height: 100rpx;" :src="item.images[0].url"
						mode="aspectFill" v-if="item.images && item.images.length > 0"
						@click="previewImage(item.images[0].url)"></image>
				</view>
			</view>
			<view class="sep bg-container"></view>
			<view class="flex-column space-py-10">
				<text class="font-title space-mx-10">商品详情</text>
				<text class="font-main space-mx-10 space-mt-10" style="word-wrap: break-word;"
					v-if="product.description">{{product.description}}</text>
				<image style="width: 100%" :class="{'space-mt-10': index == 0}" :src="item.url" mode="widthFix"
					v-for="(item, index) in product.detailImages" :key="item.id"
					@click="clickProductDetailImage(item.url)"
					v-if="product.detailImages && product.detailImages.length > 0">
				</image>
			</view>

			<view class="carts">
				<uni-goods-nav :options="cartOptions" :fill="true" :button-group="cartButtonGroup"
					@click="clickCartLeft" @buttonClick="clickCartRight" />
			</view>
		</view>

		<uni-popup ref="popupSpec" v-if="specAttr">
			<view class="flex-column bg-section uni-radius-t-lg space-pa-10" style="position: relative;">
				<uni-icons style="position: absolute;top: 20rpx;right: 20rpx;" type="closeempty" size="40rpx"
					@click="closeSpec"></uni-icons>
				<view class="flex-row-center space-mt-20">
					<image style="width: 160rpx;height:160rpx" :src="specAttr.image.url" mode="aspectFill"
						@click="clickSpecImage"></image>
					<view class="flex-column space-ml-10">
						<view class="flex-row" style="align-items: flex-end;">
							<text class="font-price">￥{{$utils.apiMoneyToShow(specAttr.price)}}</text>
							<text class="font-secondary space-ml-5" style="text-decoration: line-through;"
								v-if="specAttr.originalPrice > 0 && specAttr.originalPrice != specAttr.price">￥{{ $utils.apiMoneyToShow(specAttr.originalPrice) }}</text>
						</view>
						<text class="font-base space-mt-10">{{getStockText(specAttr.stock)}}</text>
						<uni-number-box class="space-mt-10" :min="1" v-model="quantity" />
					</view>
				</view>
				<view class="flex-column space-my-10" style="align-items: flex-start;"
					v-for="(item, index) in product.specs" :key="index">
					<text class="font-title">{{item.name}}</text>
					<text class="font-base bg-default space-mt-10 space-px-10 space-py-6 uni-radius"
						:class="{'spec-attr-active': item.activeIndex == index1}" v-for="(item1, index1) in item.attrs"
						:key="index1" @click="selectSpecAttr(index, index1)">{{item1}}</text>
				</view>
				<uni-goods-nav class="space-mt-20" :options="specOptions" :fill="true" :button-group="specButtonGroup"
					@buttonClick="clickSpecRight" />
			</view>
		</uni-popup>
	</view>
</template>

<script>
	import {
		useUserStore
	} from '@/store/user';
	import {
		setBadges,
		getBadges
	} from '@/utils/badge';
	import {
		getProduct
	} from '@/api/product'
	import {
		createCart
	} from '@/api/cart'
	export default {
		data() {
			return {
				navBarInfo: undefined,
				id: 0,
				product: null,
				specAttr: null,
				quantity: 1,
				cartOptions: [{
					icon: 'chat',
					text: '客服'
				}, {
					icon: 'cart',
					text: '购物车',
					info: 0
				}],
				cartButtonGroup: [{
						text: '加入购物车',
						backgroundColor: 'linear-gradient(90deg, #FFCD1E, #FF8A18)',
						color: '#fff'
					},
					{
						text: '立即购买',
						backgroundColor: 'linear-gradient(90deg, #FE6035, #EF1224)',
						color: '#fff'
					}
				],
				specOptions: [],
				specButtonGroup: [{
						text: '加入购物车',
						backgroundColor: 'linear-gradient(90deg, #FFCD1E, #FF8A18)',
						color: '#fff'
					},
					{
						text: '立即购买',
						backgroundColor: 'linear-gradient(90deg, #FE6035, #EF1224)',
						color: '#fff'
					}
				],
			}
		},
		onLoad(options) {
			this.navBarInfo = this.$utils.getNavBarInfo()

			this.id = options.id

			this.loadData()
		},
		onShow() {
			this.cartOptions[1].info = getBadges().cartCount
		},
		methods: {
			loadData() {
				getProduct(this.id).then(res => {
					var product = res.data

					if (product.specs && product.specs.length > 0) {
						product.specs.forEach(item => {
							item.activeIndex = 0
						})
					}

					this.product = product

					if (product.specs && product.specs.length > 0) {
						this.selectSpecAttr(0, 0)
					}
				})
			},

			clickBack() {
				if (getCurrentPages().length > 1) {
					uni.navigateBack()
				} else {
					uni.switchTab({
						url: '/pages/index/index'
					})
				}
			},

			clickEvaluateDetail() {
				uni.navigateTo({
					url: '/pages/product/evaluate?productId=' + this.product.id
				})
			},

			getStockText(stock) {
				if (stock < 0) {
					return '有货';
				} else if (stock == 0) {
					return '缺货';
				} else if (stock < 20) {
					return '库存 ' + stock;
				} else {
					return '有货';
				}
			},

			openSpec() {
				this.$refs.popupSpec.open('bottom')
			},

			closeSpec() {
				this.$refs.popupSpec.close()
			},

			selectSpecAttr(index, index1) {
				this.product.specs[index].activeIndex = index1

				var specAttrNameList = []

				this.product.specs.forEach(item => {
					specAttrNameList.push(item.attrs[item.activeIndex])
				})

				var specAttrName = specAttrNameList.join(',')

				for (var i = 0; i < this.product.specAttrs.length; i++) {
					var item = this.product.specAttrs[i]

					if (item.name == specAttrName) {
						this.specAttr = item
						break
					}
				}
			},

			clickCartLeft(e) {
				if (!useUserStore().isLogin()) {
					uni.navigateTo({
						url: '/pages/login/login'
					})
					return
				}

				if (e.index == 0) { //客服
					uni.navigateTo({
						url: '/pages/setting/customer-service'
					})
				} else if (e.index == 1) { //购物车
					uni.switchTab({
						url: '/pages/cart/cart'
					})
				}
			},

			clickCartRight(e) {
				if (!useUserStore().isLogin()) {
					uni.navigateTo({
						url: '/pages/login/login'
					})
					return
				}

				if (e.index == 0) { //加入购物车
					if (this.product.specs && this.product.specs.length > 0) {
						this.openSpec()
					} else {
						if (!this.checkStock()) {
							return
						}

						this.addCart()
					}
				} else if (e.index == 1) { //立即购买
					if (this.product.specs && this.product.specs.length > 0) {
						this.openSpec()
					} else {
						if (!this.checkStock()) {
							return
						}

						this.buy()
					}
				}
			},

			clickSpecRight(e) {
				if (!useUserStore().isLogin()) {
					uni.navigateTo({
						url: '/pages/login/login'
					})
					return
				}

				if (!this.checkStock()) {
					return
				}

				if (e.index == 0) { //加入购物车
					this.addCart()
					this.closeSpec()
				} else if (e.index == 1) { //立即购买
					this.buy()
					this.closeSpec()
				}
			},

			checkStock() {
				if (this.specAttr) {
					if (this.specAttr.stock >= 0 && this.specAttr.stock < this.quantity) {
						uni.showToast({
							title: '库存不足',
							icon: 'none',
							duration: 3000,
						})
						return false
					}
				} else {
					if (this.product.stock >= 0 && this.product.stock < this.quantity) {
						uni.showToast({
							title: '库存不足',
							icon: 'none',
							duration: 3000,
						})
						return false
					}
				}

				return true
			},

			addCart() {
				var params = {
					productId: this.product.id,
					quantity: this.quantity,
				}

				if (this.specAttr) {
					params.productSpecAttrId = this.specAttr.id
				}

				createCart([params]).then(res => {
					uni.showToast({
						title: '加入购物车成功',
						icon: 'none',
						duration: 3000,
					})

					setBadges({
						cartCount: res.data.totalCount
					})

					this.cartOptions[1].info = getBadges().cartCount
				})
			},

			buy() {
				var query = 'productId=' + this.product.id
				if (this.specAttr) {
					query += '&productSpecAttrId=' + this.specAttr.id
				}
				query += '&quantity=' + this.quantity

				uni.navigateTo({
					url: '/pages/cart/settle?' + query
				})
			},

			clickProductImage(index) {
				var urlList = []
				this.product.images.forEach(item => {
					urlList.push(item.url)
				})
				uni.previewImage({
					urls: urlList,
					current: index,
				})
			},

			clickSpecImage() {
				uni.previewImage({
					urls: [this.specAttr.image.url],
					current: 0,
				})
			},

			clickProductDetailImage(index) {
				var urlList = []
				this.product.detailImages.forEach(item => {
					urlList.push(item.url)
				})
				uni.previewImage({
					urls: urlList,
					current: index,
				})
			},

			previewImage(url) {
				uni.previewImage({
					urls: [url],
					current: 0,
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	.navigation {
		position: fixed;
		z-index: 20;
		left: 0;

		.back {
			width: 48rpx;
			height: 48rpx;
			border-radius: 50%;
			background-color: #666666;
			justify-content: center;
		}
	}

	.sep {
		height: 20rpx;
	}

	.carts {
		display: flex;
		flex-direction: column;
		position: fixed;
		left: 0;
		right: 0;
		bottom: 0;
		z-index: 50;
		border-top: 1px solid $uni-border-2;
	}

	.spec-attr-active {
		color: $color-active !important;
		background-color: #fff6f1 !important;
		border: 1rpx solid $color-active;
	}
</style>