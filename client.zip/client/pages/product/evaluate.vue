<template>
	<view class="flex-column bg-page space-pb-10">
		<view class="flex-column bg-section space-mt-10 space-pa-10" v-for="(item, index) in list" :key="item.id">
			<view class="flex-row-center">
				<image style="width: 40rpx;height: 40rpx;border-radius: 50%;"
					:src="item.user.avatar ? item.user.avatar.url : '/static/avatar.png'" mode="aspectFill">
				</image>
				<text class="font-title-s space-ml-5 space-mr-10">{{item.user.name}}</text>
				<uni-rate size="18" :readonly="true" :value="item.score" />
			</view>
			<view class="flex-row-center space-mt-10">
				<text class="flex-width-fill font-line1 font-secondary space-mr-10">{{item.productSpecAttrName}}</text>
				<text
					class="font-secondary">{{$utils.formatDate($utils.newDateWithStr(item.createdAt), 'yyyy-MM-dd')}}</text>
			</view>
			<text class="font-main space-mt-10">{{item.content}}</text>
			<view class="flex-row space-mt-10" style="flex-wrap: wrap;gap: 20rpx"
				v-if="item.images && item.images.length > 0">
				<image style="width: 200rpx;height: 200rpx;" :src="itemImage.url" mode="aspectFill"
					v-for="(itemImage, indexImage) in item.images" :key="itemImage.id"
					@click="clickEvaluateImage(index, indexImage, false)"></image>
			</view>
			<template
				v-if="item.status == 'append' && (item.appendContent != '' || (item.appendImages && item.appendImages.length > 0))">
				<view class="flex-row-center flex-content-space space-mt-10">
					<text class="font-title-s">追加评价：</text>
					<text
						class="font-secondary">{{$utils.formatDate($utils.newDateWithStr(item.appendTime), 'yyyy-MM-dd')}}</text>
				</view>
				<view class="flex-column space-ml-20">
					<text class="font-main space-mt-10">{{item.appendContent}}</text>
					<view class="flex-row space-mt-10" style="flex-wrap: wrap;gap: 20rpx"
						v-if="item.appendImages && item.appendImages.length > 0">
						<image style="width: 200rpx;height: 200rpx;" :src="itemImage.url" mode="aspectFill"
							v-for="(itemImage, indexImage) in item.appendImages" :key="itemImage.id"
							@click="clickEvaluateImage(index, indexImage, true)"></image>
					</view>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import {
		getEvaluates,
	} from '@/api/product'
	export default {
		data() {
			return {
				productId: 0,
				list: [],
				loading: false,
				loaded: false,
				loadingType: 'nomore',
			};
		},
		onLoad(options) {
			this.productId = options.productId

			this.loadData('refresh')
		},
		onReachBottom() {
			if (this.loadingType == 'more') {
				this.loadData('more')
			}
		},
		methods: {
			loadData(source) {
				var params = {
					offset: 0,
					limit: 20,
					productId: this.productId,
				}

				if (source == 'more') {
					params.offset = this.list.length
					this.loadingType = 'loading'
				} else {
					this.loadingType = 'nomore'
				}

				if (this.loading) {
					return
				}

				this.loading = true

				getEvaluates(params).then(res => {
					var list = res.data

					if (source == 'more') {
						this.list = this.list.concat(list)
					} else {
						this.list = list
					}

					this.loadingType = res.data.length < params.limit ? 'nomore' : 'more'

					this.loading = false
					this.loaded = true
				}).catch(() => {
					this.loading = false
				})
			},

			clickEvaluateImage(index, indexImage, isAppend) {
				var evaluate = this.list[index]
				var urlList = []

				if (isAppend) {
					evaluate.appendImages.forEach(item => {
						urlList.push(item.url)
					})
				} else {
					evaluate.images.forEach(item => {
						urlList.push(item.url)
					})
				}

				uni.previewImage({
					urls: urlList,
					current: indexImage,
				})
			},
		},
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-bg-color;
	}
</style>