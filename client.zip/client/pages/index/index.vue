<template>
	<view class="flex-column">
		<view class="navigation flex-column bg-section" v-if="navBarInfo">
			<view :style="{width: navBarInfo.navBar.width + 'px', marginTop: searchTop + 'px'}" @click="clickSearch">
				<uni-search-bar placeholder="搜索产品" :readonly="true"></uni-search-bar>
			</view>
		</view>

		<swiper class="space-mt-10" style="height: 300rpx;" circular :indicator-dots="banners.indexTop1.indicatorDots"
			:autoplay="banners.indexTop1.autoplay" :interval="banners.indexTop1.interval"
			:duration="banners.indexTop1.duration">
			<swiper-item v-for="(item, index) in banners.indexTop1.list" :key="item.id" @click="clickBanner(item)">
				<image style="width: 100%;height: 300rpx;" :src="item.image.url" mode="aspectFill"></image>
			</swiper-item>
		</swiper>

		<uni-grid class="space-mt-10" :column="5" :highlight="true" :showBorder="false" :square="false"
			@change="clickCategory">
			<uni-grid-item v-for="(item, index) in categoryList" :key="item.id" :index="index">
				<view class="flex-column-center space-py-10">
					<image style="width: 60rpx;height: 60rpx;" :src="item.image.url" mode="aspectFit"></image>
					<text class="font-main-l space-mt-8">{{item.name}}</text>
				</view>
			</uni-grid-item>
		</uni-grid>

		<swiper class="space-my-10" style="height: 160;" circular :indicator-dots="banners.indexTop2.indicatorDots"
			:autoplay="banners.indexTop2.autoplay" :interval="banners.indexTop2.interval"
			:duration="banners.indexTop2.duration">
			<swiper-item v-for="(item, index) in banners.indexTop2.list" :key="item.id" @click="clickBanner(item)">
				<image style="width: 100%;height: 160rpx;" :src="item.image.url" mode="aspectFill"></image>
			</swiper-item>
		</swiper>

		<product-waterfall class="bg-container space-pa-10" :column-num="2" :column-width="340" ref="productWaterfall"
			@clickItem="clickProduct"></product-waterfall>
	</view>
</template>

<script>
	import {
		useUserStore
	} from '@/store/user'
	import {
		showBadges
	} from '@/utils/badge'
	import {
		getBanners
	} from '@/api/banner'
	import {
		getCategorys
	} from '@/api/category'
	import {
		getProducts
	} from '@/api/product'
	export default {
		data() {
			return {
				navBarInfo: undefined,
				searchTop: 0,
				banners: {
					indexTop1: {
						indicatorDots: true,
						autoplay: true,
						interval: 5000,
						duration: 500,
						list: [],
					},
					indexTop2: {
						indicatorDots: true,
						autoplay: true,
						interval: 5000,
						duration: 500,
						list: [],
					},
				},
				categoryList: [],
				productList: [],
				loading: false,
				loaded: false,
				loadingType: 'nomore',
			}
		},
		onLoad() {
			this.navBarInfo = this.$utils.getNavBarInfo()
			//uni-search-bar高56px
			this.searchTop = Math.max(this.navBarInfo.menu.top + (this.navBarInfo.menu.height / 2) - (56 / 2), 0)

			this.loadBanner()
			this.loadCategory()
			this.loadProduct('refresh')
		},
		onShow() {
			showBadges()
		},
		onReachBottom() {
			this.loadProduct('more')
		},
		methods: {
			loadBanner() {
				getBanners({
					types: 'indexTop1,indexTop2'
				}).then(res => {
					var indexTop1List = []
					var indexTop2List = []

					res.data.forEach(item => {
						switch (item.type) {
							case 'indexTop1':
								indexTop1List.push(item)
								break
							case 'indexTop2':
								indexTop2List.push(item)
								break
						}
					})

					this.banners.indexTop1.list = indexTop1List
					this.banners.indexTop2.list = indexTop2List
				})
			},

			loadCategory() {
				getCategorys().then(res => {
					var list = []

					res.data.forEach(item => {
						if (!item.parentId) {
							list.push(item)
						}
					})

					this.categoryList = list
				})
			},

			loadProduct(source) {
				var params = {
					offset: 0,
					limit: 10
				}

				if (source == 'more') {
					params.offset = this.productList.length
					this.loadingType = 'loading'
				} else {
					this.loadingType = 'nomore'
				}

				if (this.loading) {
					return
				}

				this.loading = true

				getProducts(params).then(res => {
					var list = res.data

					if (source == 'more') {
						this.productList = this.productList.concat(list)
						this.$refs.productWaterfall.addDataList(list)
					} else {
						this.productList = list
						this.$refs.productWaterfall.setDataList(list)
					}

					this.loadingType = res.data.length < params.limit ? 'nomore' : 'more'

					this.loading = false
					this.loaded = true
				}).catch(() => {
					this.loading = false
				})
			},

			clickSearch() {
				uni.navigateTo({
					url: '/pages/product/product?isSearch=1'
				})
			},

			clickCategory(e) {
				var item = this.categoryList[e.detail.index]
				uni.navigateTo({
					url: '/pages/product/product?categoryId=' + item.id
				})
			},

			clickBanner(item) {
				if (item.url) {
					uni.navigateTo({
						url: item.url,
					})
				} else {
					uni.navigateTo({
						url: '/pages/banner/banner?id=' + item.id
					})
				}
			},

			clickProduct(item) {
				uni.navigateTo({
					url: '/pages/product/detail?id=' + item.id
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	.navigation {
		position: sticky;
		top: 0;
		z-index: 20;
	}
</style>