<template>
	<view class="flex-column bg-page space-pb-10">
		<view class="flex-row-center bg-section space-mt-10 space-pa-10" v-for="(item, index) in this.product.resources"
			:key="item.id" v-if="this.product">
			<text class="flex-width-fill font-title space-mr-10">{{item.name}}</text>
			<button size="mini" type="primary" @click="clickResource(index)">{{getResourceTypeText(item.type)}}</button>
		</view>
	</view>
</template>

<script>
	import {
		getOrderProductResource
	} from '@/api/order'
	export default {
		data() {
			return {
				product: null,
				typeList: [{
					type: 'video',
					title: '播放',
				}, {
					type: 'audio',
					title: '播放',
				}, {
					type: 'document',
					title: '打开',
				}, {
					type: 'file',
					title: '下载',
				}]
			};
		},
		onLoad(options) {
			this.loadData(options.id)
		},
		methods: {
			loadData(id) {
				getOrderProductResource(id).then(res => {
					this.product = res.data
				})
			},

			getResourceTypeText(type) {
				for (var i = 0; i < this.typeList.length; i++) {
					if (this.typeList[i].type == type) {
						return this.typeList[i].title
					}
				}

				return '下载'
			},

			clickResource(index) {
				var item = this.product.resources[index]

				switch (item.type) {
					case 'video':
						this.playVideo(item.url)
						break
					case 'audio':
						this.playAudio(item.url)
						break
					case 'document':
						this.openFile(item.url)
						break
					default:
						this.downloadFile(item.url)
						break
				}
			},

			playVideo(url) {
				uni.navigateTo({
					url: '/pages/resource/video',
					success: function(res) {
						// 通过eventChannel向被打开页面传送数据
						res.eventChannel.emit('acceptDataFromOpenerPage', {
							url: url
						})
					}
				})
			},

			playAudio(url) {
				uni.navigateTo({
					url: '/pages/resource/audio',
					success: function(res) {
						// 通过eventChannel向被打开页面传送数据
						res.eventChannel.emit('acceptDataFromOpenerPage', {
							url: url
						})
					}
				})
			},

			openFile(url) {
				// #ifdef WEB
				window.open(url)
				return
				// #endif
				
				uni.showLoading({
					title: '加载中...'
				})

				uni.downloadFile({
					url: url,
					success: res1 => {
						uni.openDocument({
							filePath: res1.tempFilePath,
							success: res2 => {
								console.log('uni.openDocument', res2)
								uni.hideLoading()
							},
							fail: (err2) => {
								console.log('uni.openDocument', err2)
								uni.hideLoading()
								uni.showToast({
									title: '打开失败',
									icon: 'none',
									duration: 3000,
								})
							}
						})
					},
					fail: err1 => {
						console.log('uni.downloadFile', err1)
						uni.hideLoading()
						uni.showToast({
							title: '下载失败',
							icon: 'none',
							duration: 3000,
						})
					}
				})
			},

			downloadFile(url) {
				// #ifdef WEB
				window.open(url)
				return
				// #endif
				
				uni.showLoading({
					title: '加载中...'
				})

				uni.downloadFile({
					url: url,
					success: res1 => {
						uni.saveFile({
							tempFilePath: res1.tempFilePath,
							success: res2 => {
								console.log('uni.saveFile', res2)
								uni.hideLoading()
								uni.showToast({
									title: '下载成功',
									icon: 'none',
									duration: 3000,
								})
							},
							fail: (err2) => {
								console.log('uni.saveFile', err2)
								uni.hideLoading()
								uni.showToast({
									title: '保存失败',
									icon: 'none',
									duration: 3000,
								})
							}
						})
					},
					fail: err1 => {
						console.log('uni.downloadFile', err1)
						uni.hideLoading()
						uni.showToast({
							title: '下载失败',
							icon: 'none',
							duration: 3000,
						})
					}
				})
			},
		},
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-bg-color;
	}
</style>