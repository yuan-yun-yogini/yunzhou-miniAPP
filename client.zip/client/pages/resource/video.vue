<template>
	<view class="container">
		<video style="width: 100%;height: 100%;" :src="url" @error="videoErrorCallback" controls v-if="url"></video>
	</view>
</template>

<script>
	import {
		getOrderProductResource
	} from '@/api/order'
	export default {
		data() {
			return {
				url: null,
			}
		},
		onLoad() {
			var that = this
			const eventChannel = this.getOpenerEventChannel();
			eventChannel.on('acceptDataFromOpenerPage', function(data) {
				that.url = data.url
			})
		},
		methods: {
			videoErrorCallback(e) {
				uni.showModal({
					content: e.target.errMsg,
					showCancel: false
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		width: 100vw;
		height: calc(100vh - var(--window-top));
	}
</style>