<template>
	<view class="flex-column">
		<audio :src="url" controls v-if="url"></audio>
	</view>
</template>

<script>
	import {
		getOrderProductResource
	} from '@/api/order'
	export default {
		data() {
			return {
				url: null,
			}
		},
		onLoad() {
			var that = this
			const eventChannel = this.getOpenerEventChannel();
			eventChannel.on('acceptDataFromOpenerPage', function(data) {
				that.url = data.url
			})
		},
		methods: {
			
		}
	}
</script>

<style lang="scss" scoped>
	
</style>