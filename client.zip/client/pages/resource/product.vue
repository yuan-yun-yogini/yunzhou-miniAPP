<template>
	<view class="flex-column bg-page space-pb-10">
		<view class="flex-row-center bg-section space-mt-10 space-pa-10" v-for="(item, index) in list" :key="item.id" @click="clickProduct(index)">
			<image style="width: 100rpx;height: 100rpx;border-radius: 10rpx;" :src="item.productImage.url"
				mode="aspectFill"></image>
			<view class="flex-column flex-width-fill space-mx-5">
				<text class="font-line1 font-title">{{item.productName}}</text>
				<text class="font-line1 font-base space-mt-5">{{item.productSpecAttrName}}</text>
			</view>
			<uni-icons class="space-ml-10" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
		</view>
	</view>
</template>

<script>
	import {
		getOrderProductResources,
		getOrderProductResource
	} from '@/api/order'
	export default {
		data() {
			return {
				list: [],
				loading: false,
				loaded: false,
				loadingType: 'nomore',
			};
		},
		onLoad(options) {
			this.loadData('refresh')
		},
		onReachBottom() {
			if (this.loadingType == 'more') {
				this.loadData('more')
			}
		},
		methods: {
			loadData(source) {
				var params = {
					offset: 0,
					limit: 20,
				}

				if (source == 'more') {
					params.offset = this.list.length
					this.loadingType = 'loading'
				} else {
					this.loadingType = 'nomore'
				}

				if (this.loading) {
					return
				}

				this.loading = true

				getOrderProductResources(params).then(res => {
					var list = res.data

					if (source == 'more') {
						this.list = this.list.concat(list)
					} else {
						this.list = list
					}

					this.loadingType = res.data.length < params.limit ? 'nomore' : 'more'

					this.loading = false
					this.loaded = true
				}).catch(() => {
					this.loading = false
				})
			},

			clickProduct(index) {
				uni.navigateTo({
					url: '/pages/resource/resource?id=' + this.list[index].id
				})
			},
		},
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-bg-color;
	}
</style>