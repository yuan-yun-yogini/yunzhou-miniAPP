<template>
	<view>
		<rich-text :nodes="config.configValue" v-if="config"></rich-text>
	</view>
</template>

<script>
	import {
		getConfigs
	} from '@/api/config'
	export default {
		data() {
			return {
				config: null,
			}
		},
		onLoad(options) {
			this.loadData(options.configKey)
		},
		methods: {
			loadData(configKey) {
				getConfigs({
					configKeys: configKey
				}).then(res => {
					if (res.data.length == 0) {
						return
					}
					
					this.config = res.data[0]

					uni.setNavigationBarTitle({
						title: this.config.name
					})
				})
			},
		}
	}
</script>

<style lang="scss" scoped>

</style>