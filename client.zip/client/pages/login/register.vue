<template>
	<view class="flex-column-center">
		<view class="space-mt-20" style="width: 600rpx;">
			<uni-forms ref="loginForm" :modelValue="formData" :rules="rules">
				<uni-forms-item label="用户名" name="username">
					<uni-easyinput type="text" v-model="formData.username" placeholder="请输入用户名" />
				</uni-forms-item>
				<uni-forms-item label="密码" name="password">
					<uni-easyinput type="password" v-model="formData.password" placeholder="请输入密码" />
				</uni-forms-item>
				<uni-forms-item label="确认密码" name="password1">
					<uni-easyinput type="password" v-model="formData.password1" placeholder="请输入确认密码" />
				</uni-forms-item>
				<uni-forms-item label="验证码" name="captchaAnswer">
					<view class="flex-row-center">
						<uni-easyinput type="text" v-model="formData.captchaAnswer" placeholder="请输入验证码"
							@confirm="clickRegister" />
						<image class="space-ml-10" style="width: 120rpx;height: 60rpx;" :src="captchaData"
							mode="aspectFit" @click="loadCaptcha"></image>
					</view>
				</uni-forms-item>
				<view class="flex-row-center" style="justify-content: center;">
					<radio style="transform:scale(0.8)" @click="clickProtocol" :checked="isAgree"></radio>
					<text class="font-base" @click="clickProtocol">注册须同意</text>
					<text class="font-base" style="color: #007aff;" @click="clickService">《用户服务协议》</text>
					<text class="font-base" style="color: #007aff;" @click="clickPrivate">《隐私保护协议》</text>
				</view>
			</uni-forms>
		</view>
		<view class="flex-row-center space-mt-20">
			<button type="primary" @click="clickRegister">注册</button>
			<text class="font-main-l space-ml-20" style="color: #007aff;text-decoration: underline;"
				@click="clickLogin">登录</text>
		</view>
	</view>
</template>

<script>
	import {
		captcha,
		register
	} from '@/api/login'
	import {
		useUserStore
	} from '@/store/user'
	export default {
		data() {
			return {
				formData: {

				},
				isAgree: false,
				captchaData: '',
				rules: {
					username: {
						rules: [{
							required: true,
							errorMessage: '请输入用户名'
						}]
					},
					password: {
						rules: [{
							required: true,
							errorMessage: '请输入密码'
						}, {
							minLength: 6,
							errorMessage: '密码长度至少6位'
						}]
					},
					password1: {
						rules: [{
							required: true,
							errorMessage: '请输入确认密码'
						}]
					},
					captchaAnswer: {
						rules: [{
							required: true,
							errorMessage: '请输入验证码'
						}]
					},
				},
			}
		},
		onLoad() {
			this.loadCaptcha()
		},
		methods: {
			loadCaptcha() {
				captcha().then(res => {
					this.formData.captchaId = res.data.id
					this.captchaData = res.data.imageData
				})
			},

			clickRegister() {
				this.$refs.loginForm.validate().then(() => {
					var usernamePattern = /^[a-zA-Z]\w*$/;
					if (!usernamePattern.test(this.formData.username)) {
						uni.showToast({
							title: '用户名只能由字母、数字和下划线组成，以字母开头',
							icon: 'none',
							duration: 3000,
						})
						return
					}

					if (this.formData.password != this.formData.password1) {
						uni.showToast({
							title: '确认密码不一致',
							icon: 'none',
							duration: 3000,
						})
						return
					}

					if (!this.isAgree) {
						uni.showToast({
							title: '需要同意协议',
							icon: 'none',
							duration: 3000,
						})
						return
					}

					register(this.formData).then(res => {
						uni.showToast({
							title: '注册成功，请登录',
							icon: 'none',
							duration: 3000,
						})

						uni.redirectTo({
							url: '/pages/login/login'
						})
					}).catch(() => {
						this.loadCaptcha()
					})
				}).catch(err => {

				})
			},

			clickLogin() {
				uni.redirectTo({
					url: '/pages/login/login'
				})
			},

			clickProtocol() {
				this.isAgree = !this.isAgree
			},

			clickService() {
				uni.navigateTo({
					url: '/pages/login/protocol?configKey=userServiceProtocol'
				})
			},

			clickPrivate() {
				uni.navigateTo({
					url: '/pages/login/protocol?configKey=userPrivateProtocol'
				})
			},
		}
	}
</script>

<style lang="scss" scoped>

</style>