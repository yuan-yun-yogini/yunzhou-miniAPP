<template>
	<view class="flex-column">
		<view class="flex-column-center" v-if="type == 'username'">
			<view class="space-mt-20" style="width: 600rpx;">
				<uni-forms ref="loginForm" :modelValue="formData" :rules="rules">
					<uni-forms-item label="用户名" name="username">
						<uni-easyinput type="text" v-model="formData.username" placeholder="请输入用户名" />
					</uni-forms-item>
					<uni-forms-item label="密码" name="password">
						<uni-easyinput type="password" v-model="formData.password" placeholder="请输入密码" />
					</uni-forms-item>
					<uni-forms-item label="验证码" name="captchaAnswer">
						<view class="flex-row-center">
							<uni-easyinput style="width: 0;" type="text" v-model="formData.captchaAnswer"
								placeholder="请输入验证码" @confirm="clickLogin" />
							<image class="space-ml-10" style="width: 120rpx;height: 60rpx;" :src="captchaData"
								mode="aspectFit" @click="loadCaptcha"></image>
						</view>
					</uni-forms-item>
					<view class="flex-row-center" style="justify-content: center;">
						<radio style="transform:scale(0.8)" @click="clickProtocol" :checked="isAgree"></radio>
						<text class="font-base" @click="clickProtocol">登录须同意</text>
						<text class="font-base" style="color: #007aff;" @click="clickService">《用户服务协议》</text>
						<text class="font-base" style="color: #007aff;" @click="clickPrivate">《隐私保护协议》</text>
					</view>
				</uni-forms>
			</view>
			<view class="flex-row-center space-mt-20">
				<button type="primary" @click="clickLogin">登录</button>
				<text class="font-main-l space-ml-20" style="color: #007aff;text-decoration: underline;"
					@click="clickRegister">注册</text>
			</view>
		</view>
		<view class="flex-column-center" v-if="type == 'wxMpPhone'">
			<image class="space-mt-20" style="width: 160rpx;height: 160rpx;border-radius: 20rpx;" src="/static/logo.png"
				mode="aspectFill"></image>
			<text class="font-title space-mt-20">手机号快捷一键登录</text>
			<view class="flex-row-center space-mt-20" style="justify-content: center;">
				<radio style="transform:scale(0.8)" @click="clickProtocol" :checked="isAgree"></radio>
				<text class="font-base" @click="clickProtocol">登录须同意</text>
				<text class="font-base" style="color: #007aff;" @click="clickService">《用户服务协议》</text>
				<text class="font-base" style="color: #007aff;" @click="clickPrivate">《隐私保护协议》</text>
			</view>
			<button class="space-mt-20" type="primary" open-type="getPhoneNumber" @getphonenumber="getPhoneNumber"
				v-if="isAgree">一键登录</button>
			<button class="space-mt-20" type="primary" @click="agreeToast" v-else>一键登录</button>
		</view>
	</view>
</template>

<script>
	import {
		useUserStore
	} from '@/store/user'
	import {
		loadBadges
	} from '@/utils/badge';
	import {
		captcha,
		login
	} from '@/api/login'
	import {
		loginWxMpPhone
	} from '@/api/wx'
	export default {
		data() {
			return {
				from: '',
				type: '',
				formData: {

				},
				isAgree: false,
				captchaData: '',
				rules: {
					username: {
						rules: [{
							required: true,
							errorMessage: '请输入用户名'
						}]
					},
					password: {
						rules: [{
							required: true,
							errorMessage: '请输入密码'
						}]
					},
					captchaAnswer: {
						rules: [{
							required: true,
							errorMessage: '请输入验证码'
						}]
					},
				},
			}
		},
		onLoad(options) {
			if (options.from) {
				this.from = options.from
			}

			var type = "username"
			// #ifdef MP-WEIXIN
			type = "wxMpPhone"
			// #endif
			this.type = type

			this.loadCaptcha()
		},
		methods: {
			loadCaptcha() {
				captcha().then(res => {
					this.formData.captchaId = res.data.id
					this.captchaData = res.data.imageData
				})
			},

			agreeToast() {
				uni.showToast({
					title: '需要同意协议',
					icon: 'none',
					duration: 3000,
				})
			},

			clickLogin() {
				this.$refs.loginForm.validate().then(() => {
					if (!this.isAgree) {
						uni.showToast({
							title: '需要同意协议',
							icon: 'none',
							duration: 3000,
						})
						return
					}

					login(this.formData).then(res => {
						this.loginSuccess(res.data)
					})
				}).catch(err => {

				})
			},

			getPhoneNumber(e) {
				console.log(e)
				if (e.detail.errMsg != 'getPhoneNumber:ok') {
					uni.showToast({
						title: '授权失败',
						icon: 'none',
						duration: 3000,
					})
					return
				}

				var params = {
					code: e.detail.code,
				};

				loginWxMpPhone(params).then(res => {
					this.loginSuccess(res.data)
				})
			},

			loginSuccess(data) {
				useUserStore().setLogin(data)

				loadBadges()

				if (this.from == 'api') {
					uni.switchTab({
						url: '/pages/index/index'
					})
					return
				}

				if (getCurrentPages().length > 1) {
					uni.navigateBack()
				} else {
					uni.switchTab({
						url: '/pages/index/index'
					})
				}
			},

			clickRegister() {
				uni.redirectTo({
					url: '/pages/login/register'
				})
			},

			clickProtocol() {
				this.isAgree = !this.isAgree
			},

			clickService() {
				uni.navigateTo({
					url: '/pages/login/protocol?configKey=userServiceProtocol'
				})
			},

			clickPrivate() {
				uni.navigateTo({
					url: '/pages/login/protocol?configKey=userPrivateProtocol'
				})
			},
		}
	}
</script>

<style lang="scss" scoped>

</style>