<template>
	<view class="flex-column space-pa-20">
		<view class="flex-row-center space-mt-20" v-if="csWxNo">
			<text class="font-main-l" style="width: 200rpx;">微信号</text>
			<text class="font-main-l">{{csWxNo}}</text>
			<uni-icons class="space-ml-10" type="plus" size="46rpx" color="#3a3a3a"
				@click="copyData(csWxNo)"></uni-icons>
		</view>
		<view class="flex-row space-mt-20" v-if="csWxCode">
			<text class="font-main-l" style="width: 200rpx;">微信二维码</text>
			<view class="flex-column">
				<text class="font-main-l">长按识别添加微信</text>
				<image style="width: 400rpx;" :src="csWxCode.url" mode="widthFix" :show-menu-by-longpress="true">
				</image>
			</view>
		</view>
		<view class="flex-row-center space-mt-20" v-if="csPhone">
			<text class="font-main-l" style="width: 200rpx;">手机号</text>
			<text class="font-main-l">{{csPhone}}</text>
			<uni-icons class="space-ml-10" type="phone" size="46rpx" color="#42b883"
				@click="clickPhone(csPhone)"></uni-icons>
		</view>
	</view>
</template>

<script>
	import {
		getConfigs
	} from '@/api/config'
	export default {
		data() {
			return {
				csPhone: '',
				csWxNo: '',
				csWxCode: null,
			};
		},
		onLoad() {
			this.loadData()
		},
		methods: {
			loadData() {
				getConfigs({
					configKeys: 'csPhone,csWxNo,csWxCode'
				}).then(res => {
					res.data.forEach(item => {
						switch (item.configKey) {
							case 'csPhone':
								this.csPhone = item.configValue
								break
							case 'csWxNo':
								this.csWxNo = item.configValue
								break
							case 'csWxCode':
								this.csWxCode = item.image
								break
						}
					})
				})
			},

			copyData(value) {
				uni.setClipboardData({
					data: value,
					success: function() {
						uni.showToast({
							title: '复制成功',
							icon: 'none'
						})
					}
				});
			},

			clickPhone(phone) {
				var that = this
				uni.makePhoneCall({
					phoneNumber: phone,
				});
			},
		}
	}
</script>

<style lang="scss" scoped>

</style>