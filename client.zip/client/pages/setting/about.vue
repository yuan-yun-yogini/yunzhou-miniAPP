<template>
	<view class="container flex-column-center">
		<image style="width: 200rpx;margin-top: 200rpx;border-radius: 20rpx;" src="/static/logo.png" mode="widthFix"></image>
		<text class="font-title-l space-mt-20">云舟</text>
		<view style="height: 0;flex: 1;"></view>
		<text class="font-base">ICP备案号：</text>
		<text class="font-base space-mt-6 space-mb-20">云自在(深圳)文化科技有限公司 版权所有</text>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		height: calc(100vh - var(--window-top));
	}
</style>