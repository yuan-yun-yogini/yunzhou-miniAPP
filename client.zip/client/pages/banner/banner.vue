<template>
	<view class="container">
		<rich-text :nodes="banner.description" v-if="banner"></rich-text>
	</view>
</template>

<script>
	import {
		getBanner
	} from '@/api/banner'
	export default {
		data() {
			return {
				banner: null,
			}
		},
		onLoad(options) {
			this.loadData(options.id)
		},
		methods: {
			loadData(id) {
				getBanner(id).then(res => {
					this.banner = res.data
					
					uni.setNavigationBarTitle({
						title: this.banner.name
					})
				})
			},
		}
	}
</script>

<style lang="scss" scoped>

</style>