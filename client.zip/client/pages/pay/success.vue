<template>
	<view class="flex-column-center">
		<icon style="margin-top: 200rpx;" type="success" size="120rpx" />
		<text class="font-title-l space-mt-20">支付成功</text>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		},
		methods: {
			
		},
	}
</script>

<style lang="scss" scoped>

</style>