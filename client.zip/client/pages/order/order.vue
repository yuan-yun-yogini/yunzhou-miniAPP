<template>
	<view class="flex-column bg-page">
		<view class="flex-column space-pb-10" v-if="list.length > 0">
			<view class="flex-column bg-section space-pa-10 space-mt-10" v-for="(itemOrder, indexOrder) in list"
				:key="itemOrder.id">
				<view class="flex-row-center flex-content-space">
					<text class="font-title color-active">{{getStatusLabel(itemOrder.status)}}</text>
					<text class="font-title"><text
							class="font-base">实付款￥</text>{{$utils.apiMoneyToShow(itemOrder.payAmount)}}</text>
				</view>
				<view class="flex-row space-mt-10" v-for="(itemProduct, indexProduct) in itemOrder.orderProducts"
					:key="itemProduct.id" @click="clickProduct(itemProduct.productId)">
					<image style="width: 160rpx;height: 160rpx;border-radius: 10rpx;"
						:src="itemProduct.productImage.url" mode="aspectFill"></image>
					<view class="flex-column flex-width-fill space-ml-5">
						<view class="flex-row-center space-mt-5">
							<text class="flex-width-fill font-line1 font-title">{{itemProduct.productName}}</text>
							<text class="font-title space-ml-5">￥{{$utils.apiMoneyToShow(itemProduct.price)}}</text>
						</view>
						<view class="flex-row-center space-mt-5">
							<text
								class="flex-width-fill font-line1 font-base">{{itemProduct.productSpecAttrName}}</text>
							<text class="font-base space-ml-5">x{{itemProduct.quantity}}</text>
						</view>
					</view>
				</view>
				<view class="flex-row-center space-mt-10"
					v-for="(itemExpress, indexExpress) in itemOrder.orderExpresses" :key="itemExpress.id"
					v-if="itemOrder.status == 'shipped'">
					<text class="flex-width-fill font-main">{{itemExpress.companyName}}</text>
					<text class="font-main space-ml-5">x{{itemExpress.expressNo}}</text>
					<uni-icons class="space-ml-5" type="plus" size="36rpx" color="#3a3a3a"
						@click="copyData(itemExpress.expressNo)"></uni-icons>
				</view>
				<view class="flex-row-center space-mt-10" style="justify-content: flex-end;">
					<button type="default" size="mini" class="space-ml-10 space-mr-2 space-my-2"
						v-if="statusCancelList.indexOf(itemOrder.status) >= 0"
						@click="clickCancel(indexOrder)">取消支付</button>
					<button type="default" size="mini" class="operate-active space-ml-10 space-mr-2 space-my-2"
						v-if="statusCancelList.indexOf(itemOrder.status) >= 0"
						@click="clickPay(indexOrder)">立即支付</button>

					<button type="default" size="mini" class="space-ml-10 space-mr-2 space-my-2"
						v-if="statusDeleteList.indexOf(itemOrder.status) >= 0 && itemOrder.refundStatus != 'pending' && itemOrder.refundStatus != 'refunding'"
						@click="clickDelete(indexOrder)">删除</button>

					<button type="default" size="mini" class="space-ml-10 space-mr-2 space-my-2"
						v-if="statusEvaluateList.indexOf(itemOrder.status) >= 0 && itemOrder.refundStatus == ''"
						@click="clickEvaluate(indexOrder)">{{itemOrder.evaluateStatus == 'evaluated' ? '追评' : '评价'}}</button>

					<button type="default" size="mini" class="operate-active space-ml-10 space-mr-2 space-my-2"
						v-if="itemOrder.refundStatus != ''" @click="clickRefund(indexOrder)">售后</button>
					<button type="default" size="mini" class="space-ml-10 space-mr-2 space-my-2"
						v-else-if="statusRefundList.indexOf(itemOrder.status) >= 0"
						@click="clickRefund(indexOrder)">售后</button>

					<button type="default" size="mini" class="operate-active space-ml-10 space-mr-2 space-my-2"
						v-if="statusDeliverList.indexOf(itemOrder.status) >= 0"
						@click="clickDeliver(indexOrder)">确认收货</button>

					<button type="default" size="mini" class="operate-active space-ml-10 space-mr-2 space-my-2"
						v-if="statusCartList.indexOf(itemOrder.status) >= 0 && itemOrder.refundStatus == ''"
						@click="clickCart(indexOrder)">加入购物车</button>
				</view>
			</view>
		</view>
		<data-empty v-else></data-empty>
	</view>
</template>

<script>
	import {
		setBadges
	} from '@/utils/badge'
	import {
		getOrders,
		updateOrder,
		deleteOrder,
	} from '@/api/order'
	import {
		createPayOrder,
	} from '@/api/settle'
	import {
		createCart
	} from '@/api/cart'
	export default {
		data() {
			return {
				list: [],
				loading: false,
				loaded: false,
				loadingType: 'nomore',
				statusInfo: {
					name: '全部订单',
					status: '',
				},
				statusList: [{
					name: '待支付',
					status: 'pending',
				}, {
					name: '待发货',
					status: 'paid',
				}, {
					name: '待收货',
					status: 'shipped',
				}, {
					name: '待评价',
					status: 'evaluate',
				}, {
					name: '退款/售后',
					status: 'refund',
				}],
				statusShowList: [{
					label: '待支付',
					value: 'pending',
				}, {
					label: '待发货',
					value: 'paid',
				}, {
					label: '待收货',
					value: 'shipped',
				}, {
					label: '已收货',
					value: 'delivered',
				}, {
					label: '交易完成',
					value: 'completed',
				}],
				statusCancelList: ['pending'],
				statusDeleteList: ['delivered', 'completed'],
				statusRefundList: ['paid', 'shipped', 'delivered'],
				statusEvaluateList: ['delivered', 'completed'],
				statusDeliverList: ['shipped'],
				statusCartList: ['delivered', 'completed'],
				payChannel: '',
				openId: '',
			};
		},
		onLoad(options) {
			// #ifdef MP-WEIXIN
			this.payChannel = 'wxMp'
			this.loadWxMpOpenId()
			// #endif
			// #ifdef WEB
			// var agent = navigator.userAgent.toLowerCase()
			// if (agent.match(/MicroMessenger/i) == 'micromessenger') {
			// 	this.payChannel = 'wxJsapi'
			// } else {
			// 	this.payChannel = 'wxH5'
			// }
			this.payChannel = 'wxH5'
			// #endif
			
			if (options.status) {
				for (var i = 0; i < this.statusList.length; i++) {
					if (this.statusList[i].status == options.status) {
						this.statusInfo = this.statusList[i]
						break
					}
				}
			}

			uni.setNavigationBarTitle({
				title: this.statusInfo.name
			})

			this.loadData('refresh')
		},
		onReachBottom() {
			if (this.loadingType == 'more') {
				this.loadData('more')
			}
		},
		methods: {
			loadData(source) {
				var params = {
					offset: 0,
					limit: 10,
					apiStatus: this.statusInfo.status,
				}

				if (source == 'more') {
					params.offset = this.list.length
					this.loadingType = 'loading'
				} else {
					this.loadingType = 'nomore'
				}

				if (this.loading) {
					return
				}

				this.loading = true

				getOrders(params).then(res => {
					var list = res.data

					if (source == 'more') {
						this.list = this.list.concat(list)
					} else {
						this.list = list
					}

					this.loadingType = res.data.length < params.limit ? 'nomore' : 'more'

					this.loading = false
					this.loaded = true
				}).catch(() => {
					this.loading = false
				})
			},
			
			loadWxMpOpenId() {
				var that = this
				var openId = uni.getStorageSync('openId')
				console.log('openId', openId)
				if (openId) {
					this.openId = openId
				} else {
					uni.login({
						provider: 'weixin',
						success: function(loginRes) {
							createWxMpOpenId({
								code: loginRes.code
							}).then(res => {
								that.openId = res.data.openId
								uni.setStorageSync('openId', res.data.openId)
							})
						}
					});
				}
			},

			getStatusLabel(value) {
				for (var i = 0; i < this.statusShowList.length; i++) {
					if (this.statusShowList[i].value == value) {
						return this.statusShowList[i].label
					}
				}

				return ''
			},

			copyData(value) {
				uni.setClipboardData({
					data: value,
					success: function() {
						uni.showToast({
							title: '复制成功',
							icon: 'none',
							duration: 3000,
						})
					}
				});
			},
			
			clickPay(index) {
				if (!this.openId) {
					uni.showToast({
						title: '获取openid失败',
						icon: 'none',
						duration: 3000,
					})
					return
				}
				
				if (!this.payChannel) {
					uni.showToast({
						title: '没有支持的支付方式',
						icon: 'none',
						duration: 3000,
					})
					return
				}
				
				uni.showLoading({
					title: '加载中...'
				})
				
				var params = {
					orderId: this.list[index].id,
					payChannel: this.payChannel,
					openId: this.openId,
				}
				createPayOrder(params).then(res => {
					if (res.data) {
						this.pay(res.data)
					} else {
						uni.hideLoading()
						this.payLoading = false
				
						uni.redirectTo({
							url: '/pages/pay/success'
						})
					}
				}).catch(err => {
					uni.hideLoading()
					this.payLoading = false
				})
			},
			
			pay(payInfo) {
				if (this.payChannel == 'wxH5') {
					uni.hideLoading()
					this.payLoading = false
			
					window.location.replace(payInfo.url);
				} else if (this.payChannel == 'wxJsapi') {
					uni.hideLoading()
					this.payLoading = false
			
					uni.showToast({
						title: '暂未支持',
						icon: 'none',
						duration: 3000,
					})
				} else if (this.payChannel == 'wxMp') {
					var that = this
					uni.requestPayment({
						provider: 'wxpay',
						timeStamp: payInfo.timeStamp,
						nonceStr: payInfo.nonceStr,
						package: payInfo.package,
						signType: payInfo.signType,
						paySign: payInfo.paySign,
						success: (res) => {
							uni.hideLoading()
							that.payLoading = false
			
							uni.redirectTo({
								url: '/pages/pay/success'
							})
						},
						fail: (res) => {
							uni.hideLoading()
							that.payLoading = false
						},
					})
				}
			},

			clickCancel(index) {
				var that = this
				uni.showModal({
					title: '提示',
					content: '确定取消支付吗？',
					success: function(res) {
						if (res.confirm) {
							updateOrder(that.list[index].id, {
								status: 'canceled'
							}).then(res => {
								uni.showToast({
									title: '取消成功',
									icon: 'none',
									duration: 3000,
								})
								that.list.splice(index, 1)
							})
						}
					}
				});
			},

			clickDelete(index) {
				var that = this
				uni.showModal({
					title: '提示',
					content: '确定删除吗？',
					success: function(res) {
						if (res.confirm) {
							deleteOrder(that.list[index].id).then(res => {
								uni.showToast({
									title: '删除成功',
									icon: 'none',
									duration: 3000,
								})
								that.list.splice(index, 1)
							})
						}
					}
				});
			},

			clickRefund(index) {
				uni.navigateTo({
					url: '/pages/order/refund?id=' + this.list[index].id
				})
			},

			clickEvaluate(index) {
				uni.navigateTo({
					url: '/pages/order/evaluate?id=' + this.list[index].id
				})
			},

			clickDeliver(index) {
				var that = this
				uni.showModal({
					title: '提示',
					content: '确定收货吗？',
					success: function(res) {
						if (res.confirm) {
							updateOrder(that.list[index].id, {
								status: 'delivered'
							}).then(res => {
								uni.showToast({
									title: '收货成功',
									icon: 'none',
									duration: 3000,
								})
								that.list[index] = res.data
							})
						}
					}
				});
			},

			clickCart(index) {
				var order = this.list[index]
				var params = []

				order.orderProducts.forEach(item => {
					var param = {
						productId: item.productId,
						quantity: item.quantity,
					}

					if (item.productSpecAttrId) {
						param.productSpecAttrId = item.productSpecAttrId
					}
					params.push(param)
				})

				createCart(params).then(res => {
					uni.showToast({
						title: '加入购物车成功',
						icon: 'none',
						duration: 3000,
					})

					setBadges({
						cartCount: res.data.totalCount
					})
				})
			},

			clickProduct(productId) {
				uni.navigateTo({
					url: '/pages/product/detail?id=' + productId
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-bg-color;
	}

	.operate-active {
		background-color: #fff6f1;
		color: $color-active;
	}
</style>