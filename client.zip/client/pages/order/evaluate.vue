<template>
	<view class="flex-column bg-page" style="padding-bottom: 140rpx;">
		<view class="flex-column bg-section space-mt-10 space-pa-10"
			v-for="(itemProduct, indexProduct) in order.orderProducts" :key="itemProduct.id" v-if="order">
			<view class="flex-row" @click="clickProduct(itemProduct.productId)">
				<image style="width: 160rpx;height: 160rpx;border-radius: 10rpx;" :src="itemProduct.productImage.url"
					mode="aspectFill"></image>
				<view class="flex-column flex-width-fill space-ml-5">
					<view class="flex-row-center space-mt-5">
						<text class="flex-width-fill font-line1 font-title">{{itemProduct.productName}}</text>
						<text class="font-title space-ml-5">￥{{$utils.apiMoneyToShow(itemProduct.price)}}</text>
					</view>
					<view class="flex-row-center space-mt-5">
						<text class="flex-width-fill font-line1 font-base">{{itemProduct.productSpecAttrName}}</text>
						<text class="font-base space-ml-5">x{{itemProduct.quantity}}</text>
					</view>
				</view>
			</view>

			<view class="flex-column" v-if="itemProduct.evaluate.status != ''">
				<view class="flex-row-center space-mt-20">
					<text class="font-title-s space-mr-10">评分：</text>
					<uni-rate v-model="itemProduct.evaluate.score"
						:readonly="itemProduct.evaluate.status == 'append'" />
				</view>
				<text class="font-main space-mt-10">{{itemProduct.evaluate.content}}</text>
				<view class="flex-row space-mt-10" style="flex-wrap: wrap;gap: 20rpx"
					v-if="itemProduct.evaluate.images && itemProduct.evaluate.images.length > 0">
					<image style="width: 200rpx;height: 200rpx;" :src="itemImage.url" mode="aspectFill"
						v-for="(itemImage, indexImage) in itemProduct.evaluate.images" :key="itemImage.id"
						@click="clickEvaluateImage(indexProduct, indexImage, false)"></image>
				</view>
				<text class="font-title-s space-mt-10">追加评价：</text>
				<view class="flex-column space-ml-20" v-if="itemProduct.evaluate.status == 'append'">
					<text class="font-main space-mt-10">{{itemProduct.evaluate.appendContent}}</text>
					<view class="flex-row space-mt-10" style="flex-wrap: wrap;gap: 20rpx"
						v-if="itemProduct.evaluate.appendImages && itemProduct.evaluate.appendImages.length > 0">
						<image style="width: 200rpx;height: 200rpx;" :src="itemImage.url" mode="aspectFill"
							v-for="(itemImage, indexImage) in itemProduct.evaluate.appendImages" :key="itemImage.id"
							@click="clickEvaluateImage(indexProduct, indexImage, true)"></image>
					</view>
				</view>
				<view class="flex-column space-ml-20" v-else>
					<uni-easyinput class="space-mt-10" type="textarea" maxlength="255"
						v-model="itemProduct.evaluate.appendContent" placeholder="请输入追评内容" />
					<uni-file-picker :ref="'imageRef' + indexProduct" class="space-mt-10" limit="6" title="最多选择6张图片"
						:auto-upload="false" :imageStyles="imageStyles" :sizeType="['compressed']"
						file-mediatype="image" file-extname="png,jpg,jpeg" v-model="itemProduct.evaluate.imageFileList"
						@select="($value) => {selectImage(indexProduct, $value)}"
						@delete="($value) => {deleteImage(indexProduct, $value)}"></uni-file-picker>
				</view>
			</view>
			<view class="flex-column" v-else-if="order.evaluateStatus == ''">
				<view class="flex-row-center space-mt-20">
					<text class="font-title-s space-mr-10">评分：</text>
					<uni-rate v-model="itemProduct.evaluate.score" />
				</view>
				<uni-easyinput class="space-mt-10" type="textarea" maxlength="255"
					v-model="itemProduct.evaluate.content" placeholder="请输入评价内容" />
				<uni-file-picker :ref="'imageRef' + indexProduct" class="space-mt-10" limit="6" title="最多选择6张图片"
					:auto-upload="false" :imageStyles="imageStyles" :sizeType="['compressed']" file-mediatype="image"
					file-extname="png,jpg,jpeg" v-model="itemProduct.evaluate.imageFileList"
					@select="($value) => {selectImage(indexProduct, $value)}"
					@delete="($value) => {deleteImage(indexProduct, $value)}"></uni-file-picker>
			</view>

			<view class="flex-row-center bg-section space-px-10"
				style="position: fixed;left: 0;bottom: 0;right: 0;height: 120rpx;"
				v-if="order.evaluateStatus != 'append'">
				<button size="default" type="primary" class="flex-width-fill" style="height: 80rpx;line-height: 80rpx;"
					@click="clickApply">提交评价</button>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		getOrder,
		createOrderEvaluate,
	} from '@/api/order'
	import {
		uploadImagesList,
	} from '@/api/image'
	export default {
		data() {
			return {
				orderId: 0,
				order: null,
				imageStyles: {
					width: '160rpx',
					height: '160rpx',
				},
			};
		},
		onLoad(options) {
			this.orderId = options.id

			this.loadData()
		},
		methods: {
			loadData() {
				getOrder(this.orderId).then(res => {
					var order = res.data

					order.orderProducts.forEach(item => {
						if (!item.evaluate) {
							item.evaluate = {
								id: 0,
								score: 5,
								content: '',
								images: [],
								status: '',
							}
						}

						item.evaluate.imagePathList = []
						item.evaluate.imageFileList = []
					})

					this.order = order
				})
			},

			selectImage(indexProduct, e) {
				var evaluate = this.order.orderProducts[indexProduct].evaluate
				var startIndex = evaluate.imagePathList.length
				var deleteIndexList = []

				for (var i = e.tempFiles.length - 1; i >= 0; i--) {
					if (e.tempFiles[i].size > 2 * 1024 * 1024) {
						deleteIndexList.push(startIndex + i)
					} else {
						evaluate.imagePathList.push(e.tempFiles[i].path)
					}
				}

				if (deleteIndexList.length > 0) {
					uni.showToast({
						title: '图片大小不能超过2M',
						icon: 'none',
						duration: 3000,
					})

					deleteIndexList.forEach(item => {
						this.$refs['imageRef' + indexProduct][0].clearFiles(item)
					})
				}
			},

			deleteImage(indexProduct, e) {
				var evaluate = this.order.orderProducts[indexProduct].evaluate
				evaluate.imagePathList.splice(e.index, 1)
			},

			clickApply() {
				uni.showLoading({
					title: "加载中"
				})

				var pathsList = []
				this.order.orderProducts.forEach(item => {
					var list = []
					item.evaluate.imagePathList.forEach(path => {
						list.push(path)
					})
					pathsList.push(list)
				})

				uploadImagesList(pathsList).then(imagesList => {
					var params = {
						orderId: this.order.id,
						evaluates: [],
					}

					this.order.orderProducts.forEach((item, index) => {
						var evaluate = {
							orderProductId: item.id,
							imageIds: [],
						}

						if (item.evaluate.status == '') {
							evaluate.score = item.evaluate.score
							evaluate.content = item.evaluate.content
						} else {
							evaluate.score = item.evaluate.score
							evaluate.content = item.evaluate.appendContent
						}

						imagesList[index].forEach(image => {
							evaluate.imageIds.push(image.id)
						})

						params.evaluates.push(evaluate)
					})

					createOrderEvaluate(params).then(res => {
						uni.hideLoading()
						uni.showToast({
							title: '评价成功',
							icon: 'none',
							duration: 3000,
						})

						this.loadData()
					}).catch(err => {
						uni.hideLoading()
					})
				}).catch(() => {
					uni.hideLoading()
					uni.showToast({
						title: '图片上传失败',
						icon: 'none',
						duration: 3000,
					})
				})
			},

			clickEvaluateImage(indexProduct, indexImage, isAppend) {
				var evaluate = this.order.orderProducts[indexProduct].evaluate
				var urlList = []

				if (isAppend) {
					evaluate.appendImages.forEach(item => {
						urlList.push(item.url)
					})
				} else {
					evaluate.images.forEach(item => {
						urlList.push(item.url)
					})
				}

				uni.previewImage({
					urls: urlList,
					current: indexImage,
				})
			},

			clickProduct(productId) {
				uni.navigateTo({
					url: '/pages/product/detail?id=' + productId
				})
			},
		},
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-bg-color;
	}
</style>