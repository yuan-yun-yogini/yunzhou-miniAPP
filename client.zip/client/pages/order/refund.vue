<template>
	<view class="flex-column bg-page">
		<view class="bg-section space-mt-10 space-pa-10" v-if="order && order.refundStatus == ''">
			<uni-forms ref="refundForm" :modelValue="formData" :rules="rules">
				<uni-forms-item label="订单金额">
					<view class="flex-row-center" style="height: 100%;">
						<text class="font-title">￥{{$utils.apiMoneyToShow(order.payAmount)}}</text>
					</view>
				</uni-forms-item>
				<uni-forms-item label="退款金额" name="amount">
					<uni-easyinput type="digit" v-model="formData.amount" placeholder="请输入退款金额" />
				</uni-forms-item>
				<uni-forms-item label="退款原因" name="reason">
					<uni-easyinput type="textarea" maxlength="255" v-model="formData.reason" placeholder="请输入退款原因" />
				</uni-forms-item>
				<uni-forms-item label="上传图片" name="refundReason">
					<uni-file-picker ref="imageRef" limit="6" title="最多选择6张图片" :auto-upload="false"
						:imageStyles="imageStyles" :sizeType="['compressed']" file-mediatype="image"
						file-extname="png,jpg,jpeg" v-model="imageFileList" @select="selectImage"
						@delete="deleteImage"></uni-file-picker>
				</uni-forms-item>
			</uni-forms>
			<view class="flex-row-center space-mt-20">
				<button type="primary" @click="clickApply">申请退款</button>
			</view>
		</view>
		<view class="flex-column bg-section space-mt-10 space-pa-10"
			v-if="order && order.orderRefund && order.orderRefund.status != 'pending'">
			<text class="font-title color-active">{{getStatusLabel(order.orderRefund.status)}}</text>
			<text class="font-main space-mt-10">{{order.orderRefund.replyContent}}</text>
		</view>
		<view class="flex-column bg-section space-mt-10 space-pa-10" v-if="order && order.orderRefund">
			<view class="flex-row-center flex-content-space">
				<text class="font-title" :class="{'color-active': order.orderRefund.status == 'pending'}">申请退款</text>
				<text class="font-title"><text
						class="font-base">退款金额￥</text>{{$utils.apiMoneyToShow(order.orderRefund.amount)}}</text>
			</view>
			<text class="font-main space-mt-10">{{order.orderRefund.reason}}</text>
			<view class="flex-row space-mt-10" style="flex-wrap: wrap;gap: 20rpx"
				v-if="order.orderRefund.images && order.orderRefund.images.length > 0">
				<image style="width: 200rpx;height: 200rpx;" :src="item.url" mode="aspectFill"
					v-for="(item, index) in order.orderRefund.images" :key="item.id" @click="clickRefundImage(index)">
				</image>
			</view>
			<button type="primary" @click="clickCancel" v-if="order.orderRefund.status == 'pending'">取消退款</button>
		</view>
	</view>
</template>

<script>
	import {
		getOrder,
		createOrderRefund,
		deleteOrderRefund,
	} from '@/api/order'
	import {
		uploadImagesList,
	} from '@/api/image'
	export default {
		data() {
			return {
				orderId: 0,
				order: null,
				formData: {},
				imageFileList: [],
				imagePathList: [],
				imageStyles: {
					width: '160rpx',
					height: '160rpx',
				},
				rules: {
					amount: {
						rules: [{
							required: true,
							errorMessage: '请输入退款金额'
						}]
					},
					reason: {
						rules: [{
							required: true,
							errorMessage: '请输入退款原因'
						}]
					},
				},
				statusShowList: [{
					label: '申请退款',
					value: 'pending'
				}, {
					label: '拒绝退款',
					value: 'reject'
				}, {
					label: '退款中',
					value: 'refunding'
				}, {
					label: '已退款',
					value: 'success'
				}, {
					label: '退款失败',
					value: 'fail'
				}],
			};
		},
		onLoad(options) {
			this.orderId = options.id

			this.loadData()
		},
		methods: {
			loadData() {
				this.imageFileList = []
				this.imagePathList = []

				getOrder(this.orderId).then(res => {
					this.order = res.data
				})
			},

			selectImage(e) {
				var startIndex = this.imagePathList.length
				var deleteIndexList = []

				for (var i = e.tempFiles.length - 1; i >= 0; i--) {
					if (e.tempFiles[i].size > 2 * 1024 * 1024) {
						deleteIndexList.push(startIndex + i)
					} else {
						this.imagePathList.push(e.tempFiles[i].path)
					}
				}

				if (deleteIndexList.length > 0) {
					uni.showToast({
						title: '图片大小不能超过2M',
						icon: 'none',
						duration: 3000,
					})

					deleteIndexList.forEach(item => {
						this.$refs.imageRef.clearFiles(item)
					})
				}
			},

			deleteImage(e) {
				this.imagePathList.splice(e.index, 1)
			},

			clickApply() {
				this.$refs.refundForm.validate().then(() => {
					var amount = this.$utils.inputMoneyToApi(this.formData.amount)
					if (amount <= 0) {
						uni.showToast({
							title: '请输入正确的退款金额',
							icon: 'none',
							duration: 3000,
						})
						return
					}
					if (amount > this.order.payAmount) {
						uni.showToast({
							title: '退款金额不能超过订单金额',
							icon: 'none',
							duration: 3000,
						})
						return
					}

					uni.showLoading({
						title: "加载中"
					})

					var pathsList = []
					var pathList = []
					this.imagePathList.forEach(path => {
						pathList.push(path)
					})
					pathsList.push(pathList)

					uploadImagesList(pathsList).then(imagesList => {
						var params = {
							orderId: this.order.id,
							amount: amount,
							reason: this.formData.reason,
							imageIds: [],
						}

						imagesList[0].forEach(item => {
							params.imageIds.push(item.id)
						})

						createOrderRefund(params).then(res => {
							uni.hideLoading()
							uni.showToast({
								title: '申请成功，等待客服处理',
								icon: 'none',
								duration: 3000,
							})

							this.loadData()
						}).catch(err => {
							uni.hideLoading()
						})
					}).catch(err => {
						uni.hideLoading()
						uni.showToast({
							title: '图片上传失败',
							icon: 'none',
							duration: 3000,
						})
						return
					})
				}).catch(err => {

				})
			},

			clickCancel() {
				var that = this
				uni.showModal({
					title: '提示',
					content: '确定删除吗？',
					success: function(res) {
						if (res.confirm) {
							deleteOrderRefund(that.order.orderRefund.id).then(res => {
								uni.showToast({
									title: '取消成功',
									icon: 'none',
									duration: 3000,
								})

								that.loadData()
							})
						}
					}
				});
			},

			getStatusLabel(value) {
				for (var i = 0; i < this.statusShowList.length; i++) {
					if (this.statusShowList[i].value == value) {
						return this.statusShowList[i].label
					}
				}

				return ''
			},

			clickRefundImage(index) {
				var urlList = []
				this.order.orderRefund.images.forEach(item => {
					urlList.push(item.url)
				})
				uni.previewImage({
					urls: urlList,
					current: index,
				})
			},
		},
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-bg-color;
	}
</style>