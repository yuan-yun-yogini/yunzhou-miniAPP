<template>
	<view class="flex-column bg-page" style="padding-bottom: 140rpx;">
		<view class="flex-row-center bg-section space-mt-10 space-mx-10 space-pa-10 uni-radius-lg"
			:class="{'address-active': selectId == item.id}" v-for="(item, index) in list" :key="item.id">
			<view class="flex-column flex-width-fill" @click="clickItem(index)">
				<text class="font-secondary">{{item.province}} {{item.city}} {{item.district}}</text>
				<text class="font-title space-mt-3">{{item.detail}}</text>
				<text class="font-base space-mt-3">{{item.name}} {{item.phone}}<text class="color-active space-ml-10"
						v-if="item.isDefault">默认</text></text>
			</view>
			<uni-icons class="space-ml-10" type="compose" size="48rpx" color="#3a3a3a" @click="editItem(index)"
				v-if="isSelect"></uni-icons>
			<uni-icons class="space-ml-10" type="trash" size="48rpx" color="#e64340" @click="deleteItem(index)"
				v-if="!isSelect"></uni-icons>
		</view>
		<view class="flex-row-center bg-section space-px-10"
			style="position: fixed;left: 0;bottom: 0;right: 0;height: 120rpx;">
			<button size="default" type="primary" class="flex-width-fill" style="height: 80rpx;line-height: 80rpx;"
				@click="clickAdd">增加</button>
		</view>
	</view>
</template>

<script>
	import {
		getAddresses,
		deleteAddress,
	} from '@/api/address'
	export default {
		data() {
			return {
				list: [],
				isSelect: false,
				selectId: 0,
				selectEventChannel: null,
			}
		},
		onLoad(options) {
			if (options.isSelect) {
				this.isSelect = true
				this.selectId = options.selectId
			}
			
			this.selectEventChannel = this.getOpenerEventChannel();
		},
		onShow() {
			this.loadData()
		},
		methods: {
			loadData() {
				getAddresses().then(res => {
					this.list = res.data
				})
			},

			clickItem(index) {
				var item = this.list[index]

				if (this.isSelect) {
					this.selectEventChannel.emit('acceptDataFromOpenedPage', item);
					uni.navigateBack()
				} else {
					uni.navigateTo({
						url: '/pages/my/address-edit?id=' + item.id
					})
				}
			},

			clickAdd() {
				uni.navigateTo({
					url: '/pages/my/address-edit'
				})
			},

			editItem(index) {
				uni.navigateTo({
					url: '/pages/my/address-edit?id=' + this.list[index].id
				})
			},

			deleteItem(index) {
				var that = this
				uni.showModal({
					title: '提示',
					content: '确定删除吗？',
					success: function(res) {
						if (res.confirm) {
							deleteAddress(that.list[index].id).then(res => {
								that.loadData()
							})
						}
					}
				});
			},
		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-bg-color;
	}

	.address-active {
		background-color: #fff6f1 !important;
		border: 1rpx solid $color-active;
	}
</style>