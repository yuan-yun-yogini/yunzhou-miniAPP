<template>
	<view class="flex-column bg-page">
		<view class="flex-column bg-section">
			<view class="sep-line-x"></view>
			<view class="item">
				<text class="font-main-l flex-width-fill">头像</text>
				<view class="flex-column space-ml-10" style="width: 60rpx;height: 60rpx;">
					<uni-file-picker limit="1" :del-icon="false" disable-preview :auto-upload="false"
						:imageStyles="avatarStyles" :sizeType="['compressed']" return-type="object"
						file-mediatype="image" file-extname="png,jpg,jpeg" v-model="avatarFile"
						@select="uploadAvatar"></uni-file-picker>
				</view>
				<uni-icons class="space-ml-10" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
			</view>
			<view class="sep-line-x"></view>
			<view class="item" @click="clickName">
				<text class="font-main-l flex-width-fill">名称</text>
				<text class="font-base-l space-ml-10">{{user.name}}</text>
				<uni-icons class="space-ml-10" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
			</view>
			<view class="sep-line-x"></view>
			<template v-if="env != 'wxMp'">
				<view class="item" @click="clickPhone">
					<text class="font-main-l flex-width-fill">手机号</text>
					<text class="font-base-l space-ml-10">{{user.phone}}</text>
					<uni-icons class="space-ml-10" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
				</view>
				<view class="sep-line-x"></view>
				<view class="item" @click="clickPassword">
					<text class="font-main-l flex-width-fill">密码</text>
					<uni-icons class="space-ml-10" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
				</view>
				<view class="sep-line-x"></view>
			</template>
		</view>
		<button class="space-my-20" type="default" @click="clickLogout">退出登录</button>

		<uni-popup ref="inputDialog" type="dialog">
			<uni-popup-dialog mode="input" :title="update.title" v-model="update.value" placeholder="请输入内容"
				@confirm="dialogInputConfirm"></uni-popup-dialog>
		</uni-popup>
	</view>
</template>

<script>
	import {
		useUserStore
	} from '@/store/user'
	import {
		resetBadges
	} from '@/utils/badge'
	import {
		updateMy
	} from '@/api/user'
	import {
		uploadImageUrl,
		uploadImageHeader
	} from '@/api/image'
	export default {
		data() {
			return {
				env: '',
				user: null,
				update: {
					type: '',
					title: '',
					value: '',
				},
				avatarFile: null,
				avatarStyles: {
					width: '80rpx',
					height: '80rpx',
					border: {
						radius: '50%'
					}
				},
			};
		},
		onLoad() {
			// #ifdef MP-WEIXIN
			this.env = "wxMp"
			// #endif
		},
		onShow() {
			this.user = useUserStore().getUser()
			if (this.user.avatar) {
				this.avatarFile = {
					url: this.user.avatar.url,
				}
			}
		},
		methods: {
			clickLogout() {
				useUserStore().setLogin(null)
				resetBadges()
				uni.switchTab({
					url: '/pages/index/index'
				})
			},

			uploadAvatar(e) {
				const filePath = e.tempFilePaths[0];

				if (e.tempFiles[0].size > 2 * 1024 * 1024) {
					uni.showToast({
						title: '图片大小不能超过2M',
						icon: 'none',
						duration: 3000,
					})
					return
				}

				//获取图片临时路径
				uni.uploadFile({
					url: uploadImageUrl, //【必填】图片上传地址
					filePath: filePath, //【必填】（files和filePath选其一）要上传文件资源的路径。
					name: 'file', //【必填】上传名字，注意与后台接收的参数名一致
					header: uploadImageHeader(), //设置请求头
					//请求成功，后台返回自己服务器上的图片地址
					success: res => {
						var resData = JSON.parse(res.data)

						updateMy({
							avatarId: resData.data.id
						}).then(res1 => {
							this.user.avatar = resData.data
							useUserStore().setUser(this.user)

							this.avatarFile = {
								url: this.user.avatar.url,
							}
						})
					},
					fail: () => {
						uni.showToast({
							title: '图片上传失败',
							icon: 'none',
							duration: 3000,
						})
					},
				});
			},

			clickName() {
				this.update = {
					type: 'name',
					title: '名称',
					value: this.user.name,
				}
				this.$refs.inputDialog.open()
			},

			clickPhone() {
				this.update = {
					type: 'phone',
					title: '手机号',
					value: this.user.phone,
				}
				this.$refs.inputDialog.open()
			},

			dialogInputConfirm(val) {
				if (this.update.type == 'name') {
					updateMy({
						name: val
					}).then(res => {
						this.$refs.inputDialog.close()
						this.user.name = val
						useUserStore().setUser(this.user)
					})
				} else if (this.update.type == 'phone') {
					var phonePattern = /^1[3-9]\d{9}$/;
					if (!phonePattern.test(val)) {
						uni.showToast({
							title: '手机号格式错误',
							icon: 'none',
							duration: 3000,
						})
						return
					}

					updateMy({
						phone: val
					}).then(res => {
						this.$refs.inputDialog.close()
						this.user.phone = val

						useUserStore().setUser(this.user)
					})
				}
			},

			clickPassword() {
				uni.navigateTo({
					url: '/pages/my/password'
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-bg-color;
	}

	.item {
		height: 100rpx;
		padding: 0 20rpx;
		display: flex;
		flex-direction: row;
		align-items: center;
	}

	// :deep(.uni-file-picker__container) {
	// 	margin: 0;
	// }

	// :deep(.file-picker__box-content) {
	// 	margin: 0;
	// }
</style>