<template>
	<view class="flex-column-center">
		<view class="space-mt-20" style="width: 600rpx;">
			<uni-forms ref="loginForm" :modelValue="formData" :rules="rules">
				<uni-forms-item label="旧密码" name="oldPassword">
					<uni-easyinput type="password" v-model="formData.oldPassword" placeholder="请输入旧密码" />
				</uni-forms-item>
				<uni-forms-item label="新密码" name="password">
					<uni-easyinput type="password" v-model="formData.password" placeholder="请输入新密码" />
				</uni-forms-item>
				<uni-forms-item label="确认密码" name="password1">
					<uni-easyinput type="password" v-model="formData.password1" placeholder="请输入确认密码" />
				</uni-forms-item>
			</uni-forms>
		</view>
		<view class="flex-row-center space-mt-20">
			<button type="primary" @click="clickConfirm">确定</button>
		</view>
	</view>
</template>

<script>
	import {
		useUserStore
	} from '@/store/user'
	import {
		resetBadges
	} from '@/utils/badge'
	import {
		updateMy
	} from '@/api/user'
	export default {
		data() {
			return {
				formData: {

				},
				rules: {
					oldPassword: {
						rules: [{
							required: true,
							errorMessage: '请输入旧密码'
						}]
					},
					password: {
						rules: [{
							required: true,
							errorMessage: '请输入新密码'
						}, {
							minLength: 6,
							errorMessage: '密码长度至少6位'
						}]
					},
					password1: {
						rules: [{
							required: true,
							errorMessage: '请输入确认密码'
						}]
					},
				},
			}
		},
		onLoad() {

		},
		methods: {
			clickConfirm() {
				this.$refs.loginForm.validate().then(() => {
					if (this.formData.password != this.formData.password1) {
						uni.showToast({
							title: '确认密码不一致',
							icon: 'none',
							duration: 3000,
						})
						return
					}

					updateMy({
						oldPassword: this.formData.oldPassword,
						password: this.formData.password,
					}).then(res => {
						uni.showToast({
							title: '修改成功，请重新登录',
							icon: 'none',
							duration: 3000,
						})

						useUserStore().setLogin(null)
						resetBadges()

						uni.reLaunch({
							url: '/pages/login/login'
						})
					})
				}).catch(err => {

				})
			},

			clickLogin() {
				uni.redirectTo({
					url: '/pages/login/login'
				})
			},

			clickProtocol() {
				this.isAgree = !this.isAgree
			},

			clickService() {
				uni.navigateTo({
					url: '/pages/login/protocol?configKey=userServiceProtocol'
				})
			},

			clickPrivate() {
				uni.navigateTo({
					url: '/pages/login/protocol?configKey=userPrivateProtocol'
				})
			},
		}
	}
</script>

<style lang="scss" scoped>

</style>