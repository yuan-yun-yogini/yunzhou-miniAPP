<template>
	<view class="flex-column bg-page">
		<view :style="{height: navBarInfo.statusBarHeight + 'px'}" v-if="navBarInfo"></view>
		<view class="flex-row-center space-ma-20">
			<image style="width: 80rpx;height: 80rpx;border-radius: 50%;"
				:src="user && user.avatar ? user.avatar.url : '/static/avatar.png'" mode="aspectFill"
				@click="clickUser"></image>
			<text class="font-main-l space-ml-10"
				@click="clickUser">{{ user ? (user.name ? user.name : '用户' + user.id) : '点击登录' }}</text>
		</view>
		<view class="flex-column bg-section space-mx-10 space-pa-10 uni-radius-lg">
			<view class="flex-row-center">
				<text class="flex-width-fill font-title">我的订单</text>
				<text class="font-base" @click="clickOrder">查看全部</text>
				<uni-icons class="space-ml-5" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
			</view>
			<uni-grid class="space-mt-10" :column="5" :highlight="true" :showBorder="false" :square="false"
				@change="clickOrderStatus">
				<uni-grid-item v-for="(item, index) in orderStatusList" :key="item.id" :index="index">
					<view class="flex-column-center space-py-10">
						<uni-badge :text="item.badge" absolute="rightTop" size="small">
							<uni-icons class="space-ml-5" :type="item.icon" size="56rpx" color="#6a6a6a"></uni-icons>
						</uni-badge>
						<text class="font-main space-mt-8">{{item.name}}</text>
					</view>
				</uni-grid-item>
			</uni-grid>
		</view>
		<view class="flex-column bg-section space-mt-10 space-mx-10 uni-radius-lg">
			<view class="item" @click="clickAddress">
				<text class="font-main-l flex-width-fill">收货地址</text>
				<text class="font-base-l space-ml-10"></text>
				<uni-icons class="space-ml-10" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
			</view>
			<view class="sep-line-x"></view>
			<view class="item" @click="clickResource">
				<text class="font-main-l flex-width-fill">数字产品</text>
				<text class="font-base-l space-ml-10"></text>
				<uni-icons class="space-ml-10" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
			</view>
			<view class="sep-line-x"></view>
			<view class="item" @click="clickCustomerService">
				<text class="font-main-l flex-width-fill">联系客服</text>
				<text class="font-base-l space-ml-10"></text>
				<uni-icons class="space-ml-10" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
			</view>
			<view class="sep-line-x"></view>
			<view class="item" @click="clickAbout">
				<text class="font-main-l flex-width-fill">关于我们</text>
				<text class="font-base-l space-ml-10"></text>
				<uni-icons class="space-ml-10" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		useUserStore
	} from '@/store/user'
	import {
		showBadges,
		setBadges,
		getBadges
	} from '@/utils/badge'
	import {
		getOrderStatistics
	} from '@/api/order'
	export default {
		data() {
			return {
				navBarInfo: null,
				user: null,
				orderStatusList: [{
					name: '待支付',
					status: 'pending',
					icon: 'wallet',
					badge: 0,
				}, {
					name: '待发货',
					status: 'paid',
					icon: 'upload',
					badge: 0,
				}, {
					name: '待收货',
					status: 'shipped',
					icon: 'location',
					badge: 0,
				}, {
					name: '待评价',
					status: 'evaluate',
					icon: 'chat',
					badge: 0,
				}, {
					name: '退款/售后',
					status: 'refund',
					icon: 'undo',
					badge: 0,
				}]
			}
		},
		onLoad() {
			this.navBarInfo = this.$utils.getNavBarInfo()
		},
		onShow() {
			showBadges()

			this.user = useUserStore().getUser()

			if (this.user) {
				this.loadOrder()
			}
		},
		methods: {
			loadOrder() {
				getOrderStatistics().then(res => {
					this.orderStatusList[0].badge = res.data.pendingCount
					this.orderStatusList[1].badge = res.data.paidCount
					this.orderStatusList[2].badge = res.data.shippedCount
					this.orderStatusList[3].badge = res.data.evaluateCount
					this.orderStatusList[4].badge = res.data.refundCount

					var myCount = 0
					myCount += res.data.pendingCount > 0 ? 1 : 0
					myCount += res.data.paidCount > 0 ? 1 : 0
					myCount += res.data.shippedCount > 0 ? 1 : 0
					myCount += res.data.evaluateCount > 0 ? 1 : 0
					myCount += res.data.refundCount > 0 ? 1 : 0
					if (getBadges().myCount != myCount) {
						setBadges({
							myCount: myCount
						})
						showBadges()
					}
				})
			},

			clickUser() {
				if (this.user) {
					uni.navigateTo({
						url: '/pages/my/info'
					})
				} else {
					uni.navigateTo({
						url: '/pages/login/login'
					})
				}
			},

			clickOrder() {
				if (!useUserStore().isLogin()) {
					uni.navigateTo({
						url: '/pages/login/login'
					})
					return
				}

				uni.navigateTo({
					url: '/pages/order/order'
				})
			},

			clickOrderStatus(e) {
				if (!useUserStore().isLogin()) {
					uni.navigateTo({
						url: '/pages/login/login'
					})
					return
				}

				var item = this.orderStatusList[e.detail.index]
				uni.navigateTo({
					url: '/pages/order/order?status=' + item.status
				})
			},

			clickAddress() {
				if (!useUserStore().isLogin()) {
					uni.navigateTo({
						url: '/pages/login/login'
					})
					return
				}

				uni.navigateTo({
					url: '/pages/my/address'
				})
			},
			
			clickResource() {
				if (!useUserStore().isLogin()) {
					uni.navigateTo({
						url: '/pages/login/login'
					})
					return
				}
				
				uni.navigateTo({
					url: '/pages/resource/product'
				})
			},

			clickCustomerService() {
				uni.navigateTo({
					url: '/pages/setting/customer-service'
				})
			},

			clickAbout() {
				uni.navigateTo({
					url: '/pages/setting/about'
				})
			},
		},
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-bg-color;
	}

	.item {
		height: 100rpx;
		padding: 0 20rpx;
		display: flex;
		flex-direction: row;
		align-items: center;
	}
</style>