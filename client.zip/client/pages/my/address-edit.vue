<template>
	<view class="flex-column-center">
		<view class="space-mt-20" style="width: 600rpx;">
			<uni-forms ref="loginForm" :modelValue="formData" :rules="rules">
				<uni-forms-item label="姓名" name="name">
					<uni-easyinput type="text" v-model="formData.name" placeholder="请输入收货人姓名" />
				</uni-forms-item>
				<uni-forms-item label="手机号" name="phone">
					<uni-easyinput type="text" v-model="formData.phone" placeholder="请输入收货人手机号" />
				</uni-forms-item>
				<uni-forms-item label="省市区" v-if="areaList[0].length > 0">
					<view class="flex-column" style="height: 100%;justify-content: center;">
						<picker mode="multiSelector" @change="changeArea" @cancel="cancelArea"
							@columnchange="changeAreaColumn" :value="areaIndexList" :range="areaList" range-key="name">
							<view class="flex-row-center">
								<text class="flex-width-fill font-base font-line1">
									{{areaNameText}}
								</text>
								<uni-icons class="space-ml-10" type="forward" size="28rpx" color="#c7c7c7"></uni-icons>
							</view>
						</picker>
					</view>
				</uni-forms-item>
				<uni-forms-item label="详细地址" name="detail">
					<uni-easyinput type="text" v-model="formData.detail" placeholder="请输入详细地址" />
				</uni-forms-item>
				<uni-forms-item label="是否默认">
					<view class="flex-row-center" style="height: 100%;">
						<radio @click="clickIsDefault" :checked="formData.isDefault"></radio>
					</view>
				</uni-forms-item>
			</uni-forms>
		</view>
		<button class="space-mt-20" type="primary" @click="clickSave">保存</button>
	</view>
</template>

<script>
	import {
		getAreas
	} from '@/api/area'
	import {
		getAddress,
		createAddress,
		updateAddress
	} from '@/api/address'
	export default {
		data() {
			return {
				areaList: [
					[],
					[],
					[]
				],
				areaIndexList: [0, 0, 0],
				areaSelectedList: [0, 0, 0],
				formData: {

				},
				rules: {
					name: {
						rules: [{
							required: true,
							errorMessage: '请输入收货人姓名'
						}]
					},
					phone: {
						rules: [{
							required: true,
							errorMessage: '请输入收货人手机号'
						}]
					},
					detail: {
						rules: [{
							required: true,
							errorMessage: '请输入详细地址'
						}]
					},
				},
			}
		},
		onLoad(options) {
			if (options.id) {
				this.loadData(options.id)
			} else {
				this.loadArea()
			}
		},
		computed: {
			areaNameText() {
				if (this.areaList[0].length == 0) {
					return ''
				}

				var item1 = this.areaList[0][this.areaSelectedList[0]]
				var item2 = item1.children[this.areaSelectedList[1]]
				var item3 = item2.children[this.areaSelectedList[2]]

				return item1.name + ' ' + item2.name + ' ' + item3.name
			}
		},
		methods: {
			loadData(id) {
				getAddress(id).then(res => {
					this.formData = res.data

					this.loadArea()
				})
			},

			loadArea() {
				getAreas().then(res => {
					var list = []
					var map = new Map()

					res.data.forEach(item => {
						if (item.level == 1) {
							list.push(item)
						} else {
							var parent = map.get(item.parentCode)
							if (!parent.children) {
								parent.children = []
							}
							parent.children.push(item)
						}

						map.set(item.code, item)
					})

					var areaSelectedList = [0, 0, 0]
					if (this.formData.id) {
						for (var i1 = 0; i1 < list.length; i1++) {
							var item1 = list[i1]
							if (item1.name == this.formData.province) {
								areaSelectedList[0] = i1
								for (var i2 = 0; i2 < item1.children.length; i2++) {
									var item2 = item1.children[i2]
									if (item2.name == this.formData.city) {
										areaSelectedList[1] = i2
										for (var i3 = 0; i3 < item2.children.length; i3++) {
											var item3 = item2.children[i3]
											if (item3.name == this.formData.district) {
												areaSelectedList[2] = i3
												break
											}
										}
										break
									}
								}
								break
							}
						}
					}

					this.areaSelectedList = areaSelectedList
					this.areaIndexList = [...this.areaSelectedList]
					this.areaList[0] = list
					this.selectArea()
				})
			},

			selectArea() {
				this.areaList[1] = this.areaList[0][this.areaIndexList[0]].children
				this.areaList[2] = this.areaList[1][this.areaIndexList[1]].children
			},

			changeAreaColumn(e) {
				this.areaIndexList[e.detail.column] = e.detail.value

				if (e.detail.column == 0) {
					this.areaIndexList[1] = 0
					this.areaIndexList[2] = 0
				} else if (e.detail.column == 1) {
					this.areaIndexList[2] = 0
				}

				this.selectArea()
			},

			changeArea(e) {
				this.areaSelectedList = [...this.areaIndexList]
			},

			cancelArea(e) {
				this.areaIndexList = [...this.areaSelectedList]
				this.selectArea()
			},

			clickIsDefault() {
				this.formData.isDefault = this.formData.isDefault ? false : true
			},

			clickSave() {
				this.$refs.loginForm.validate().then(() => {
					var phonePattern = /^1[3-9]\d{9}$/;
					if (!phonePattern.test(this.formData.phone)) {
						uni.showToast({
							title: '手机号格式错误',
							icon: 'none',
							duration: 3000,
						})
						return
					}

					var item1 = this.areaList[0][this.areaSelectedList[0]]
					var item2 = item1.children[this.areaSelectedList[1]]
					var item3 = item2.children[this.areaSelectedList[2]]

					this.formData.province = item1.name
					this.formData.city = item2.name
					this.formData.district = item3.name

					if (this.formData.id) {
						updateAddress(this.formData.id, this.formData).then(res => {
							uni.showToast({
								title: '修改成功',
								icon: 'none',
								duration: 3000,
							})
							uni.navigateBack()
						})
					} else {
						createAddress(this.formData).then(res => {
							uni.showToast({
								title: '增加成功',
								icon: 'none',
								duration: 3000,
							})
							uni.navigateBack()
						})
					}
				}).catch(err => {

				})
			},
		}
	}
</script>

<style lang="scss" scoped>

</style>