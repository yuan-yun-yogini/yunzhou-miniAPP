<template>
	<view class="container flex-column">
		<view class="flex-column" v-if="navBarInfo">
			<view :style="{width: navBarInfo.navBar.width + 'px', marginTop: searchTop + 'px'}">
				<uni-search-bar placeholder="请输入分类名称" v-model="searchValue" @confirm="clickSearch"></uni-search-bar>
			</view>
		</view>
		<view class="flex-row flex-height-fill">
			<scroll-view class="bg-container" style="width: 200rpx;height: 100%;" :scroll-y="true">
				<view class="flex-column">
					<view class="flex-row-center space-pa-12" :class="{'bg-item': item.isActive}"
						v-for="(item, index) in list1" :key="item.id" @click="clickCategory1(index)">
						<view class="space-mr-4" style="width: 4rpx;height: 16rpx;border-radius: 2rpx;"
							:class="{'bg-color-active': item.isActive}"></view>
						<text class="font-main-l" :class="{'color-active': item.isActive}">{{item.name}}</text>
					</view>
				</view>
			</scroll-view>
			<scroll-view class="flex-width-fill bg-section" style="height: 100%;" :scroll-y="true">
				<uni-grid :column="3" :highlight="true" :showBorder="false" :square="false" @change="clickCategory2">
					<uni-grid-item v-for="(item, index) in list2" :key="item.id" :index="index">
						<view class="flex-column-center space-py-10">
							<image style="width: 60rpx;height: 60rpx;" :src="item.image.url" mode="aspectFit"></image>
							<text class="font-main-l space-mt-8"
								:class="{'color-active': item.isActive}">{{item.name}}</text>
						</view>
					</uni-grid-item>
				</uni-grid>
				<data-empty v-if="list2.length == 0"></data-empty>
			</scroll-view>
		</view>
	</view>
</template>

<script>
	import {
		showBadges
	} from '@/utils/badge'
	import {
		getCategorys
	} from '@/api/category'
	export default {
		data() {
			return {
				navBarInfo: undefined,
				searchTop: 0,
				searchValue: '',
				list1: [],
				list2: [],
			}
		},
		onLoad() {
			this.navBarInfo = this.$utils.getNavBarInfo()
			//uni-search-bar高56px
			this.searchTop = Math.max(this.navBarInfo.menu.top + (this.navBarInfo.menu.height / 2) - (56 / 2), 0)

			this.loadData()
		},
		onShow() {
			showBadges()
		},
		methods: {
			loadData() {
				getCategorys().then(res => {
					var list = []
					var map = new Map()

					res.data.forEach(item => {
						item.isActive = false
						item.children = []

						if (item.parentId) {
							if (map.has(item.parentId)) {
								var parent = map.get(item.parentId)
								parent.children.push(item)
								map.set(item.id, item)
							}
						} else {
							list.push(item)
							map.set(item.id, item)
						}
					});

					if (list.length > 0) {
						list[0].isActive = true
						this.list2 = list[0].children
					}

					this.list1 = list
				})
			},

			clickSearch() {
				if (!this.searchValue) {
					return
				}

				var list = this.list1
				this.resetActive(list)
				var index = this.search(list)
				if (index >= 0) {
					this.list2 = list[index].children
				} else {
					this.list2 = []
				}
				this.list1 = list
			},

			search(list) {
				for (var i = 0; i < list.length; i++) {
					var item = list[i]
					if (item.name.indexOf(this.searchValue) >= 0) {
						item.isActive = true
						return i
					}

					if (item.children) {
						if (this.search(item.children) >= 0) {
							item.isActive = true
							return i
						}
					}
				}
				return -1
			},

			resetActive(list) {
				list.forEach(item => {
					item.isActive = false
					if (item.children) {
						this.resetActive(item.children)
					}
				})
			},

			clickCategory1(index) {
				var list = this.list1
				this.resetActive(list)
				list[index].isActive = true
				this.list2 = list[index].children
				this.list1 = list
			},

			clickCategory2(e) {
				var item = this.list2[e.detail.index]
				uni.navigateTo({
					url: '/pages/product/product?categoryId=' + item.id
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		height: calc(100vh - var(--window-bottom));
	}
</style>