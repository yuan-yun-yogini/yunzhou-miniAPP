import {
	defineStore
} from 'pinia';

export const useUserStore = defineStore('user', {
	state: () => {
		return {
			login: null
		}
	},
	getters: {

	},
	actions: {
		initLogin() {
			var value = uni.getStorageSync('login')
			if (value) {
				this.login = JSON.parse(value)
			} else {
				this.login = null
			}
		},
		setLogin(value) {
			this.login = value

			if (value) {
				uni.setStorageSync('login', JSON.stringify(this.login))
			} else {
				uni.removeStorageSync('login')
			}
		},
		isLogin() {
			if (!this.login) {
				return false
			}

			if (this.login.expire > Date.now()) {
				return true
			} else {
				return false
			}
		},
		getUser() {
			if (this.isLogin()) {
				return this.login.user
			} else {
				return null
			}
		},
		setUser(value) {
			if (this.login) {
				var login = this.login

				login.user = value

				this.setLogin(login)
			}
		},
	},
})