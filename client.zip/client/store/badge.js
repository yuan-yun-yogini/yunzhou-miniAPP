import {
	defineStore
} from 'pinia';

export const useBadgeStore = defineStore('badge', {
	state: () => {
		return {
			cartCount: 0,
			messageCount: 0,
			myCount: 0,
		}
	},
	getters: {

	},
	actions: {

	},
})