<script>
	import {
		useUserStore
	} from '@/store/user';
	import {
		loadBadges
	} from '@/utils/badge';
	export default {
		onLaunch: function() {
			console.log('App Launch')

			useUserStore().initLogin()

			if (useUserStore().isLogin()) {
				loadBadges()
			}
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	@import '@/uni_modules/uni-scss/index.scss';
	@import '@/static/common.scss';
	@import '@/static/space.scss';

	/* #ifndef APP-NVUE */
	@import '@/static/customicons.css';
	/* #endif */

	view {
		box-sizing: border-box;
	}

	image {
		display: block;
		height: auto;
	}
</style>