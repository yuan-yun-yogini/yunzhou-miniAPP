<template>
	<view class="flex-row flex-content-space">
		<view class="flex-column" :style="{width: columnWidth + 'rpx'}"
			v-for="(columnData, columnIndex) in columnDataList" :key="columnIndex">
			<view class="flex-column bg-item space-mb-10 uni-radius-lg" v-for="(item, index) in columnData" :key="item.id"
				@click="clickProduct(item)">
				<image :src="item.image.url"
					:style="{width: columnWidth + 'rpx', height: item.image.showHeight + 'px' }" mode="aspectFill" />
				<text class="font-title font-line2 space-mt-10 space-px-5" style="line-height: 36rpx;">{{ item.name }}</text>
				<text class="font-base space-mt-5 space-px-5" style="line-height: 28rpx;">销量：{{ item.salesVolumn }}</text>
				<view class="flex-row space-mt-5 space-mb-10" style="align-items: flex-end;height: 36rpx;">
					<text class="font-price space-px-5">￥{{ $utils.apiMoneyToShow(item.price) }}</text>
					<text class="font-secondary space-pr-5" style="text-decoration: line-through;"
						v-if="item.originalPrice > 0 && item.originalPrice != item.price">￥{{ $utils.apiMoneyToShow(item.originalPrice) }}</text>
				</view>
			</view>
		</view>

		<!-- 用来测量文字高度的隐藏节点（关键） -->
		<text class="measure-text font-title font-line2 space-px-5" :style="{width: columnWidth + 'rpx'}"
			id="measure">{{ measureText }}</text>
	</view>
</template>

<script>
	export default {
		name: "product-waterfall",
		props: {
			columnNum: {
				type: Number,
				default: 2,
			},
			columnWidth: {
				type: Number,
				default: 300,
			}
		},

		data() {
			return {
				columnDataList: [],
				columnHeightList: [],
				measureText: '', // 测量文字
			}
		},

		onLoad() {
			this.initDataList()
		},

		methods: {
			initDataList() {
				var columnDataList = []
				var columnHeightList = []

				for (var i = 0; i < this.columnNum; i++) {
					columnDataList.push([])
					columnHeightList.push(0)
				}

				this.columnDataList = columnDataList
				this.columnHeightList = columnHeightList
			},

			async setDataList(list) {
				this.initDataList()

				for (var item of list) {
					await this.addItemToColumn(item)
				}
			},

			async addDataList(list) {
				for (var item of list) {
					await this.addItemToColumn(item)
				}
			},

			async addItemToColumn(item) {
				const itemHeight = await this.calcItemRealHeight(item)

				var minIndex = 0;
				var minHeight = this.columnHeightList[0];
				for (var i = 1; i < this.columnNum; i++) {
					if (this.columnHeightList[i] < minHeight) {
						minHeight = this.columnHeightList[i]
						minIndex = i
					}
				}

				this.columnHeightList[minIndex] += itemHeight
				this.columnDataList[minIndex].push(item)
			},

			// 计算所有 item 真实总高度（图片+文字）
			async calcItemRealHeight(item) {
				// 图片高度（等比缩放）
				item.image.showHeight = uni.upx2px((item.image.height / item.image.width) * this.columnWidth)

				// 文字真实高度
				const nameHeight = await this.getTextHeight(item.name)

				// 其它高度(名称top+销量top+销量height+价格top+价格height+价格bottom+条目bottom)
				const otherHeight = uni.upx2px(20 + 10 + 28 + 10 + 36 + 20 + 20)

				return item.image.showHeight + nameHeight + otherHeight
			},

			// 精准测量文字真实高度（核心方法）
			getTextHeight(text) {
				return new Promise(resolve => {
					this.measureText = text // 把文字放进隐藏节点

					// 下一帧再获取高度（确保渲染完成）
					setTimeout(() => {
						uni.createSelectorQuery().in(this)
							.select('#measure')
							.boundingClientRect(r => {
								resolve(r.height)
							}).exec()
					}, 30)
				})
			},

			clickProduct(item) {
				this.$emit("clickItem", item)
			},
		},
	}
</script>

<style lang="scss" scoped>
	/* 测量文字高度用：隐藏但真实渲染 */
	.measure-text {
		position: fixed;
		left: -750rpx;
		top: 0;
		line-height: 36rpx;
		box-sizing: border-box;
		visibility: hidden;
	}
</style>