<template>
	<view class="flex-column-center">
		<image style="width: 160rpx;" :style="{marginTop: top}" src="/static/empty.png" mode="widthFix"></image>
		<text class="font-secondary space-mt-10">{{message}}</text>
	</view>
</template>

<script>
	export default {
		name: "data-empty",
		props: {
			message: {
				type: String,
				default: '没有数据',
			},
			top: {
				type: String,
				default: '100rpx',
			}
		},

		data() {
			return {

			};
		}
	}
</script>

<style lang="scss" scoped>

</style>